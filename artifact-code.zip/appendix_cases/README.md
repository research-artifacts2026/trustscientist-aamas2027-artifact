# Recorded appendix cases
Four post hoc examples from existing experiments. examples.json keeps exact
selected source records, version digests and source-file SHA256 values. It
does not replace complete study denominators. Source projections omit unrelated
API usage and timing fields; inference and decisions are not modified. Branch
indices are zero-based in the raw data. No new model call or annotation is made.

Strict numeric checking also exposed existing appendix registry omissions for signed paired differences and conditional risks. Their real source selectors were added. Scientific-notation variances and a coverage-range dash were reformatted as equivalent decimal values/text to avoid parser fragments; no measured result changed.
The saved coverage curve uses17 to93 selected pairs; its appendix description now states those actual coordinates instead of nominal percentages. Main text remains unchanged. One-decimal signed percentages have explicit reproducible display-value selectors, without broadening numerical tolerance.
