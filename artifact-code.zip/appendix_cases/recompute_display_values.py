"""Recompute existing appendix display values; no inference or result changes."""
from pathlib import Path
import csv,hashlib,json
P=Path(__file__).resolve().parents[1]
source=P/'revision_control/paired_scope/summary.json';d=json.loads(source.read_text())
raw={'structured_risk':d['summary'][1]['selective_risk'],'scope_risk':d['summary'][3]['selective_risk'],
 'delta_success':d['paired'][0]['delta_success'],'delta_false':d['paired'][0]['delta_false'],
 'delta_success_low':d['paired'][0]['delta_success_ci'][0],'delta_success_high':d['paired'][0]['delta_success_ci'][1],
 'delta_false_low':d['paired'][0]['delta_false_ci'][0]}
curve=P/'experiments/matched_coverage_benchmark/results/matched_coverage_curve.csv'
rows=list(csv.DictReader(curve.open(encoding='utf-8')))
out={'scope_source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'curve_source_sha256':hashlib.sha256(curve.read_bytes()).hexdigest(),
 'rounding':'Percentage points rounded to one decimal for existing appendix display.',
 'raw':raw,'display_percent':{k:round(v*100,1) for k,v in raw.items()},
 'selected_k_min':min(int(x['selected_k']) for x in rows),'selected_k_max':max(int(x['selected_k']) for x in rows)}
(P/'revision_examples/appendix_display_values.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print('Previously reported display statistics recomputed from source records.')
