from pathlib import Path
import sys,json,copy,shutil,importlib.util,time,hashlib,random
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'implementation'))
from researchclaw.pipeline.counterfactual_revalidation import Store,version_contract_policy,canonical,digest,atomic
OLD=BASE/'legacy_dependency_tracker.py'
spec=importlib.util.spec_from_file_location('legacy_tracker',OLD);legacy=importlib.util.module_from_spec(spec);spec.loader.exec_module(legacy)
SOURCE=BASE/'data'
METHODS=['no_reaudit','existing_dependency_tracker','full_replay','TrustScientist_CBR']
def prepare():
    cases=json.loads((SOURCE/'cases.json').read_text())
    protocol={'scope':'Controlled version updates on real archived CORE files, with authored linear historical decision chains; no new scientific execution or LLM calls.',
      'cases':len(cases),'events':sum(len(c['events']) for c in cases),'methods':METHODS,
      'policy':'Existing Stage-15 requirements rule: reject and retry_count<max_retries -> refine, otherwise proceed. Here retry=0,max=1. PIVOT is covered separately by functional tests.',
      'lineage':'Claims are ordered by their archived question order into an authored chain. Each event starts from the immediately preceding file state and freshly recorded decisions. Histories are independent replay scenarios, not a resumed autonomous research trajectory.',
      'oracle':'Direct comparison of all required current file hashes to frozen registered versions and base_pass, independent of the CBR store. Earliest changed action in linear history is the rollback target.',
      'tracker':'Frozen existing graph_select/build_index/checker from dynamic_revalidation_20260930.py. Updates certificate predicates but has no decision replay or rollback.',
      'full':'Replay in historical order and stop at first flip, like CBR, including unaffected earlier decisions.',
      'CBR':'Determine changed bound file digests; replay affected decisions in historical order; rollback and invalidate causal suffix at first action change.',
      'metrics':['wrong historical actions retained','earliest rollback exact','unnecessary rollback','decision replay calls','certificate checks','witness files inspected'],
      'timing':'Filesystem and bookkeeping measured separately only; no claim of latency speedup from predicate call counts.',
      'data_hash':digest(cases),'runner_hash':digest(Path(__file__).read_bytes()),'engine_hash':digest((BASE/'implementation/researchclaw/pipeline/counterfactual_revalidation.py').read_bytes()),'tracker_hash':digest(OLD.read_bytes())}
    p=BASE/'protocol.json'
    if p.exists():assert json.loads(p.read_text())==protocol
    else:atomic(p,protocol)
    atomic(BASE/'cases.json',cases)
    return cases
def action(claim,root,case):
    passed=claim['base_pass'] and all(hashlib.sha256((root/f).read_bytes()).hexdigest()==case['files'][f]['expected_sha256'] for f in claim['required_files'])
    return 'proceed' if passed else 'refine'
def mutate(root,event):
    for f in event['changed_files']:
        if f=='unregistered':(root/f).write_text('unrelated update');continue
        original=(SOURCE/'originals'/CURRENT_ID/f).read_bytes()
        (root/f).write_bytes(original+(b'\nCONTROLLED_VERSION_CHANGE\n' if event['mutated'] else b''))
def run():
    global CURRENT_ID
    cases=prepare();rows=[];order_rng=random.Random(20261002)
    for ci,case in enumerate(cases):
        CURRENT_ID=case['id'];prev=BASE/'workspaces'/CURRENT_ID/'previous';prev.mkdir(parents=True,exist_ok=True)
        for f in case['files']:shutil.copyfile(SOURCE/'originals'/CURRENT_ID/f,prev/f)
        (prev/'unregistered').write_text('initial')
        for event_index,event in enumerate(case['events']):
            before=[action(c,prev,case) for c in case['claims']]
            method_order=METHODS.copy();order_rng.shuffle(method_order);out={}
            for method in method_order:
                root=BASE/'workspaces'/CURRENT_ID/str(event_index)/method
                root.mkdir(parents=True,exist_ok=True)
                for f in list(case['files'])+['unregistered']:shutil.copyfile(prev/f,root/f)
                store=Store(root,{'version_contract':version_contract_policy})
                for j,claim in enumerate(case['claims']):
                    output='branch/output_'+str(j)+'.json'
                    atomic(root/output,{'decision_index':j,'action':before[j]})
                    context={'base_pass':claim['base_pass'],'expected':{f:case['files'][f]['expected_sha256'] for f in claim['required_files']},'retry_count':0,'max_retries':1}
                    store.record('version_contract',claim['required_files'],context,before[j],[output],
                        {'last_completed_stage':14,'last_completed_name':'RESULT_ANALYSIS','resume_decision_index':j})
                ids={n['id'] for n in case['nodes']};cache={n:None for n in ids}
                legacy.checker(case['nodes'],case['files'],root,cache,ids,len(ids))
                mutate(root,event)
                gold=[action(c,root,case) for c in case['claims']]
                flipped=[j for j,(a,b) in enumerate(zip(before,gold)) if a!=b]
                expected=min(flipped) if flipped else None
                start=time.perf_counter()
                if method=='existing_dependency_tracker':
                    selected=legacy.graph_select(legacy.build_index(case['nodes']),event['changed_files'])
                    cost=legacy.checker(case['nodes'],case['files'],root,cache,selected,len(ids))
                    report={'rollback_index':None,'replayed':[],'certificate_checks':cost['checks'],
                        'certificates':{c['node']:cache[c['node']] for c in case['claims']},
                        'branch_revalidation_supported':False,'selected':sorted(selected)}
                else:
                    report=store.revalidate({'no_reaudit':'none','full_replay':'full','TrustScientist_CBR':'cbr'}[method])
                    report['certificate_checks']=0
                elapsed=time.perf_counter()-start
                rollback=report['rollback_index']
                active_count=len(store.state()['active'])
                remaining=sum(before[j]!=gold[j] for j in range(active_count))
                if rollback is not None:
                    assert not any((root/('branch/output_'+str(j)+'.json')).exists() for j in range(rollback,len(before)))
                    assert json.loads((root/'checkpoint.json').read_text())['resume_decision_index']==rollback
                out[method]={'report':report,'seconds':elapsed,'active_decisions':active_count,
                    'wrong_actions_retained':remaining,'exact_rollback':rollback==expected,
                    'unnecessary_rollback':rollback is not None and expected is None}
            rows.append({'capsule':CURRENT_ID,'event_index':event_index,'event_type':event['type'],
              'old_actions':before,'counterfactual_actions':gold,'flip_indices':flipped,'oracle_rollback':expected,
              'method_order':method_order,'methods':out})
            mutate(prev,event)
        print(ci+1,'/',len(cases),'completed',flush=True)
    atomic(BASE/'records.json',rows)
    summary=[]
    for m in METHODS:
        mr=[r['methods'][m] for r in rows]
        summary.append({'method':m,'events':len(rows),'flip_events':sum(r['oracle_rollback'] is not None for r in rows),
          'exact_rollback_on_flip':sum(r['methods'][m]['exact_rollback'] for r in rows if r['oracle_rollback'] is not None),
          'nonflip_events':sum(r['oracle_rollback'] is None for r in rows),
          'unnecessary_rollbacks':sum(x['unnecessary_rollback'] for x in mr),
          'wrong_actions_retained':sum(x['wrong_actions_retained'] for x in mr),
          'decision_replays':sum(len(x['report']['replayed']) for x in mr),
          'certificate_checks':sum(x['report']['certificate_checks'] for x in mr),
          'seconds':sum(x['seconds'] for x in mr)})
    atomic(BASE/'summary.json',summary)
    import csv
    with (BASE/'summary.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
    print(json.dumps(summary,indent=2))
if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='prepare': print(json.dumps({'cases':len(prepare())}))
    else:run()
