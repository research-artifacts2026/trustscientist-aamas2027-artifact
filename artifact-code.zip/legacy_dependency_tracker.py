import json,hashlib,time
from collections import defaultdict,deque

def canonical(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'))

def sha(x):return hashlib.sha256(x if isinstance(x,bytes) else str(x).encode()).hexdigest()

def checker(nodes,files,workspace,cache,selected,budget):
    for node in selected:cache[node]=None
    nchecks=0;nreads=0;nbytes=0;start=time.perf_counter()
    for node in nodes:
        if node['id'] not in selected or nchecks>=budget:continue
        nchecks+=1;ok=all(cache[p] is True for p in node['parents'])
        if ok:
            for fid in node['input_files']:
                blob=(workspace/fid).read_bytes();nreads+=1;nbytes+=len(blob)
                ok &= sha(blob)==files[fid]['expected_sha256']
        if node['kind']=='closure':ok &= node['initial_contract_pass']
        cache[node['id']]=bool(ok)
    return {'checks':nchecks,'file_reads':nreads,'bytes_read':nbytes,'check_seconds':time.perf_counter()-start}

def build_index(nodes):
    direct=defaultdict(list);children=defaultdict(list)
    for node in nodes:
        for f in node['input_files']:direct[f].append(node['id'])
        for parent in node['parents']:children[parent].append(node['id'])
    return direct,children

def graph_select(index,changed):
    direct,children=index
    selected=set();queue=deque(n for f in changed for n in direct[f])
    while queue:
        n=queue.popleft()
        if n in selected:continue
        selected.add(n);queue.extend(children[n])
    return selected
