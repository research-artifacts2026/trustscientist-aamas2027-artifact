# TrustScientist: evidence and branch revalidation

Anonymous research artifact for the current AAMAS draft. This release contains
real recorded outputs and a portable implementation of Counterfactual Branch
Revalidation (CBR). It does not claim SOTA, independently validated scientific
correctness, adaptive risk certification, or lower overall agent cost.

## Reproduce offline

Linux, Python 3.10+; CBR uses the standard library including fcntl file locks. Begin in a
fresh checkout: experiment state persists between runs.

```text
python test_cbr.py
python run_branch_experiment.py prepare
python run_branch_experiment.py
python validate_branch_results.py
python analysis/recompute_recorded_results.py
```

The branch experiment uses real archived artifact bytes from 45 capsules,
405 controlled update scenarios and authored linear histories. It is a
contract/decision-maintenance experiment, not autonomous research execution.
`recorded_results/` retains the original recorded branch outputs; newly
reproduced outputs are written at the root. Portable witness redaction and
digest handling are documented in `ANONYMIZATION.json`.

## Redraw the four result figures

Install the plotting dependencies from `requirements-figures.txt`, then run:

```text
python visualizations/scripts/plot_current_results.py --data-dir visualizations
python visualizations/scripts/create_report.py --data-dir visualizations
```

Outputs are vector PDF, editable SVG and 350-dpi PNG. Counts and full scope
captions come from frozen JSON, not hardcoded measurements. The second
command also writes the five-page report and complete metric CSV.

## Evidence map

| Directory | Content and scope |
|---|---|
| implementation/ | CBR engine, CLI and opt-in integration patch |
| data/ | Portable archived witness bytes and controlled update cases |
| recorded_results/ | Original 405-event branch experiment |
| evidence/certificate/ | 2,025 scored method-event rows, saved model receipts; scripted versions and declared dependencies |
| evidence/scope/ | 79 paired semantic-gate cases and saved model receipts |
| evidence/acquisition/ | Saved acquisition decisions; budget-four ECC/structured-selector tie; guarded closure is zero |
| evidence/disambiguation/ | Frozen 41-question/24-capsule pilot and separate post hoc diagnostics, plus archived model receipts |
| evidence/manifest/ | 372 saved records per LLM and held-out contract decisions; supplied validity flags |
| evidence/scifact/ | Fixed-retrieval predictions; six repeated policies and two single deterministic operating points |
| evidence/fresh/ | Five repeats of the same 20 tasks; prepared compatibility fixes; not independent populations |
| appendix_cases/ | Four selected actual traces; qualitative examples, not new aggregate evidence |
| visualizations/ | Complete plotted inputs, figure sources and captions |
| historical_code/ | Archived experiment programs, requiring original services/data configuration for live inference |
| paper/ | Current technical appendix and matching Overleaf source package |

The offline analysis recomputes reported counts from saved records. It does not
rerun LLM inference. Acquisition and manifest validity follow their archived
protocols; model judgments are not human labels. The discriminating pilot and
post hoc diagnostic remain separate, including in raw receipt inventories.
Document binaries from the acquisition corpus are omitted; public source IDs,
protocols and saved outputs remain. Full production AutoResearchClaw source,
private services and naturally occurring decision histories are not included.

## Boundaries that must survive reproduction

- CBR and full replay both find 254/254 earliest rollback points; CBR uses
  382 vs 416 decision evaluations. Certificate-only tracking has no replay API.
- Graph and flat certificate tracking tie, using 1,530 predicate checks vs
  2,888 for full checking. These work units are not total cost.
- The unguarded controller and structured selector match all 82 budget-four
  outcomes. Failed historical calibration yields 0/82 guarded closures.
- Nominal clean manifest closure is not semantic binding accuracy. GPT rejects
  three actual candidate mismatches accepted by TrustScientist.
- Scope witnesses lose nine correct closures while removing one error.
- SciFact methods have different coverage; no connected SOTA frontier is claimed.

Author-local paths and network addresses are redacted without modifying
decisions or numeric outcomes. `RELEASE_PROVENANCE.json` records original
source hashes, released hashes and whether a file was text-redacted. No author
Git history, credentials, private production backup or API keys are included.
The original integration patch applies to the audited modified checkout, not
an asserted upstream release. Upstream judge recomputation and autonomous
replacement-branch execution remain untested. See `AI_ASSISTANCE.md`.
