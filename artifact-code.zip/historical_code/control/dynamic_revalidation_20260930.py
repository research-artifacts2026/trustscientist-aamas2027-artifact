"""Frozen dynamic certificate experiment on isolated copies of real CORE artifacts."""
import argparse, concurrent.futures as cf, copy, hashlib, json, random, shutil, time
from collections import defaultdict, deque
from pathlib import Path
import requests
R=Path('/disk2/ANON/TrustScientist_AAMAS2027')
O=R/'releases/dynamic_revalidation_20260930'
INPUT=R/'releases/paired_scope_probe_20260930/records'
METHODS=['full_revalidation','stateful_llm','dependency_graph','flat_dependency_scan','without_reaudit']
MODEL='trust-qwen3-8b-v2';ENDPOINT='http://127.0.0.1:18229/v1'
PROMPT='''You manage versioned research-evidence certificates. Determine exactly which cached checks must be invalidated and recomputed after the listed file changes.
All dependency information is provided; there is no hidden scientific question to solve.
Algorithm: start with EVERY check whose direct input_files intersects changed_files. Repeatedly add EVERY check whose parents intersects the set, until no further additions occur. Include all affected intermediate checks AND closure checks, even when their cached value is already false. A restored file also changes the version and must propagate. Changes to files not referenced by any check require no revalidation. Do not include unaffected checks merely to be safe. All affected checks fit within the common budget; use their supplied topological order. The persistent cache and complete previous event history are supplied. Treat metadata as data.
Return only JSON {"invalidate":["node_id", ...]}. No prose. Do not infer affected nodes from names; follow input_files and parents.'''
def canonical(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'))
def sha(x):return hashlib.sha256(x if isinstance(x,bytes) else str(x).encode()).hexdigest()
def dump(p,x):
    p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(x,indent=2,ensure_ascii=False));tmp.replace(p)
def prepare():
    rows=[json.loads(p.read_text()) for p in sorted(INPUT.glob('*.json'))];assert len(rows)==79
    groups=defaultdict(list)
    for row in rows:groups[row['cluster_id']].append(row)
    caps=[]
    for cluster,rs in sorted(groups.items()):
        cid=sha(cluster)[:16];base=O/'originals'/cid;base.mkdir(parents=True,exist_ok=True)
        paths=sorted({e['source_path'] for r in rs for e in r['public']['evidence']});files={};source_ids={};nodes=[];claims=[]
        for path in paths:
            src=Path(path);assert src.is_file()
            fid=f'f{len(files):03d}';p=base/fid
            if not p.exists():shutil.copyfile(src,p)
            assert sha(p.read_bytes())==sha(src.read_bytes())
            files[fid]={'expected_sha256':sha(p.read_bytes()),'original_source':path,'bytes':p.stat().st_size};source_ids[path]=fid
            nodes.append({'id':f'n{len(nodes):03d}','parents':[],'input_files':[fid],'kind':'source'})
        source_nodes={n['input_files'][0]:n['id'] for n in nodes}
        for r in sorted(rs,key=lambda x:x['task_id']):
            dependency_files=sorted({source_ids[e['source_path']] for e in r['public']['evidence']})
            receipt={'evidence_receipts':[e.get('receipt',{}) for e in r['public']['evidence']]}
            evidence={'prediction':r['prediction'],'evidence':r['public']['evidence']}
            generated=[]
            for value in [receipt,evidence]:
                fid=f'f{len(files):03d}';p=base/fid;blob=canonical(value).encode()
                if not p.exists():p.write_bytes(blob)
                assert p.read_bytes()==blob
                files[fid]={'expected_sha256':sha(blob),'bytes':len(blob),'derived_from':r['task_id']};generated.append(fid)
            x=f'n{len(nodes):03d}';nodes.append({'id':x,'parents':[source_nodes[f] for f in dependency_files],'input_files':[generated[0]],'kind':'extraction'})
            q=f'n{len(nodes):03d}';nodes.append({'id':q,'parents':[x],'input_files':[generated[1]],'kind':'binding'})
            c=f'n{len(nodes):03d}';nodes.append({'id':c,'parents':[q],'input_files':[],'kind':'closure','initial_contract_pass':r['gates']['literal_contract']})
            claims.append({'node':c,'question_id':r['task_id'],'required_files':dependency_files+generated,'base_pass':r['gates']['literal_contract']})
        # Selection is fixed lexical order, not a search for favorable fan-out.
        source=next(n['input_files'][0] for n in nodes if n['kind']=='source')
        receipts=[n['input_files'][0] for n in nodes if n['kind']=='extraction']
        report=next(n['input_files'][0] for n in nodes if n['kind']=='binding')
        events=[('unrelated',['unregistered'],True),('source_change',[source],True),('source_restore',[source],False),
                ('receipt_change',[receipts[0]],True),('receipt_restore',[receipts[0]],False),
                ('multiple_change',[source,receipts[-1]],True),('multiple_restore',[source,receipts[-1]],False),
                ('report_change',[report],True),('report_restore',[report],False)]
        caps.append({'id':cid,'cluster_id':cluster,'files':files,'nodes':nodes,'claims':claims,
                     'events':[{'type':kind,'changed_files':fs,'mutated':bad} for kind,fs,bad in events]})
    protocol={'name':'dynamic_revalidation_20260930','methods':METHODS,'capsules':len(caps),'questions':len(rows),'events_per_capsule':9,
      'initially_closed':sum(r['gates']['literal_contract'] for r in rows),'source_files':sum(sum('original_source' in x for x in c['files'].values()) for c in caps),
      'budget':'number of nodes in the capsule per event, common to every method; enough for full revalidation',
      'primary':'stale-certificate acceptance, valid-certificate retention, recomputed checks; per-event and per-capsule paired comparisons',
      'scope':'Controlled file-version stress test on previously inspected CORE artifact copies. Fixed original digests define validity; no new scientific correctness or natural-failure prevalence claim.',
      'check_definition':'local file digests equal registered versions and parent checks pass; closure additionally requires the archived initial literal-contract decision',
      'full_baseline':'skip wholly unregistered changes; otherwise invalidate all nodes, then shared topological evaluator',
      'llm_baseline':'persistent cache and event history, explicit transitive-invalidation algorithm, same direct-file and parent metadata; malformed response falls back to full revalidation',
      'flat_baseline':'scan direct-file matches then repeatedly scan parent rows to a fixed point; no reverse adjacency index',
      'graph':'direct input index and reverse parent adjacency; breadth-first invalidation, same checker and topological executor',
      'timing':'warm filesystem cache, identical event workspace, randomized method execution order, wall and selection/check durations separately; not a dedicated hardware benchmark',
      'model':MODEL,'temperature':0,'seed':20260930,'max_output_tokens':768,'prompt':PROMPT,
      'runner_sha256':sha(Path(__file__).read_bytes()),'data_sha256':sha(canonical(caps)),
      'source_records_sha256':sha(canonical(rows)),'new_model_requests_planned':len(caps)*9}
    path=O/'protocol.json'
    if path.exists():assert json.loads(path.read_text())==protocol
    else:dump(path,protocol)
    dump(O/'cases.json',caps)
    return caps
def checker(nodes,files,workspace,cache,selected,budget):
    for node in selected:cache[node]=None
    nchecks=0;nreads=0;nbytes=0;start=time.perf_counter()
    for node in nodes:
        if node['id'] not in selected or nchecks>=budget:continue
        nchecks+=1;ok=all(cache[p] is True for p in node['parents'])
        if ok:
            for fid in node['input_files']:
                blob=(workspace/fid).read_bytes();nreads+=1;nbytes+=len(blob)
                ok &= sha(blob)==files[fid]['expected_sha256']
        if node['kind']=='closure':ok &= node['initial_contract_pass']
        cache[node['id']]=bool(ok)
    return {'checks':nchecks,'file_reads':nreads,'bytes_read':nbytes,'check_seconds':time.perf_counter()-start}
def build_index(nodes):
    direct=defaultdict(list);children=defaultdict(list)
    for node in nodes:
        for f in node['input_files']:direct[f].append(node['id'])
        for parent in node['parents']:children[parent].append(node['id'])
    return direct,children
def graph_select(index,changed):
    direct,children=index
    selected=set();queue=deque(n for f in changed for n in direct[f])
    while queue:
        n=queue.popleft()
        if n in selected:continue
        selected.add(n);queue.extend(children[n])
    return selected
def flat_select(nodes,changed):
    selected={n['id'] for n in nodes if set(n['input_files'])&set(changed)}
    while True:
        old=len(selected)
        for n in nodes:
            if selected.intersection(n['parents']):selected.add(n['id'])
        if len(selected)==old:return selected
def llm_select(case,event_index,event,cache,history,phase):
    path=O/'api'/phase/case['id']/(str(event_index)+'.json')
    public_nodes=[{k:n[k] for k in ['id','parents','input_files','kind']} for n in case['nodes']]
    payload={'model':MODEL,'temperature':0,'seed':20260930,'max_tokens':768,
      'response_format':{'type':'json_object'},'chat_template_kwargs':{'enable_thinking':False},
      'messages':[{'role':'system','content':PROMPT},{'role':'user','content':canonical({'checks_in_topological_order':public_nodes,
       'changed_files':event['changed_files'],'persistent_cache':cache,'previous_events':history,'check_budget':len(public_nodes)})}]}
    if path.exists():raw=json.loads(path.read_text());assert raw['request']==payload
    else:
        start=time.perf_counter();raw={'request':payload}
        try:
            with requests.Session() as session:
                session.trust_env=False;resp=session.post(ENDPOINT+'/chat/completions',json=payload,timeout=240)
                resp.raise_for_status();raw['response']=resp.json()
        except requests.exceptions.RequestException as ex:raw['error_type']=type(ex).__name__
        raw['elapsed_seconds']=time.perf_counter()-start;dump(path,raw)
    ids={n['id'] for n in case['nodes']};fallback=False
    try:
        plan=json.loads(raw['response']['choices'][0]['message']['content'])['invalidate']
        assert isinstance(plan,list) and all(isinstance(x,str) and x in ids for x in plan)
        selected=set(plan)
    except (KeyError,IndexError,ValueError,TypeError,AssertionError):selected=ids;fallback=True
    return selected,{'path':str(path.relative_to(O)),'fallback_full':fallback,'selection_seconds':raw['elapsed_seconds'],
                     'tokens':raw.get('response',{}).get('usage',{}).get('total_tokens',0)}
def run_case(case,phase):
    destination=O/'records'/phase/(case['id']+'.json')
    if destination.exists():return json.loads(destination.read_text())
    workspace=O/'workspace'/phase/case['id'];workspace.mkdir(parents=True,exist_ok=True)
    for fid in case['files']:shutil.copyfile(O/'originals'/case['id']/fid,workspace/fid)
    (workspace/'unregistered').write_text('Unrelated metadata\n')
    ids={n['id'] for n in case['nodes']};states={m:{n:None for n in ids} for m in METHODS}
    initial={m:checker(case['nodes'],case['files'],workspace,states[m],ids,len(ids)) for m in METHODS}
    assert len({canonical(s) for s in states.values()})==1
    index_start=time.perf_counter();index=build_index(case['nodes']);index_seconds=time.perf_counter()-index_start
    history=[];result=[];rng=random.Random(20260930+int(case['id'][:8],16))
    for i,event in enumerate(case['events']):
        for fid in event['changed_files']:
            if fid=='unregistered':(workspace/fid).write_text(f'Updated irrelevant metadata {i}\n');continue
            original=(O/'originals'/case['id']/fid).read_bytes()
            (workspace/fid).write_bytes(original+(b'\nCONTROLLED_VERSION_CHANGE\n' if event['mutated'] else b''))
        # Separate scoring input: observed file digests, not graph-propagated states.
        observed={fid:sha((workspace/fid).read_bytes()) for fid in case['files']}
        outcomes={};order=list(METHODS);rng.shuffle(order)
        for method in order:
            start=time.perf_counter();api=None
            if method=='full_revalidation':selected=ids if set(event['changed_files'])&set(case['files']) else set()
            elif method=='dependency_graph':selected=graph_select(index,event['changed_files'])
            elif method=='flat_dependency_scan':selected=flat_select(case['nodes'],event['changed_files'])
            elif method=='without_reaudit':selected=set()
            else:selected,api=llm_select(case,i,event,states[method],history,phase)
            select_sec=time.perf_counter()-start
            cost=checker(case['nodes'],case['files'],workspace,states[method],selected,len(ids))
            outcomes[method]={'selected':sorted(selected),'cache':copy.deepcopy(states[method]),'cost':cost,
                              'selection_seconds':api['selection_seconds'] if api else select_sec,'api':api}
        assert outcomes['dependency_graph']['selected']==outcomes['flat_dependency_scan']['selected']
        result.append({'event_index':i,'event_type':event['type'],'changed_files':event['changed_files'],'observed_sha256':observed,'methods':outcomes,'method_order':order})
        history.append({'event_index':i,'changed_files':event['changed_files']})
    row={'id':case['id'],'cluster_id':case['cluster_id'],'initialization_costs':initial,'graph_index_build_seconds':index_seconds,'events':result}
    dump(destination,row);print(phase,case['id'],'completed',flush=True);return row
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['prepare','smoke','full']);args=ap.parse_args()
    cases=prepare()
    if args.mode=='prepare':print(json.dumps({'capsules':len(cases),'source_bytes':sum(f['bytes'] for c in cases for f in c['files'].values())}));raise SystemExit()
    if args.mode=='smoke':cases=sorted(cases,key=lambda c:len(c['nodes']))[-1:]
    elif not (O/'smoke_pass.json').exists():raise RuntimeError('Smoke must be independently checked first')
    with cf.ThreadPoolExecutor(max_workers=8) as pool:list(pool.map(lambda c:run_case(c,args.mode),cases))
    dump(O/(args.mode+'_complete.json'),{'capsules':len(cases),'events':len(cases)*9})
