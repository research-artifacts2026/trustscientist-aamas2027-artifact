#!/usr/bin/env python3
"""Frozen v2 artifact-closure experiments; public inputs and evaluator labels separated."""
import argparse, concurrent.futures, copy, csv, hashlib, json, math, os, re
import subprocess, sys, time, traceback
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(os.environ.get('TS_ROOT', '/disk2/ANON/TrustScientist_AAMAS2027'))
sys.path.insert(0, str(ROOT))
from src.closure.audit import audit, binding_valid, answer_matches
from src.utils.prepare import artifact_text
from src.utils.common import CAPS

OUT = ROOT / 'releases/v2b_20260929'
METHODS = ['Direct', 'ReAct', 'Reflection', 'LLM Judge', 'Rubric verifier (adapted)',
           'Generic validator + recovery', 'TrustScientist', 'TrustScientist + closed loop',
           'Ablation: no semantic gate', 'Ablation: LLM action selector', 'Ablation: no hard gate']
SEEDS = [20270928, 20270929, 20270930]
MAX_CALLS = 6
MAX_OUTPUT = 1536
MODEL = 'trust-qwen3-8b-v2'
ENDPOINT = os.environ.get('TS_ENDPOINT', 'http://127.0.0.1:18229/v1')

def digest(x):
    return hashlib.sha256(x if isinstance(x, bytes) else str(x).encode()).hexdigest()

def readrows(p):
    return [json.loads(s) for s in p.read_text().splitlines() if s.strip()] if p.exists() else []

def dump(p, x):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(x, ensure_ascii=False, indent=2))

def write_rows(p, xs):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(''.join(json.dumps(x, ensure_ascii=False)+'\n' for x in xs))

def canonical(x):
    return json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

def public(c):
    # An allowlist is the only model-facing interface. Gold never leaves the evaluator.
    return {k: copy.deepcopy(c[k]) for k in ['task_id', 'cluster_id', 'question',
            'requirements', 'evidence', 'trusted_manifest']}

def terms(x):
    return re.findall(r'[a-z0-9][a-z0-9_-]+', x.lower())

STOP = set('report the a an of for with and from in on to is at by using name score average'.split())

def layout_text(p):
    """Preserve table rows and PDF columns; no reference-aware parsing."""
    if p.suffix.lower() in ['.html', '.htm']:
        if p.stat().st_size > 10_000_000:
            return ''
        from bs4 import BeautifulSoup
        s = BeautifulSoup(p.read_text(errors='replace'), 'html.parser')
        for t in s(['script', 'style']):
            t.decompose()
        table_rows = [' | '.join(cell.get_text(' ', strip=True) for cell in row.find_all(['th','td']))
                      for row in s.find_all('tr')]
        for t in s.find_all('table'):
            t.decompose()
        return '\n'.join(table_rows) + '\n' + s.get_text('\n', strip=True)
    return artifact_text(p)

def docs(cid, base=CAPS):
    target = (base / cid / 'results').resolve()
    cache = OUT / 'data/documents' / (digest(str(target))[:20]+'.json')
    if cache.exists():
        return json.loads(cache.read_text())
    result = []
    for p in sorted(target.rglob('*')):
        if not p.is_file():
            continue
        text = layout_text(p)
        if text.strip():
            result.append({'path':str(p), 'text':text[:1_000_000],
                           'source_sha256':digest(p.read_bytes())})
    dump(cache, result)
    return result

def retrieve(cid, question, query=None, offset=0, base=CAPS):
    vocabulary = Counter(w for w in terms(query or question) if w not in STOP)
    passages = []
    for d in docs(cid, base):
        text = d['text']
        for start in range(0, len(text), 1500):
            chunk = text[start:start+2600]
            counts = Counter(terms(chunk)); length = sum(counts.values())
            passages.append((d, start, chunk, counts, length))
    df = Counter()
    for _,_,_,counts,_ in passages:
        df.update(set(counts))
    avg = sum(p[4] for p in passages) / max(1, len(passages))
    scored = []
    for d, start, chunk, counts, length in passages:
        score = sum(math.log(1+(len(passages)-df[w]+.5)/(df[w]+.5)) *
                    counts[w]*2.2/(counts[w]+1.2*(.25+.75*length/max(avg,1)))
                    for w in vocabulary if counts[w])
        score += .2*len(set(terms(Path(d['path']).name)) & set(vocabulary))
        scored.append((score,d['path'],start,chunk,d['source_sha256']))
    ranked = sorted(scored, key=lambda p:(-p[0],p[1],p[2]))
    # Diversity avoids returning four nearly identical chunks from one file.
    selected=[]; per_doc=Counter()
    for p in ranked[offset:]:
        if per_doc[p[1]] >= 2:
            continue
        selected.append(p); per_doc[p[1]] += 1
        if len(selected) == 4:
            break
    ev=[]; manifest={}
    for score,path,start,text,source_hash in selected:
        eid=digest(path+str(start))[:16]
        e={'evidence_id':eid,'capsule_id':cid,'question':question,'text':text,
           'source_path':path,'source_sha256':source_hash,'content_sha256':digest(text),
           'receipt':{'status':'complete','stages':['read','normalize','extract'],
                      'operation':'query-only BM25 layout retrieval'},'retrieval_score':score}
        ev.append(e)
        manifest[eid]={k:e[k] for k in ['capsule_id','question','content_sha256','source_sha256']}
    return ev,manifest

def suggested_action(c, states):
    # Resolve the violated primitive; no gold/corruption_type/ref answer inspected.
    if any(not s['source_access'] for s in states.values()):
        return 'fetch_source'
    if any(not s['integrity_valid'] for s in states.values()):
        return 'refresh_source'
    if any(not s['binding_valid'] for s in states.values()):
        return 'rebind'
    if any(not s['extract_complete'] for s in states.values()):
        return 'resume_extract'
    return 'search'

def execute(c, request, phase, run_id):
    action=request.get('action'); before=digest(canonical(public(c)))
    observation={}; started=time.time()
    if action=='inspect':
        observation=next((e for e in c['evidence'] if e['evidence_id']==request.get('evidence_id')),
                         {'error':'unknown evidence_id'})
    elif action=='validate':
        ok,states=audit(c); observation={'structural_pass':ok,'obligation_states':states}
    elif action=='search':
        if not c.get('source_snapshot'):
            ev,man=retrieve(c['cluster_id'],c['question'],str(request.get('query') or c['question']),
                            int(request.get('offset',0)), Path(c.get('capsule_base',str(CAPS))))
            if ev:
                c['evidence']=ev; c['trusted_manifest']=man
                observation={'retrieved':ev,'rule':'question/query only; no reference answer'}
            else:
                observation={'error':'no readable text evidence; visual-only artifacts unresolved'}
        else:
            q=set(terms(str(request.get('query',c['question']))))
            observation={'retrieved':sorted(c['evidence'],
                key=lambda e:len(q & set(terms(e['text']))),reverse=True)[:2]}
    elif action in ['fetch_source','refresh_source','rebind','resume_extract']:
        if not c.get('source_snapshot'):
            observation={'error':'no immutable snippet snapshot; use search on original artifacts'}
        elif not c['trusted_manifest']:
            observation={'error':'no trusted source identity'}
        else:
            eid,m=next(iter(c['trusted_manifest'].items()))
            snapshot=(ROOT / c['source_snapshot']).resolve()
            allowed=(ROOT/'data/corebench/snapshots').resolve()
            if not snapshot.is_relative_to(allowed):
                raise ValueError('snapshot outside explicit allowed source directory')
            text=snapshot.read_text()
            if digest(text)!=m['content_sha256']:
                observation={'error':'immutable source no longer matches registered digest'}
            elif action in ['fetch_source','refresh_source']:
                c['evidence']=[{'evidence_id':eid,'capsule_id':m['capsule_id'],
                    'question':m['question'],'text':text,'content_sha256':digest(text),
                    'source_sha256':m['source_sha256'],'source_path':str(snapshot),
                    'receipt':{'status':'complete','stages':['read','normalize','extract'],
                        'operation':'read immutable published-artifact snapshot',
                        'scope':'artifact restoration; not a scientific model rerun'}}]
                observation={'read_path':str(snapshot),'read_sha256':digest(text),'restored':True}
            elif not c['evidence']:
                observation={'error':'no evidence to modify; fetch first'}
            elif action=='rebind':
                c['evidence'][0].update(capsule_id=m['capsule_id'],question=m['question'])
                observation={'identity_rebound':True,'source_read_sha256':digest(text)}
            elif digest(c['evidence'][0]['text'])!=digest(text):
                observation={'error':'content mismatch; refresh_source required'}
            else:
                c['evidence'][0]['receipt']={'status':'complete','stages':['read','normalize','extract'],
                    'operation':'reread and verify extraction against immutable source'}
                observation={'extraction_completed':True,'source_read_sha256':digest(text)}
    else:
        observation={'error':'unsupported action'}
    receipt={'request':request,'observation':copy.deepcopy(observation),
             'before_public_sha256':before,'after_public_sha256':digest(canonical(public(c))),
             'elapsed':time.time()-started,'phase':phase}
    dump(OUT/'receipts'/phase/run_id/(digest(canonical(receipt))[:20]+'.json'),receipt)
    return receipt

PROMPT = '''Complete the given scientific result-reporting obligation using published artifact evidence.
This does not establish a fresh scientific execution. An answer must match the requested metric,
dataset, method, split, aggregation and table row/column. Quote enough context to identify these;
a number that merely occurs somewhere is insufficient. If only a plot image is available, abstain.
DONE requires every requested obligation, literal supporting evidence, correct binding, a complete
extraction receipt and a trusted digest. You have no gold answers. The same evidence, tools and
budget are available to every method. Tools: inspect(evidence_id), validate(), search(query,offset),
fetch_source(), refresh_source(), rebind(), resume_extract(). Source actions restore published
artifacts and cannot rerun training. Return ONE JSON object. For a tool: {"action":"...",...}.
Use at most TWO distinct evidence bindings, each quote at most 400 characters; do not duplicate
the same quotation across overlapping evidence snippets. Keep reasoning within 40 words.
For a final answer: {"answer":number|string|null,"requirements":[exact question strings],
"declared_done":boolean,"final_status":"CLOSED|OPEN|ABSTAIN",
"evidence_bindings":[{"evidence_id":"...","question":"...","quote":"literal text"}],
"reasoning":"short"}. Never put an action in a final answer.'''

REVIEW = '''Independently verify this proposed report WITHOUT reference answers. Return JSON
{"verdict":"PASS|FAIL|UNRESOLVED","checks":{"requested_metric":boolean,
"dataset_method_split":boolean,"row_column_binding":boolean,"value_and_aggregation":boolean,
"sufficient_literal_context":boolean,"no_unresolved_conflict":boolean},"reason":"short"}.
All six checks must be established for PASS. A nearby unrelated number is not evidence.
Inspect row and column headings, metric labels, mean vs standard deviation, percent vs fraction,
and dataset/method identity. A truncated table without headers is UNRESOLVED. Do not guess.'''

class Client:
    def __init__(self, phase, run_id, seed):
        import requests
        self.session=requests.Session(); self.session.trust_env=False
        self.phase=phase; self.run_id=run_id; self.seed=seed; self.calls=[]; self.usage=Counter()
    def query(self,messages,purpose):
        if len(self.calls)>=MAX_CALLS:
            return {'declared_done':False,'final_status':'ABSTAIN','budget_exhausted':True}
        payload={'model':MODEL,'messages':messages,'temperature':0.0 if self.seed==SEEDS[0] else .2,
                 'seed':self.seed,'max_tokens':MAX_OUTPUT,'response_format':{'type':'json_object'},
                 'chat_template_kwargs':{'enable_thinking':False}}
        p=OUT/'api'/self.phase/self.run_id/(str(len(self.calls))+'.json')
        start=time.time()
        response=self.session.post(ENDPOINT+'/chat/completions',json=payload,timeout=240)
        response.raise_for_status(); r=response.json()
        dump(p,{'request':payload,'response':r,'elapsed':time.time()-start,'purpose':purpose})
        self.calls.append(str(p.relative_to(OUT)))
        self.usage.update({k:r.get('usage',{}).get(k,0) for k in
                          ['prompt_tokens','completion_tokens','total_tokens']})
        content=r['choices'][0]['message'].get('content') or ''
        try:
            obj=json.loads(content)
            if not isinstance(obj,dict):
                raise ValueError('JSON object required')
        except (ValueError,TypeError):
            obj={'parse_error':True,'declared_done':False,'final_status':'ABSTAIN','raw':content}
        return obj

def semantic(client,c,pred):
    return client.query([{'role':'system','content':REVIEW},
        {'role':'user','content':canonical({'bundle':public(c),'proposed_report':pred})}], 'semantic_review')

def semantic_pass(review):
    keys=['requested_metric','dataset_method_split','row_column_binding','value_and_aggregation',
          'sufficient_literal_context','no_unresolved_conflict']
    return review.get('verdict')=='PASS' and all(review.get('checks',{}).get(k) is True for k in keys)

def final_gate(c,pred,review,use_hard=True,use_semantic=True):
    structural,states=audit(c)
    req=pred.get('requirements',[])
    requirement_ok=isinstance(req,list) and all(q in req for q in c['requirements'])
    literal=binding_valid(pred,c)
    gate=(structural and literal and requirement_ok) if use_hard else True
    gate=gate and (semantic_pass(review) if use_semantic else True)
    return gate,{'structural_pass':structural,'states':states,'literal_binding':literal,
                'requirement_complete':requirement_ok,'semantic_pass':semantic_pass(review)}

def run_case(case,method,seed,phase):
    c=copy.deepcopy(case); run_id=digest(case['task_id']+method+str(seed))[:24]
    client=Client(phase,run_id,seed); trace=[]; rounds=[]; reviews=[]
    structural,states=audit(c)
    # This free, cheap diagnostic is shared with ALL baselines, not private to TrustScientist.
    initial={'bundle':public(c),'shared_structural_diagnostic':{'pass':structural,'states':states},
             'max_model_calls':MAX_CALLS,'max_output_tokens_per_call':MAX_OUTPUT,'max_tool_actions':3}
    style={'Direct':'Give a direct final report.', 'ReAct':'Use inspect/search/validate or restoration tools before finishing.',
           'Reflection':'Answer, then critically revise.', 'LLM Judge':'Propose a report; an independent judge will review it.',
           'Rubric verifier (adapted)':'Propose a report for iterative rubric-guided verification.'}.get(method,
           'Propose a report for obligation-based verification and artifact recovery.')
    messages=[{'role':'system','content':PROMPT+'\n'+style},
              {'role':'user','content':canonical(initial)}]
    pred=client.query(messages,'initial_report')
    if method=='ReAct':
        for tool_round in range(3):
            if pred.get('action') not in ['inspect','search','validate','fetch_source','refresh_source','rebind','resume_extract']:
                break
            receipt=execute(c,pred,phase,run_id); trace.append(receipt)
            messages.extend([{'role':'assistant','content':canonical(pred)},
                {'role':'user','content':canonical({'tool_observation':receipt,'bundle':public(c),
                    'instruction':'Return a final report now.' if tool_round==2 else 'Continue or report.'})}])
            pred=client.query(messages,'react_report')
    if method=='Reflection':
        for _ in range(3):
            messages.extend([{'role':'assistant','content':canonical(pred)},
              {'role':'user','content':'Critically check all obligations, metric/row/column context and conflicts; return a revised final report.'}])
            pred=client.query(messages,'reflection')
    if method in ['LLM Judge','Rubric verifier (adapted)']:
        iterations=1 if method=='LLM Judge' else 2
        for _ in range(iterations):
            review=semantic(client,c,pred); reviews.append(review)
            pred=client.query([{'role':'system','content':PROMPT},
                {'role':'user','content':canonical({'bundle':public(c),'previous_report':pred,
                    'independent_rubric_feedback':review,'instruction':'Revise or abstain. Return final report JSON.'})}],
                    'rubric_revision')
    initial_pred=copy.deepcopy(pred)
    gated=method in METHODS[5:]
    looped=method in METHODS[5:] and method!='TrustScientist'
    use_hard=method!='Ablation: no hard gate'
    use_semantic=method not in ['Generic validator + recovery','Ablation: no semantic gate']
    if gated:
        review={}
        if audit(c)[0] and binding_valid(pred,c) and use_semantic:
            review=semantic(client,c,pred); reviews.append(review)
        ok,state=final_gate(c,pred,review,use_hard,use_semantic)
        for rnd in range(1,3):
            if ok or not looped or len(client.calls)>=MAX_CALLS-1:
                break
            if not audit(c)[0]:
                selected=suggested_action(c,audit(c)[1])
                if method=='Ablation: LLM action selector':
                    choice=client.query([{'role':'system','content':'Choose one available corrective tool action; return its JSON request. Do not answer the scientific question.'},
                        {'role':'user','content':canonical({'bundle':public(c),'unresolved':state,
                            'previous_actions_and_errors':trace})}], 'llm_action_selection')
                    request=choice
                else:
                    request={'action':selected}
            else:
                # Retrieval expands context based solely on the question and verifier's objection.
                query=c['question']
                request={'action':'search','query':query,'offset':(rnd-1)*4}
            receipt=execute(c,request,phase,run_id); trace.append(receipt)
            pred=client.query([{'role':'system','content':PROMPT},
                {'role':'user','content':canonical({'bundle':public(c),'previous_report':pred,
                    'unresolved':state,'semantic_feedback':review,'executed_action':receipt,
                    'previous_actions_and_errors':trace,'instruction':'Resolve the objection or abstain; return final report.'})}],
                'recovery_report')
            review={}
            if use_semantic and audit(c)[0] and binding_valid(pred,c) and len(client.calls)<MAX_CALLS:
                review=semantic(client,c,pred); reviews.append(review)
            ok,state=final_gate(c,pred,review,use_hard,use_semantic)
            # Gold evaluation is downstream logging only; never used to choose/stop/repair.
            rounds.append({'round':rnd,'action':request,'gate_pass':ok,
                'declared_done':ok and pred.get('declared_done') is True,
                'gold_closed':audit(c)[0] and binding_valid(pred,c) and
                              answer_matches(pred.get('answer'),case['reference_values'])})
        if not ok:
            pred.update(declared_done=False,final_status='ABSTAIN' if audit(c)[0] else 'OPEN')
    if pred.get('action'):
        pred.update(declared_done=False,final_status='OPEN')
    done=pred.get('declared_done') is True
    factual=answer_matches(pred.get('answer'),case['reference_values'])
    gold=audit(c)[0] and binding_valid(pred,c) and factual
    req=pred.get('requirements',[]); req=req if isinstance(req,list) else []
    report={'task_id':case['task_id'],'cluster_id':case['cluster_id'],'cohort':case['cohort'],
            'method':method,'model':MODEL,'seed':seed,'phase':phase,
            'input_public_sha256':digest(canonical(public(case))),'declared_done':done,
            'gold_closed':gold,'false_closure':done and not gold,'safe_completion':done and gold,
            'answer_correct':factual,'literal_binding':binding_valid(pred,c),
            'final_status':'CLOSED' if done else pred.get('final_status','ABSTAIN'),
            'prediction':pred,'initial_prediction':initial_pred,'semantic_reviews':reviews,
            'tool_trace':trace,'recovery_rounds':rounds,'final_public_bundle':public(c),
            'api_calls':client.calls,'token_usage':dict(client.usage),
            'corruption_type':case.get('corruption_type','none'),
            'initial_structural_closed':audit(case)[0],
            'requirement_recall':sum(q in req for q in case['requirements'])/len(case['requirements']),
            'source_reexecution':False,'timestamp_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
    return report

def prepare():
    OUT.mkdir(parents=True,exist_ok=True)
    cases=[]
    for p in [ROOT/'data/clean_artifacts/clean.jsonl',ROOT/'data/corruptions/corrupted.jsonl']:
        for c in readrows(p):
            c['cohort']='controlled'; cases.append(c)
    natural=readrows(ROOT/'data/natural_failures/tasks.jsonl')
    for c in natural:
        # Fixed first-pass v1 retrieval enables direct cohort correspondence. Shared tools
        # permit layout-preserving source reads to every v2 method.
        c['cohort']='natural'; cases.append(c)
    for c in cases:
        c['original_task_id']=c['task_id']
        c['task_id']=c['cohort']+'/'+c['task_id']
    assert len(cases)==223 and len({c['task_id'] for c in cases})==223
    evaluator=[]; inputs=[]
    for c in cases:
        evaluator.append({'task_id':c['task_id'],'reference_values':c['reference_values'],
                          'corruption_type':c['corruption_type'],'cohort':c['cohort']})
        x={k:v for k,v in c.items() if k not in ['reference_values','gold_observed','gold_closed','gold_corruption_label','corruption_type']}
        inputs.append(x)
    protocol={'version':'v2b_20260929','primary_seed':SEEDS[0],'robustness_seeds':SEEDS[1:],
        'methods':METHODS,'primary_tasks':223,'controlled_tasks':144,'natural_tasks':79,
        'model':MODEL,'max_calls':MAX_CALLS,'max_output_tokens':MAX_OUTPUT,'max_tool_actions':3,
        'primary_temperature':0.0,'robustness_temperature':0.2,
        'primary_metric':'safe completion; report FCR and coverage jointly',
        'fcr':'sum(declared_done and not gold_closed)/sum(declared_done); undefined if no DONE',
        'bootstrap':'10000 resamples by capsule; paired methods share sampled capsules',
        'comparison_scope':'same-backbone artifact-reporting cohort, not official CORE-Bench agent leaderboard',
        'literature_baseline':'Rubric verifier is our prompt adaptation, not the official DeepVerifier implementation',
        'information_parity':'all methods see the same public bundle, structural diagnostic and tool catalog',
        'budget_parity':'common maximum budget; actual tokens are measured, not claimed exactly equal',
        'exposure':'v1 test outcomes inspected before v2; v2 is retrospective, not untouched held-out confirmation',
        'human_gold':'benchmark numeric/reference labels; no new independent semantic annotation',
        'sota_claim_allowed':False,
        'smoke_repair':'v2 smoke stopped before formal inference: 3 final JSON truncations. All methods receive a common 1536-token cap and concise output instruction; no acceptance criterion changed.',
        'source_hashes':{str(p.relative_to(ROOT)):digest(p.read_bytes()) for p in [
          ROOT/'data/clean_artifacts/clean.jsonl',ROOT/'data/corruptions/corrupted.jsonl',
          ROOT/'data/natural_failures/tasks.jsonl']},
        'public_sha256':digest(canonical(inputs)),'evaluator_sha256':digest(canonical(evaluator)),
        'implementation_sha256':digest(Path(__file__).read_bytes())}
    lock=OUT/'protocol.json'
    if lock.exists() and json.loads(lock.read_text())!=protocol:
        raise RuntimeError('Frozen v2 protocol changed; create a new release instead of overwriting')
    dump(lock,protocol); write_rows(OUT/'data/public_tasks.jsonl',inputs)
    write_rows(OUT/'data/evaluator_only.jsonl',evaluator)
    return cases

def preflight(cases):
    # CPU smoke precedes complete structural-recovery experiment. These are executed reads,
    # not LLM reports and not scientific retraining.
    smoke=[]; full=[]
    controlled=[c for c in cases if c['cohort']=='controlled' and c['corruption_type']!='clean']
    selected=[next(c for c in controlled if c['corruption_type']==name) for name in sorted({c['corruption_type'] for c in controlled})]
    for phase,pool,target in [('cpu_smoke',selected,smoke),('cpu_full',controlled,full)]:
        for original in pool:
            c=copy.deepcopy(original); history=[]; before=audit(c)[0]
            for rnd in range(2):
                ok,states=audit(c)
                if ok:
                    break
                request={'action':suggested_action(c,states)}
                history.append(execute(c,request,phase,digest(c['task_id'])[:24]))
            target.append({'task_id':c['task_id'],'cluster_id':c['cluster_id'],
                           'initial_structural_closed':before,'final_structural_closed':audit(c)[0],
                           'actions':history,'scope':'typed structural restoration only; no model answer or benchmark completion'})
        assert all(x['final_structural_closed'] for x in target)
    write_rows(OUT/'runs/cpu_smoke/structural_recovery.jsonl',smoke)
    write_rows(OUT/'runs/cpu_full/structural_recovery.jsonl',full)
    # Public-interface invariance under arbitrary changes to gold labels.
    for c in cases:
        mutated=copy.deepcopy(c)
        mutated.update(reference_values=['DO_NOT_EXPOSE_GOLD_SENTINEL'],gold_closed=False,
                       gold_observed=987654321,corruption_type='FAKE_EVALUATOR_LABEL')
        assert public(c)==public(mutated)
        assert suggested_action(c,audit(c)[1])==suggested_action(mutated,audit(mutated)[1])
    # Missing header/row identity must never pass a semantic validator by omission.
    assert not semantic_pass({'verdict':'PASS','checks':{'requested_metric':True}})
    assert not semantic_pass({'verdict':'UNRESOLVED','checks':{}})
    dump(OUT/'results/cpu_preflight.json',{'status':'PASS','structural_smoke_cases':len(smoke),
        'executed_structural_full_cases':len(full),'structural_restoration_successes':sum(x['final_structural_closed'] for x in full),
        'gold_invariance_cases':len(cases),'model_inference_done':False,'sota_claim_allowed':False})
    print('CPU PREFLIGHT PASS; executed structural restoration:',len(full),flush=True)

def model_smoke_cases(cases):
    result=[next(c for c in cases if c.get('corruption_type')==name) for name in
            ['clean','missing_evidence','wrong_binding','partial_execution','result_corruption','stale_or_conflicting_artifact']]
    result += [c for c in cases if c['cohort']=='natural'][:2]
    return result

def run(cases,methods,seeds,phase,workers):
    protocol_hash=digest((OUT/'protocol.json').read_bytes())
    for seed in seeds:
        jobs=[]
        for method in methods:
            path=OUT/'runs'/phase/str(seed)/(digest(method)[:16]+'.jsonl')
            saved=readrows(path); byid={r['task_id']:r for r in saved}
            if len(byid)!=len(saved):
                raise ValueError('duplicate saved record')
            current={c['task_id']:c for c in cases}
            for r in saved:
                if r['task_id'] not in current or r['protocol_sha256']!=protocol_hash or r['input_public_sha256']!=digest(canonical(public(current[r['task_id']]))):
                    raise RuntimeError('resume protocol/input mismatch')
            path.parent.mkdir(parents=True,exist_ok=True)
            for c in cases:
                if c['task_id'] not in byid:
                    jobs.append((c,method,path))
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
            pending={pool.submit(run_case,c,m,seed,phase):(c,m,p) for c,m,p in jobs}
            done_count=0
            for future in concurrent.futures.as_completed(pending):
                c,m,p=pending[future]
                try:
                    r=future.result()
                except Exception:
                    dump(OUT/'errors'/phase/(digest(c['task_id']+m+str(seed))+'.json'),
                         {'task_id':c['task_id'],'method':m,'seed':seed,'traceback':traceback.format_exc()})
                    raise
                r['protocol_sha256']=protocol_hash
                with p.open('a') as f:
                    f.write(json.dumps(r,ensure_ascii=False)+'\n'); f.flush()
                done_count+=1
                if done_count%10==0 or done_count==len(jobs):
                    print(phase,seed,done_count,'/',len(jobs),m,r['final_status'],flush=True)
        if phase=='smoke':
            outputs=[r for p in (OUT/'runs'/phase/str(seed)).glob('*.jsonl') for r in readrows(p)]
            assert len(outputs)==len(cases)*len(methods)
            parse_failures=sum(r['prediction'].get('parse_error',False) for r in outputs)
            assert parse_failures==0, 'model smoke parse failures; do not run full'
            api_parse_failures=0
            truncations=0
            for r in outputs:
                for api in r['api_calls']:
                    raw=json.loads((OUT/api).read_text())['response']['choices'][0]
                    truncations+=raw['finish_reason']=='length'
                    try:
                        assert isinstance(json.loads(raw['message'].get('content') or ''),dict)
                    except (ValueError,AssertionError):
                        api_parse_failures+=1
            assert api_parse_failures==0 and truncations==0,'all intermediate smoke responses must be complete structured JSON'
            assert all(len(r['api_calls'])<=MAX_CALLS and len(r['tool_trace'])<=3 for r in outputs)
            dump(OUT/'results/model_smoke.json',{'status':'PASS','samples':len(outputs),
                'actual_api_calls':sum(len(r['api_calls']) for r in outputs),
                'parse_failures':parse_failures,'api_parse_failures':api_parse_failures,
                'truncations':truncations,'seed':seed,'protocol_sha256':protocol_hash})

def validate_results(records):
    cases=prepare(); refs={c['task_id']:c['reference_values'] for c in cases}
    for r in records:
        done=r['prediction'].get('declared_done') is True
        gold=audit(r['final_public_bundle'])[0] and binding_valid(r['prediction'],r['final_public_bundle']) and answer_matches(r['prediction'].get('answer'),refs[r['task_id']])
        assert r['declared_done']==done and r['gold_closed']==gold
        assert r['safe_completion']==(done and gold) and r['false_closure']==(done and not gold)
        usage=Counter()
        for api in r['api_calls']:
            raw=json.loads((OUT/api).read_text()); req=raw['request']
            assert req['model']==MODEL and req['seed']==r['seed']
            assert 'reference_values' not in canonical(req['messages'])
            usage.update({k:raw['response'].get('usage',{}).get(k,0) for k in
                          ['prompt_tokens','completion_tokens','total_tokens']})
        assert dict(usage)==r['token_usage']
    return True

def summarize():
    import numpy as np
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    records=[r for p in (OUT/'runs/full').rglob('*.jsonl') for r in readrows(p)]
    if not records:
        return
    validate_results(records)
    groups=defaultdict(list)
    for r in records:
        groups[(r['seed'],r['cohort'],r['method'])].append(r)
    rows=[]; paired=[]
    rng=np.random.default_rng(20260929)
    for seed in sorted({r['seed'] for r in records}):
        for cohort in ['controlled','natural']:
            cluster_ids=sorted({r['cluster_id'] for r in records if r['seed']==seed and r['cohort']==cohort})
            if not cluster_ids:
                continue
            indices=rng.integers(0,len(cluster_ids),size=(10000,len(cluster_ids)))
            safe_samples={}
            for method in METHODS:
                rs=groups.get((seed,cohort,method),[])
                expected=144 if cohort=='controlled' else 79
                if len(rs)!=expected:
                    continue
                matrix=np.array([[sum(x['cluster_id']==cid for x in rs),
                    sum(x['declared_done'] for x in rs if x['cluster_id']==cid),
                    sum(x['false_closure'] for x in rs if x['cluster_id']==cid),
                    sum(x['safe_completion'] for x in rs if x['cluster_id']==cid)] for cid in cluster_ids],dtype=float)
                sampled=matrix[indices].sum(axis=1); totals=matrix.sum(axis=0)
                metrics={'coverage':(totals[1]/totals[0],sampled[:,1]/sampled[:,0]),
                         'safe_completion':(totals[3]/totals[0],sampled[:,3]/sampled[:,0]),
                         'fcr':(totals[2]/totals[1] if totals[1] else math.nan,
                                np.divide(sampled[:,2],sampled[:,1],out=np.full(10000,np.nan),where=sampled[:,1]!=0))}
                safe_samples[method]=metrics['safe_completion'][1]
                for metric,(estimate,samples) in metrics.items():
                    finite=samples[np.isfinite(samples)]
                    lo,hi=np.quantile(finite,[.025,.975]) if len(finite) else [math.nan,math.nan]
                    rows.append({'seed':seed,'cohort':cohort,'method':method,'metric':metric,
                       'estimate':estimate,'ci_low':lo,'ci_high':hi,'n':len(rs),
                       'done':int(totals[1]),'false_closures':int(totals[2]),'safe':int(totals[3]),
                       'mean_tokens':sum(r['token_usage'].get('total_tokens',0) for r in rs)/len(rs),
                       'mean_model_calls':sum(len(r['api_calls']) for r in rs)/len(rs),
                       'mean_tool_calls':sum(len(r['tool_trace']) for r in rs)/len(rs)})
            target='TrustScientist + closed loop'
            if target in safe_samples:
                for method,samples in safe_samples.items():
                    if method==target:
                        continue
                    diff=safe_samples[target]-samples
                    lo,hi=np.quantile(diff,[.025,.975])
                    a=groups[(seed,cohort,target)];b=groups[(seed,cohort,method)]
                    paired.append({'seed':seed,'cohort':cohort,'comparison':target+' vs '+method,
                        'metric':'safe_completion_difference','estimate':sum(r['safe_completion'] for r in a)/len(a)-sum(r['safe_completion'] for r in b)/len(b),
                        'ci_low':lo,'ci_high':hi})
    for name,data in [('summary.csv',rows),('paired_differences.csv',paired)]:
        if data:
            path=OUT/'results'/name;path.parent.mkdir(parents=True,exist_ok=True)
            with path.open('w',newline='') as f:
                w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
    write_rows(OUT/'results/samples.jsonl',records)
    primary=[r for r in rows if r['seed']==SEEDS[0]]
    lookup={(r['cohort'],r['method'],r['metric']):r for r in primary}
    tex=['\\begin{tabular}{llrrr}','\\toprule','Cohort & Method & FCR & Coverage & Safe completion \\\\','\\midrule']
    for cohort in ['controlled','natural']:
        for method in METHODS:
            if (cohort,method,'coverage') not in lookup:
                continue
            vals=[]
            for metric in ['fcr','coverage','safe_completion']:
                r=lookup[(cohort,method,metric)]
                vals.append('--' if not math.isfinite(r['estimate']) else f"{100*r['estimate']:.1f} [{100*r['ci_low']:.1f}, {100*r['ci_high']:.1f}]")
            tex.append(cohort+' & '+method.replace('&','\\&')+' & '+' & '.join(vals)+' \\\\')
    tex += ['\\bottomrule','\\end{tabular}']
    (OUT/'results/main_table.tex').write_text('\n'.join(tex)+'\n')
    fig,axes=plt.subplots(1,2,figsize=(10,4),constrained_layout=True)
    for ax,cohort in zip(axes,['controlled','natural']):
        for method in METHODS:
            key=(cohort,method,'coverage')
            if key not in lookup:
                continue
            x=lookup[key];y=lookup[(cohort,method,'fcr')]
            if math.isfinite(y['estimate']):
                ax.scatter(100*x['estimate'],100*y['estimate'],label=method,s=35)
        ax.set(xlabel='Coverage (%)',ylabel='False closure risk among DONE (%)',title=cohort.capitalize(),xlim=(-2,102),ylim=(-2,102));ax.grid(alpha=.2)
    axes[1].legend(fontsize=6,loc='upper left',bbox_to_anchor=(1,1))
    (OUT/'figures').mkdir(exist_ok=True)
    for suffix in ['pdf','svg','png']:
        fig.savefig(OUT/'figures'/('native_risk_coverage.'+suffix),dpi=300)
    plt.close(fig)
    complete=len(records)==len(METHODS)*223*len(SEEDS)
    dump(OUT/'results/status.json',{'records':len(records),'expected_all_seeds':len(METHODS)*223*len(SEEDS),
        'complete':complete,'validated':True,'sota_claim_allowed':False,
        'limitation':'comparison on retrospective local artifact cohort; external SOTA not established',
        'completed_groups':[(k,len(v)) for k,v in groups.items()]})
    print('validated summaries',len(records),'complete all seeds:',complete,flush=True)

def main():
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['prepare','preflight','smoke','full','summarize','pipeline'])
    p.add_argument('--workers',type=int,default=8);p.add_argument('--seeds',default=str(SEEDS[0]))
    p.add_argument('--methods',default='all');args=p.parse_args()
    cases=prepare()
    if args.stage=='prepare':
        print('frozen protocol, public223, evaluator223',flush=True);return
    if args.stage in ['preflight','pipeline']:
        preflight(cases)
    if args.stage=='preflight':
        return
    methods=METHODS if args.methods=='all' else [METHODS[int(i)] for i in args.methods.split(',')]
    seeds=[int(s) for s in args.seeds.split(',')]
    if args.stage in ['smoke','pipeline']:
        run(model_smoke_cases(cases),methods,[SEEDS[0]],'smoke',args.workers)
    if args.stage in ['full','pipeline']:
        smoke=OUT/'results/model_smoke.json'
        assert smoke.exists() and json.loads(smoke.read_text())['status']=='PASS','model smoke required before full'
        run(cases,methods,seeds,'full',args.workers);summarize()
    if args.stage=='summarize':
        summarize()

if __name__=='__main__':
    main()
