import controller,json
from pathlib import Path
r=controller.ROOT
cases=json.loads((r/'data/cases_with_private_labels.json').read_text())
for cid in sorted({c['cluster_id'] for c in cases}):
 controller.adapter.docs(cid)
print('Document caches prepared sequentially; frozen controller unchanged.',flush=True)
controller.run(False)
