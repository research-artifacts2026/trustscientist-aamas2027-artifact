import json, csv, collections, hashlib
from pathlib import Path
import numpy as np
ROOT=Path('/disk2/ANON/experiments/trustscientist_control_v1_20260929')
records=[json.loads(p.read_text()) for p in sorted((ROOT/'records/full').glob('*.json'))]
complete=json.loads((ROOT/'results/full_completed.json').read_text())
assert len(records)==complete['records']==1476
assert len({(x['task_id'],x['method'],x['budget']) for x in records})==len(records)
protocol=json.loads((ROOT/'protocol.json').read_text())
assert hashlib.sha256((ROOT/'code/controller.py').read_bytes()).hexdigest()==protocol['script_sha256']
for r in records:
 assert r['spent_cost_units']<=r['budget']
 assert r['spent_cost_units']==sum(a['charged_cost_units'] for a in r['actions'])
 assert len(r['actions'])<=4
 assert not r['declared_done'] or r['method'] in ['structured_LLM','without_risk_bound']
 assert not r['declared_done'] or all(r['final_state'].values())
 assert not r['successful_closure'] or r['gold_valid']
 assert not (r['successful_closure'] and r['false_termination'])
 assert len(r['evidence_versions'])==len(r['actions'])+1
groups=collections.defaultdict(list)
for r in records:groups[(r['cohort'],r['method'],r['budget'])].append(r)
rng=np.random.default_rng(20260929)
rows=[]
def mean(a):return float(np.mean(a)) if a else None
for (cohort,method,budget),rs in sorted(groups.items()):
 clusters=sorted({r['cluster_id'] for r in rs});by={c:[r for r in rs if r['cluster_id']==c] for c in clusters}
 row={'cohort':cohort,'method':method,'budget':budget,'n':len(rs),'capsules':len(clusters)}
 metrics=['declared_done','false_termination','successful_closure','candidate_closure_before_risk','candidate_correct']
 draws=rng.integers(0,len(clusters),(5000,len(clusters)))
 sizes=np.array([len(by[c]) for c in clusters]);den=sizes[draws].sum(axis=1)
 for k in metrics:
  counts=np.array([sum(x[k] for x in by[c]) for c in clusters]);ci=np.percentile(counts[draws].sum(axis=1)/den,[2.5,97.5])
  row[k]=int(counts.sum());row[k+'_rate']=float(counts.sum()/len(rs));row[k+'_ci95_low']=float(ci[0]);row[k+'_ci95_high']=float(ci[1])
 closed=[r for r in rs if r['declared_done']];success=[r for r in rs if r['successful_closure']]
 initial=[r for r in rs if not all(r['initial_state'].values())]
 row.update(selective_risk=mean([r['false_termination'] for r in closed]),
  initially_unresolved=len(initial),recovered=sum(r['successful_closure'] for r in initial),
  recovery_success=mean([r['successful_closure'] for r in initial]),
  mean_actions_to_closure=mean([r['actions_to_closure'] for r in success]),
  mean_cost_to_closure=mean([r['cost_to_closure'] for r in success]),
  mean_spent_cost=mean([r['spent_cost_units'] for r in rs]),
  mean_charged_tokens=mean([r['token_usage_charged'] for r in rs]),
  candidate_errors=sum(r['candidate_closure_before_risk'] and not r['gold_valid'] for r in rs))
 rows.append(row)
out=ROOT/'results'
(out/'summary.json').write_text(json.dumps(rows,indent=2))
with (out/'summary.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
keys={c['cache_key'] for r in records for c in r['model_receipts']}
apis={k:json.loads((ROOT/'api'/(k+'.json')).read_text()) for k in keys}
errors=collections.Counter(x['status'] for x in apis.values())
finish=collections.Counter(x.get('response',{}).get('choices',[{}])[0].get('finish_reason') for x in apis.values())
malformed=0
for x in apis.values():
 try:assert isinstance(json.loads(x['response']['choices'][0]['message']['content']),dict)
 except Exception:malformed+=1
audit={'records':len(records),'cases':len({r['task_id'] for r in records}),
 'capsules':len({r['cluster_id'] for r in records}),'actual_unique_model_requests':len(keys),
 'api_status':dict(errors),'finish_reasons':dict(finish),'malformed_model_json':malformed,
 'actual_tokens':sum(x.get('response',{}).get('usage',{}).get('total_tokens',0) for x in apis.values()),
 'actions_executed':sum(len(r['actions']) for r in records),
 'action_types':dict(collections.Counter(a['request']['action'] for r in records for a in r['actions'])),
 'cluster_bootstrap_repetitions':5000,'bootstrap_scope':'percentile interval for capsule resampling; a degenerate zero-error interval is not a population risk guarantee',
 'checks':['complete factorial','unique rollout keys','budget and action caps','risk gate','closure consistency','version logging','frozen script hash'],
 'definitions':{'false_termination':'closed and automated operational gold invalid / all cohort attempts',
 'successful_closure':'closed and automated operational gold valid / all cohort attempts',
 'recovery_success':'successful final closure / initially unresolved predicate states',
 'actions_and_cost_to_closure':'means among successful final closures only; undefined with no successes',
 'cost':'declared acquisition units, excludes model token price and is not wall time'}}
(out/'audit.json').write_text(json.dumps(audit,indent=2))
# Compact per-rollout outcomes suffice to recompute every reported count and bootstrap.
fields=['task_id','cluster_id','cohort','scenario','method','budget','declared_done','gold_valid','false_termination','successful_closure','candidate_closure_before_risk','candidate_correct','spent_cost_units','actions_to_closure','cost_to_closure','token_usage_charged','initial_state']
with (out/'outcomes.jsonl').open('w') as f:
 for r in records:f.write(json.dumps({k:r[k] for k in fields})+'\n')
traces=[r for r in records if r['method']=='without_risk_bound' and r['scenario']=='binding_and_receipt' and r['budget']==2 and r['successful_closure'] and len(r['actions'])>0]
if traces:(out/'worked_trace.json').write_text(json.dumps(traces[0],indent=2))
print(json.dumps(audit,indent=2))
for r in rows:
 if r['budget']==4:print(r['cohort'],r['method'],r['n'],r['declared_done'],r['false_termination'],r['successful_closure'],r['candidate_closure_before_risk'],r['candidate_errors'])
