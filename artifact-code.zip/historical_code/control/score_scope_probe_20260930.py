"""Separate evaluator: no controller, audit, binding, or certificate imports."""
import csv, hashlib, json, math, re
from pathlib import Path
import numpy as np
R=Path('/disk2/ANON/TrustScientist_AAMAS2027')
O=R/'releases/paired_scope_probe_20260930'
NUM=r'(?<![\w.])[-+]?(?:\d+\.\d+|\d+|\.\d+)(?:[eE][-+]?\d+)?'
def scalar(x):
    if isinstance(x,bool) or x is None:raise ValueError()
    s=str(x).strip().rstrip('%')
    try:y=float(s)
    except ValueError:
        if re.search(r'\b(not|incorrect|wrong|unknown|less|greater)\b',s,re.I):raise ValueError()
        ns=re.findall(NUM,s)
        if len(ns)!=1:raise ValueError()
        y=float(ns[0])
    if not math.isfinite(y):raise ValueError()
    return y
def reference_match(answer,refs):
    vals=[v for x in refs for v in (x if isinstance(x,list) else [x])]
    if answer is None:return False
    try:
        x=scalar(answer);targets=[float(v) for v in vals]
        lower,upper=min(targets),max(targets)
        margin=max(1e-5,.05*(upper-lower),.001*abs(lower))
        return lower-margin<=x<=upper+margin
    except (ValueError,TypeError):return any(' '.join(str(answer).lower().split())==' '.join(str(x).lower().split()) for x in vals)
def source_scores(row):
    bundle=row['public'];pred=row['prediction'];ev={e['evidence_id']:e for e in bundle['evidence']}
    integrity=True
    for e in ev.values():
        p=Path(e['source_path']);manifest=bundle['trusted_manifest'].get(e['evidence_id'],{})
        integrity &= p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==e['source_sha256']
        integrity &= hashlib.sha256(e['text'].encode()).hexdigest()==manifest.get('content_sha256')
        integrity &= e['capsule_id']==bundle['cluster_id'] and e['question']==bundle['question']
        integrity &= e.get('receipt',{}).get('status')=='complete'
    literal=False
    for b in pred.get('evidence_bindings',[]) if isinstance(pred.get('evidence_bindings'),list) else []:
        if not isinstance(b,dict):continue
        text=ev.get(b.get('evidence_id'),{}).get('text','');quote=b.get('quote','')
        if not isinstance(quote,str) or len(quote.strip())<3 or ' '.join(quote.split()) not in ' '.join(text.split()):continue
        try:
            a=scalar(pred.get('answer'))
            literal |= any(abs(float(n)-a)<=max(1e-5,.001*abs(a)) for n in re.findall(NUM,quote))
        except (TypeError,ValueError):literal |= pred.get('answer') is not None and str(pred['answer']).lower() in quote.lower()
    return bool(integrity and ev),bool(literal)
assert reference_match('98.3',[100]) is False
assert reference_match('100%',[100]) is True
assert reference_match(None,[0]) is False
assert reference_match('unknown 100',[100]) is False
assert reference_match('Lean DEM',['Lean DEM']) is True
assert reference_match('DEM',['Lean DEM']) is False
if __name__=='__main__':
    gold={'natural/'+c['task_id']:c for c in [json.loads(s) for s in (R/'data/natural_failures/tasks.jsonl').read_text().splitlines()]}
    rows=[json.loads(p.read_text()) for p in sorted((O/'records').glob('*.json'))]
    assert len(rows)==len(gold)==79 and {r['task_id'] for r in rows}==set(gold)
    scored=[]
    for r in rows:
        integrity,literal=source_scores(r)
        scored.append({'task_id':r['task_id'],'cluster_id':r['cluster_id'],'answer_match':reference_match(r['prediction'].get('answer'),gold[r['task_id']]['reference_values']),
                       'source_integrity':integrity,'literal_answer_support':literal,'semantic_fidelity':'unknown','gates':r['gates']})
    clusters=sorted({r['cluster_id'] for r in scored});rng=np.random.default_rng(20260930)
    samples=rng.integers(0,len(clusters),(10000,len(clusters)))
    methods=list(scored[0]['gates']);summary=[]
    for method in methods:
        by=np.array([[sum(r['gates'][method] and r['answer_match'] for r in scored if r['cluster_id']==c),
                      sum(r['gates'][method] and not r['answer_match'] for r in scored if r['cluster_id']==c),
                      sum(r['cluster_id']==c for r in scored)] for c in clusters])
        success,error,n=by.sum(axis=0);boot=by[samples].sum(axis=1)
        lo,hi=np.quantile(boot[:,:2]/boot[:,2,None],[.025,.975],axis=0)
        summary.append({'method':method,'attempts':int(n),'closed':int(success+error),'correct':int(success),'wrong':int(error),
                        'successful_closure':float(success/n),'false_termination':float(error/n),'selective_risk':float(error/(success+error)) if success+error else None,
                        'success_ci':[float(lo[0]),float(hi[0])],'false_ci':[float(lo[1]),float(hi[1])]})
    def contrast(a,b):
        vals=np.array([[sum((int(r['gates'][a])-int(r['gates'][b]))*int(r['answer_match']==target) for r in scored if r['cluster_id']==c) for target in [True,False]]+[sum(r['cluster_id']==c for r in scored)] for c in clusters])
        boots=vals[samples].sum(axis=1);ci=np.quantile(boots[:,:2]/boots[:,2,None],[.025,.975],axis=0)
        return {'a':a,'b':b,'delta_success':float(vals[:,0].sum()/79),'delta_false':float(vals[:,1].sum()/79),'delta_success_ci':ci[:,0].tolist(),'delta_false_ci':ci[:,1].tolist()}
    api=[json.loads((O/p).read_text()) for r in rows for p in r['api_calls']]
    out={'n':79,'capsules':len(clusters),'model_requests':len(api),'response_errors':sum('transport_error' in a for a in api),
         'parse_errors':sum(bool(r[x].get('parse_error')) for r in rows for x in ['prediction','review','proof']),
         'tokens':sum(r['usage'].get('total_tokens',0) for r in rows),'source_integrity_pass':sum(r['source_integrity'] for r in scored),
         'literal_support_pass':sum(r['literal_answer_support'] for r in scored),'semantic_unknown':79,
         'summary':summary,'paired':[contrast('scope_witness','answer_agreement'),contrast('scope_witness','structured_rubric')],
         'evaluator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (O/'scored.json').write_text(json.dumps(scored,indent=2));(O/'summary.json').write_text(json.dumps(out,indent=2))
    with (O/'summary.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
    print(json.dumps(out,indent=2))
