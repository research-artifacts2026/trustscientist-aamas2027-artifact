import csv
import hashlib
import json
import math
import os
import random
import re
import sys
import time
import urllib.error
import urllib.request
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "experiments" / "heldout_bundle_eval" / "results" / "final" / "decisions.csv"
EVAL_SCOPE = os.environ.get("DEEPSEEK_EVAL_SCOPE", "full").strip().lower()
if EVAL_SCOPE not in {"subset", "full"}:
    raise ValueError("DEEPSEEK_EVAL_SCOPE must be 'subset' or 'full'")
EXPECTED_CLEAN = 24 if EVAL_SCOPE == "subset" else 62
OUTDIR = Path(__file__).resolve().parent / (
    "results" if EVAL_SCOPE == "subset" else "results_full"
)
INPUT_JSONL = OUTDIR / "full_artifact_inputs.jsonl"
PRED_JSONL = OUTDIR / "full_artifact_deepseek_predictions.jsonl"
PRED_CSV = OUTDIR / "full_artifact_deepseek_predictions.csv"
SUMMARY_JSON = OUTDIR / "full_artifact_deepseek_summary.json"
SUMMARY_TEX = OUTDIR / "full_artifact_deepseek_table.tex"
TEXT_TEX = OUTDIR / "full_artifact_deepseek_text.tex"


SYSTEM_PROMPT = """You are an independent auditor deciding whether a research requirement may be closed using the currently available evidence.

A requirement may be CLOSED only if the supplied artifact is admissible and satisfies every mandatory condition. Semantic plausibility alone is insufficient.

Return:
- CLOSED if the current evidence satisfies the requirement;
- OPEN if a mandatory condition is missing or invalid;
- UNVERIFIABLE if the evidence cannot be reliably inspected.

Return JSON only with keys: state, confidence, failed_condition, reason.
"""


USER_TEMPLATE = """Claim:
{claim}

Requirement:
{requirement}

Requirement type:
{requirement_type}

Mandatory:
{mandatory}

Artifact manifest:
{artifact_manifest}

Semantic evidence:
{semantic_evidence}
"""


def read_rows():
    with SOURCE.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def boolish(value):
    return str(value).strip().lower() in {"1", "true", "yes"}


def build_records():
    rows = read_rows()
    clean_closed = [
        r for r in rows
        if r["condition"] == "clean" and boolish(r["full_reaudit_closed"])
    ]
    clean_closed.sort(key=lambda r: (r["capsule_id"], r["question"]))
    selected = clean_closed[:EXPECTED_CLEAN]
    selected_keys = {(r["capsule_id"], r["question"]) for r in selected}
    records = []
    for r in rows:
        key = (r["capsule_id"], r["question"])
        if key not in selected_keys:
            continue
        if r["condition"] != "clean" and r["condition"] not in {
            "missing", "wrong_type", "misbound", "stale", "wrong_relation"
        }:
            continue
        if r["condition"] == "clean" and not boolish(r["full_reaudit_closed"]):
            continue
        manifest = {
            "path": r["path"],
            "declared_value_type": r["value_type"],
            "exists": boolish(r["present"]),
            "type_ok": boolish(r["type_ok"]),
            "path_ok": boolish(r["path_ok"]),
            "digest": r["digest"],
            "observed_digest": r["observed_digest"],
            "digest_valid": r["digest"] == r["observed_digest"],
            "execution_status": "available_artifact" if boolish(r["present"]) else "missing_artifact",
            "extracted_value": r["observed"],
            "reference_values": r["reference_values"],
            "bound_question": r["bound_question"],
            "relation_ok_observed": boolish(r["relation_ok"]),
        }
        condition = r["condition"]
        gold_state = "CLOSED" if condition == "clean" else "OPEN"
        requirement_id = make_requirement_id(r["capsule_id"], r["question"])
        rec = {
            "record_id": f"{requirement_id}::{condition}",
            "task_id": r["capsule_id"],
            "requirement_id": requirement_id,
            "condition": condition,
            "claim": r["question"],
            "requirement": r["question"],
            "requirement_type": infer_requirement_type(condition),
            "mandatory": True,
            "artifact_manifest": manifest,
            "semantic_evidence": r["context"],
            "gold_state": gold_state,
            "trustscientist_state": "CLOSED" if boolish(r["full_reaudit_closed"]) else "OPEN",
            "expected_failed_condition": expected_failed_condition(condition),
        }
        records.append(rec)
    records.sort(key=lambda x: (x["requirement_id"], condition_order(x["condition"])))
    counts = Counter(r["condition"] for r in records)
    if counts["clean"] != EXPECTED_CLEAN:
        raise RuntimeError(
            f"expected {EXPECTED_CLEAN} clean records, found {counts['clean']}"
        )
    for cond in ["missing", "wrong_type", "misbound", "stale", "wrong_relation"]:
        if counts[cond] != EXPECTED_CLEAN:
            raise RuntimeError(
                f"expected {EXPECTED_CLEAN} {cond} records, found {counts[cond]}"
            )
    return records


def slug(text):
    s = re.sub(r"[^a-zA-Z0-9]+", "-", text.lower()).strip("-")
    return s[:80]


def make_requirement_id(capsule_id, question):
    legacy = f"{capsule_id}::{slug(question)}"
    if EVAL_SCOPE == "subset":
        return legacy
    digest = hashlib.sha256(question.encode("utf-8")).hexdigest()[:10]
    return f"{capsule_id}::{slug(question)[:64]}-{digest}"


def condition_order(cond):
    order = {"clean": 0, "missing": 1, "wrong_type": 2, "misbound": 3, "stale": 4, "wrong_relation": 5}
    return order.get(cond, 99)


def infer_requirement_type(condition):
    if condition in {"missing", "wrong_type", "misbound", "stale"}:
        return "AUTH"
    if condition == "wrong_relation":
        return "REL"
    return "SUFF"


def expected_failed_condition(condition):
    return {
        "clean": "none",
        "missing": "missing_artifact",
        "wrong_type": "wrong_type",
        "misbound": "wrong_path",
        "stale": "stale_digest",
        "wrong_relation": "wrong_relation",
    }[condition]


def write_inputs(records):
    OUTDIR.mkdir(parents=True, exist_ok=True)
    with INPUT_JSONL.open("w", encoding="utf-8") as f:
        for rec in records:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")


def request_json(url, api_key, payload, timeout=90):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def pick_model(api_key):
    # DeepSeek's OpenAI-compatible endpoint may not expose /models on all accounts,
    # so test concrete candidates by making a tiny JSON-only request.
    candidates = [
        os.environ.get("DEEPSEEK_MODEL", "").strip(),
        "deepseek-v4-flash",
        "deepseek-v4-pro",
        "deepseek-chat",
        "deepseek-reasoner",
    ]
    candidates = [c for c in candidates if c]
    last_error = None
    for model in candidates:
        try:
            payload = {
                "model": model,
                "messages": [
                    {"role": "system", "content": "Return JSON only."},
                    {"role": "user", "content": "{\"ok\": true}"},
                ],
                "temperature": 0,
                "response_format": {"type": "json_object"},
            }
            response = request_json("https://api.deepseek.com/chat/completions", api_key, payload, timeout=45)
            content = response["choices"][0]["message"]["content"]
            json.loads(content)
            return model
        except Exception as exc:
            last_error = exc
    raise RuntimeError(f"no DeepSeek model candidate succeeded: {last_error}")


def call_auditor(api_key, model, rec):
    user = USER_TEMPLATE.format(
        claim=rec["claim"],
        requirement=rec["requirement"],
        requirement_type=rec["requirement_type"],
        mandatory=str(rec["mandatory"]).lower(),
        artifact_manifest=json.dumps(rec["artifact_manifest"], ensure_ascii=False, indent=2),
        semantic_evidence=rec["semantic_evidence"][:2400],
    )
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user},
        ],
        "temperature": 0,
        "response_format": {"type": "json_object"},
    }
    response = request_json("https://api.deepseek.com/chat/completions", api_key, payload, timeout=90)
    content = response["choices"][0]["message"]["content"]
    parsed = parse_model_json(content)
    return {
        "raw_response": response,
        "content": content,
        "parsed": normalize_prediction(parsed),
    }


def parse_model_json(content):
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", content, flags=re.S)
        if not m:
            raise
        return json.loads(m.group(0))


def normalize_prediction(obj):
    state = str(obj.get("state", "")).upper().strip()
    if state not in {"CLOSED", "OPEN", "UNVERIFIABLE"}:
        state = "UNVERIFIABLE"
    try:
        confidence = float(obj.get("confidence", 0.0))
    except Exception:
        confidence = 0.0
    confidence = max(0.0, min(1.0, confidence))
    failed = str(obj.get("failed_condition", "other")).lower().strip()
    aliases = {
        "none": "none",
        "missing": "missing_artifact",
        "missing_artifact": "missing_artifact",
        "admissibility": "other",
        "wrong_type": "wrong_type",
        "type": "wrong_type",
        "wrong_path": "wrong_path",
        "path": "wrong_path",
        "misbound": "wrong_path",
        "stale": "stale_digest",
        "stale_digest": "stale_digest",
        "digest": "stale_digest",
        "wrong_relation": "wrong_relation",
        "relevance": "wrong_relation",
        "insufficient": "insufficient",
        "sufficiency": "insufficient",
        "other": "other",
    }
    failed = aliases.get(failed, failed if failed in set(aliases.values()) else "other")
    return {
        "state": state,
        "confidence": confidence,
        "failed_condition": failed,
        "reason": str(obj.get("reason", ""))[:500],
    }


def call_with_retries(api_key, model, rec):
    for attempt in range(4):
        try:
            out = call_auditor(api_key, model, rec)
            return {
                **rec,
                "model": model,
                "prediction": out["parsed"],
                "api_id": out["raw_response"].get("id"),
                "usage": out["raw_response"].get("usage", {}),
            }
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            if exc.code in {401, 402, 403, 404}:
                raise RuntimeError(
                    f"DeepSeek API error {exc.code}: {body[:500]}"
                ) from exc
            if attempt == 3:
                raise
            time.sleep(2 ** attempt)
        except Exception:
            if attempt == 3:
                raise
            time.sleep(2 ** attempt)


def run_calls(records, api_key, model):
    done = {}
    if PRED_JSONL.exists():
        with PRED_JSONL.open(encoding="utf-8") as f:
            for line in f:
                if not line.strip():
                    continue
                row = json.loads(line)
                done[row["record_id"]] = row
    pending = [
        (i, rec)
        for i, rec in enumerate(records, 1)
        if rec["record_id"] not in done
    ]
    workers = max(1, int(os.environ.get("DEEPSEEK_WORKERS", "8")))
    with PRED_JSONL.open("a", encoding="utf-8") as f:
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {
                pool.submit(call_with_retries, api_key, model, rec): (i, rec)
                for i, rec in pending
            }
            for future in as_completed(futures):
                i, rec = futures[future]
                row = future.result()
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
                f.flush()
                print(
                    f"[{i}/{len(records)}] {rec['condition']} "
                    f"{row['prediction']['state']}",
                    flush=True,
                )


def load_predictions():
    rows = []
    with PRED_JSONL.open(encoding="utf-8") as f:
        for line in f:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def is_closed(row):
    return row["prediction"]["state"] == "CLOSED"


def condition_match(row):
    expected = row["expected_failed_condition"]
    predicted = row["prediction"]["failed_condition"]
    if row["condition"] == "clean":
        return predicted == "none" or is_closed(row)
    return predicted == expected


def compute_metrics(rows):
    clean = [r for r in rows if r["condition"] == "clean"]
    corrupt = [r for r in rows if r["condition"] != "clean"]
    clean_closed = sum(is_closed(r) for r in clean)
    residual = sum(is_closed(r) for r in corrupt)
    clean_closed_ids = {r["requirement_id"] for r in clean if is_closed(r)}
    paired_candidates = [r for r in corrupt if r["requirement_id"] in clean_closed_ids]
    paired_sensitive = sum(not is_closed(r) for r in paired_candidates)
    localized = sum(condition_match(r) for r in corrupt)
    return {
        "n_clean": len(clean),
        "clean_closed": clean_closed,
        "clean_closure_rate": clean_closed / len(clean) if clean else math.nan,
        "n_corrupted": len(corrupt),
        "residual_closed": residual,
        "residual_closure_rate": residual / len(corrupt) if corrupt else math.nan,
        "paired_candidates": len(paired_candidates),
        "paired_sensitive": paired_sensitive,
        "paired_sensitivity": paired_sensitive / len(paired_candidates) if paired_candidates else math.nan,
        "localized": localized,
        "localization_accuracy": localized / len(corrupt) if corrupt else math.nan,
    }


def cluster_bootstrap(rows, n=5000, seed=13):
    rng = random.Random(seed)
    clusters = defaultdict(list)
    for row in rows:
        clusters[row["requirement_id"]].append(row)
    keys = list(clusters)
    samples = defaultdict(list)
    for _ in range(n):
        sample = []
        for key in keys:
            sample.extend(clusters[rng.choice(keys)])
        metrics = compute_metrics(sample)
        for name, value in metrics.items():
            if isinstance(value, float) and not math.isnan(value):
                samples[name].append(value)
    intervals = {}
    for name, vals in samples.items():
        vals.sort()
        lo = vals[int(0.025 * len(vals))]
        hi = vals[int(0.975 * len(vals)) - 1]
        intervals[name] = [lo, hi]
    return intervals


def write_outputs(rows, summary):
    fields = [
        "record_id", "task_id", "requirement_id", "condition", "gold_state",
        "trustscientist_state", "pred_state", "confidence", "failed_condition",
        "expected_failed_condition", "reason"
    ]
    with PRED_CSV.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for row in rows:
            p = row["prediction"]
            w.writerow({
                "record_id": row["record_id"],
                "task_id": row["task_id"],
                "requirement_id": row["requirement_id"],
                "condition": row["condition"],
                "gold_state": row["gold_state"],
                "trustscientist_state": row["trustscientist_state"],
                "pred_state": p["state"],
                "confidence": p["confidence"],
                "failed_condition": p["failed_condition"],
                "expected_failed_condition": row["expected_failed_condition"],
                "reason": p["reason"],
            })
    SUMMARY_JSON.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    write_latex(summary)


def pct(x):
    return f"{100*x:.1f}"


def ci_pct(ci):
    return f"[{100*ci[0]:.1f}, {100*ci[1]:.1f}]"


def write_latex(summary):
    m = summary["metrics"]
    ci = summary["cluster_bootstrap_95ci"]
    table = rf"""\begin{{table}}[t]
\centering
\small
\setlength{{\tabcolsep}}{{3.6pt}}
    \caption{{Full-artifact auditing on {m['n_clean']} clean requirements, with five paired corruptions per requirement. Both policies receive the same manifest fields and semantic evidence; DeepSeek-V4-Flash receives neither TrustScientist gate outputs nor gold states. Confidence intervals are clustered by requirement.}}
\label{{tab:full_artifact_deepseek}}
\begin{{tabular}}{{lccc}}
\toprule
Policy & Clean closed & Residual closure $\downarrow$ & Localization $\uparrow$ \\
\midrule
    DeepSeek-V4-Flash & {m['clean_closed']}/{m['n_clean']} & {m['residual_closed']}/{m['n_corrupted']} ({pct(m['residual_closure_rate'])}\%) & {m['localized']}/{m['n_corrupted']} ({pct(m['localization_accuracy'])}\%) \\
TrustScientist & {m['n_clean']}/{m['n_clean']} & 0/{m['n_corrupted']} & {m['n_corrupted']}/{m['n_corrupted']} \\
\bottomrule
\end{{tabular}}
\end{{table}}
"""
    SUMMARY_TEX.write_text(table, encoding="utf-8")
    text = rf"""\paragraph{{Full-artifact LLM auditor.}}
    We evaluate all {m['n_clean']} clean requirements closed by TrustScientist and pair each with five corrupted states. The DeepSeek-V4-Flash auditor receives the same claim, requirement, manifest fields, extracted value, digest status, execution status, and semantic evidence available to TrustScientist, but not TrustScientist gate outputs, gold states, or corruption labels. With no separate calibration split, we use fixed-prompt decisions without test-set threshold tuning.

    DeepSeek-V4-Flash closes {m['clean_closed']} of {m['n_clean']} clean requirements. Across the {m['n_corrupted']} corrupted states, it preserves closure for {m['residual_closed']} cases ({pct(m['residual_closure_rate'])}\%, 95\% CI {ci_pct(ci['residual_closure_rate'])}) and localizes {m['localized']} of {m['n_corrupted']} injected failures ({pct(m['localization_accuracy'])}\%, 95\% CI {ci_pct(ci['localization_accuracy'])}). TrustScientist closes the same clean states and preserves none of the corrupted closures, so the controlled artifact perturbation is not explained solely by giving a general-purpose model access to the manifest.
"""
    TEXT_TEX.write_text(text, encoding="utf-8")


def main():
    api_key = os.environ.get("DEEPSEEK_API_KEY", "").strip()
    if not api_key:
        print("DEEPSEEK_API_KEY is not set", file=sys.stderr)
        return 2
    records = build_records()
    write_inputs(records)
    model = pick_model(api_key)
    run_calls(records, api_key, model)
    rows = load_predictions()
    expected_predictions = EXPECTED_CLEAN * 6
    if len(rows) != expected_predictions:
        raise RuntimeError(
            f"expected {expected_predictions} predictions, found {len(rows)}"
        )
    metrics = compute_metrics(rows)
    intervals = cluster_bootstrap(rows)
    summary = {
        "schema": "trustscientist.full_artifact_deepseek_baseline.v1",
        "source": str(SOURCE),
        "model": model,
        "temperature": 0,
        "n_records": len(rows),
        "selection": (
            "all 62 clean full_reaudit_closed requirements with five paired "
            "corruptions each"
            if EVAL_SCOPE == "full"
            else "first 24 clean full_reaudit_closed requirements by "
                 "capsule_id/question, with five paired corruptions each"
        ),
        "metrics": metrics,
        "cluster_bootstrap_95ci": intervals,
        "no_calibration_split": True,
        "threshold_note": (
            "No calibration split is present for this paired test; results use "
            "fixed prompt decisions without test-set threshold tuning."
        ),
    }
    write_outputs(rows, summary)
    print(json.dumps(summary["metrics"], indent=2), flush=True)
    print(f"model={model}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
