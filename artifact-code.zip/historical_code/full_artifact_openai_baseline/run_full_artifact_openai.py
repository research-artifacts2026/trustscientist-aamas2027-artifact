import hashlib
import importlib.util
import json
import math
import os
import random
import sys
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DEEPSEEK_DIR = ROOT / "experiments" / "full_artifact_deepseek_baseline"
DEEPSEEK_RUNNER = DEEPSEEK_DIR / "run_full_artifact_deepseek.py"
INPUT_SOURCE = DEEPSEEK_DIR / "results_full" / "full_artifact_inputs.jsonl"
REASONING_EFFORT = os.environ.get("OPENAI_REASONING_EFFORT", "none").strip()
if REASONING_EFFORT not in {"none", "low", "medium", "high", "xhigh", "max"}:
    raise ValueError(f"unsupported OPENAI_REASONING_EFFORT={REASONING_EFFORT!r}")
DEFAULT_OUTDIR = (
    "results_full"
    if REASONING_EFFORT == "none"
    else f"results_full_{REASONING_EFFORT}"
)
OUTDIR = HERE / os.environ.get("OPENAI_OUTPUT_DIR", DEFAULT_OUTDIR).strip()
PRED_JSONL = OUTDIR / "full_artifact_openai_predictions.jsonl"
PRED_CSV = OUTDIR / "full_artifact_openai_predictions.csv"
SUMMARY_JSON = OUTDIR / "full_artifact_openai_summary.json"
SUMMARY_TEX = OUTDIR / "full_artifact_openai_table.tex"
TEXT_TEX = OUTDIR / "full_artifact_openai_text.tex"
MODEL = os.environ.get("OPENAI_MODEL", "gpt-5.6-sol").strip()
API_URL = "https://api.openai.com/v1/responses"


def load_deepseek_runner():
    os.environ["DEEPSEEK_EVAL_SCOPE"] = "full"
    spec = importlib.util.spec_from_file_location(
        "full_artifact_deepseek_runner", DEEPSEEK_RUNNER
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


BASE = load_deepseek_runner()


def load_records():
    records = []
    with INPUT_SOURCE.open(encoding="utf-8") as f:
        for line in f:
            if line.strip():
                records.append(json.loads(line))
    if len(records) != 372:
        raise RuntimeError(f"expected 372 input records, found {len(records)}")
    condition_counts = {}
    for row in records:
        condition_counts[row["condition"]] = condition_counts.get(row["condition"], 0) + 1
    expected = {
        "clean": 62,
        "missing": 62,
        "wrong_type": 62,
        "misbound": 62,
        "stale": 62,
        "wrong_relation": 62,
    }
    if condition_counts != expected:
        raise RuntimeError(f"unexpected condition counts: {condition_counts}")
    return records


def request_json(api_key, payload, timeout=120):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        API_URL,
        data=data,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def response_text(response):
    for item in response.get("output", []):
        if item.get("type") != "message":
            continue
        for content in item.get("content", []):
            if content.get("type") == "output_text":
                return content.get("text", "")
    raise RuntimeError("OpenAI response did not contain output_text")


def call_auditor(api_key, rec):
    user = BASE.USER_TEMPLATE.format(
        claim=rec["claim"],
        requirement=rec["requirement"],
        requirement_type=rec["requirement_type"],
        mandatory=str(rec["mandatory"]).lower(),
        artifact_manifest=json.dumps(
            rec["artifact_manifest"], ensure_ascii=False, indent=2
        ),
        semantic_evidence=rec["semantic_evidence"][:2400],
    )
    payload = {
        "model": MODEL,
        "reasoning": {"effort": REASONING_EFFORT},
        "input": [
            {"role": "system", "content": BASE.SYSTEM_PROMPT},
            {"role": "user", "content": user},
        ],
        "text": {
            "format": {
                "type": "json_schema",
                "name": "artifact_audit_decision",
                "strict": True,
                "schema": {
                    "type": "object",
                    "additionalProperties": False,
                    "properties": {
                        "state": {
                            "type": "string",
                            "enum": ["CLOSED", "OPEN", "UNVERIFIABLE"],
                        },
                        "confidence": {
                            "type": "number",
                            "minimum": 0,
                            "maximum": 1,
                        },
                        "failed_condition": {
                            "type": "string",
                            "enum": [
                                "none",
                                "missing_artifact",
                                "wrong_type",
                                "wrong_path",
                                "stale_digest",
                                "wrong_relation",
                                "insufficient",
                                "other",
                            ],
                        },
                        "reason": {"type": "string"},
                    },
                    "required": [
                        "state",
                        "confidence",
                        "failed_condition",
                        "reason",
                    ],
                },
            }
        },
        "store": False,
    }
    response = request_json(api_key, payload)
    parsed = BASE.normalize_prediction(json.loads(response_text(response)))
    return response, parsed


def call_with_retries(api_key, rec):
    for attempt in range(6):
        try:
            response, prediction = call_auditor(api_key, rec)
            return {
                **rec,
                "model_requested": MODEL,
                "model_returned": response.get("model"),
                "prediction": prediction,
                "api_id": response.get("id"),
                "usage": response.get("usage", {}),
            }
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            if exc.code in {400, 401, 402, 403, 404}:
                try:
                    detail = json.loads(body).get("error", {})
                    safe_detail = {
                        "type": detail.get("type"),
                        "code": detail.get("code"),
                        "param": detail.get("param"),
                        "message": str(detail.get("message", ""))[:300],
                    }
                except Exception:
                    safe_detail = {"message": "unparseable API error"}
                raise RuntimeError(
                    f"OpenAI API error {exc.code}: {safe_detail}"
                ) from exc
            if attempt == 5:
                raise
            time.sleep(min(30, 2 ** attempt + random.random()))
        except Exception:
            if attempt == 5:
                raise
            time.sleep(min(30, 2 ** attempt + random.random()))


def run_calls(records, api_key):
    OUTDIR.mkdir(parents=True, exist_ok=True)
    done = {}
    if PRED_JSONL.exists():
        with PRED_JSONL.open(encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    row = json.loads(line)
                    done[row["record_id"]] = row
    pending = [
        (i, rec)
        for i, rec in enumerate(records, 1)
        if rec["record_id"] not in done
    ]
    workers = max(1, int(os.environ.get("OPENAI_WORKERS", "6")))
    with PRED_JSONL.open("a", encoding="utf-8") as f:
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {
                pool.submit(call_with_retries, api_key, rec): (i, rec)
                for i, rec in pending
            }
            for future in as_completed(futures):
                i, rec = futures[future]
                row = future.result()
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
                f.flush()
                print(
                    f"[{i}/{len(records)}] {rec['condition']} "
                    f"{row['prediction']['state']}",
                    flush=True,
                )


def load_predictions():
    rows = []
    with PRED_JSONL.open(encoding="utf-8") as f:
        for line in f:
            if line.strip():
                rows.append(json.loads(line))
    rows.sort(key=lambda row: row["record_id"])
    return rows


def aggregate_usage(rows):
    totals = {}
    for row in rows:
        for key, value in row.get("usage", {}).items():
            if isinstance(value, (int, float)):
                totals[key] = totals.get(key, 0) + value
    return totals


def write_outputs(rows, summary):
    BASE.PRED_CSV = PRED_CSV
    BASE.SUMMARY_JSON = SUMMARY_JSON
    BASE.SUMMARY_TEX = SUMMARY_TEX
    BASE.TEXT_TEX = TEXT_TEX
    BASE.write_outputs(rows, summary)
    write_latex(summary)


def pct(value):
    return f"{100 * value:.1f}"


def ci_pct(interval):
    return f"[{100 * interval[0]:.1f}, {100 * interval[1]:.1f}]"


def write_latex(summary):
    metrics = summary["metrics"]
    ci = summary["cluster_bootstrap_95ci"]
    label = summary["paper_model_label"]
    table = rf"""\begin{{table}}[t]
\centering
\small
\setlength{{\tabcolsep}}{{3.4pt}}
\begin{{tabular}}{{lcc}}
\toprule
Policy & Clean closed & Residual closure $\downarrow$ \\
\midrule
DeepSeek-V4-Flash & 55/62 & 149/310 \\
{label} & {metrics['clean_closed']}/{metrics['n_clean']} & {metrics['residual_closed']}/{metrics['n_corrupted']} \\
TrustScientist & 62/62 & 0/310 \\
\bottomrule
\end{{tabular}}
\caption{{Full-artifact auditing on all 62 clean closures and five paired corruptions per requirement. All policies receive the same manifest fields and semantic evidence; the LLM baselines receive neither TrustScientist gate outputs nor gold states.}}
\label{{tab:deepseek}}
\end{{table}}
"""
    SUMMARY_TEX.write_text(table, encoding="utf-8")
    text = rf"""\noindent\textbf{{Full-artifact LLM baselines.}}
Both LLM auditors receive the same claim, requirement, manifest fields,
extracted value, digest and execution status, and semantic evidence, without
TrustScientist gate outputs or corruption labels.  {label} closes
{metrics['clean_closed']}/{metrics['n_clean']} clean requirements and preserves
closure for {metrics['residual_closed']}/{metrics['n_corrupted']} corruptions
({pct(metrics['residual_closure_rate'])}\%; requirement-clustered 95\% CI
${ci_pct(ci['residual_closure_rate'])}$).
"""
    TEXT_TEX.write_text(text, encoding="utf-8")


def main():
    api_key = os.environ.get("OPENAI_API_KEY", "").strip()
    if not api_key:
        print("OPENAI_API_KEY is not set", file=sys.stderr)
        return 2
    records = load_records()
    run_calls(records, api_key)
    rows = load_predictions()
    if len(rows) != len(records):
        raise RuntimeError(
            f"expected {len(records)} predictions, found {len(rows)}"
        )
    metrics = BASE.compute_metrics(rows)
    intervals = BASE.cluster_bootstrap(rows)
    returned_models = sorted(
        {row.get("model_returned") for row in rows if row.get("model_returned")}
    )
    input_sha256 = hashlib.sha256(INPUT_SOURCE.read_bytes()).hexdigest()
    summary = {
        "schema": "trustscientist.full_artifact_openai_baseline.v1",
        "input_source": str(INPUT_SOURCE.relative_to(ROOT)).replace("\\", "/"),
        "input_sha256": input_sha256,
        "model_requested": MODEL,
        "models_returned": returned_models,
        "paper_model_label": f"GPT-5.6-Sol ({REASONING_EFFORT})",
        "endpoint": "responses",
        "reasoning_effort": REASONING_EFFORT,
        "n_records": len(rows),
        "selection": (
            "all 62 clean full_reaudit_closed requirements with five paired "
            "corruptions each"
        ),
        "metrics": metrics,
        "cluster_bootstrap_95ci": intervals,
        "usage": aggregate_usage(rows),
        "no_calibration_split": True,
        "threshold_note": (
            "No calibration split is present for this paired test; results use "
            "fixed structured-output decisions without test-set threshold tuning."
        ),
    }
    write_outputs(rows, summary)
    print(json.dumps(metrics, indent=2), flush=True)
    print(f"model_requested={MODEL}", flush=True)
    print(f"models_returned={returned_models}", flush=True)
    print(f"reasoning_effort={REASONING_EFFORT}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
