#!/usr/bin/env python3
"""Download the frozen CORE-Bench test capsules from the official host."""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import os
import shutil
import subprocess
import tarfile
import tempfile
import urllib.request
from pathlib import Path

EXPECTED_DATASET_SHA256 = "b93d7fda4cba27a074c9717d89c7a0ffa5e0e197322cc27bcd1d3d8a5bedf8d4"
URL = "https://corebench.cs.princeton.edu/capsules/{capsule_id}.tar.gz"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def load_test_dataset(encrypted: Path) -> list[dict]:
    with tempfile.TemporaryDirectory() as temp_dir:
        clear = Path(temp_dir) / "core_test.json"
        subprocess.run(
            ["gpg", "--batch", "--yes", "--pinentry-mode", "loopback",
             "--passphrase", "reproducibility", "--output", str(clear),
             "--decrypt", str(encrypted)],
            check=True,
        )
        if sha256(clear) != EXPECTED_DATASET_SHA256:
            raise RuntimeError("CORE-Bench test manifest digest does not match the frozen protocol")
        return json.loads(clear.read_text())


def safe_extract(archive: Path, destination: Path) -> None:
    destination = destination.resolve()
    with tarfile.open(archive) as tf:
        for member in tf.getmembers():
            resolved = (destination / member.name).resolve()
            if destination != resolved and destination not in resolved.parents:
                raise RuntimeError(f"unsafe archive path: {member.name}")
        tf.extractall(destination)


def fetch(task: dict, capsule_root: Path) -> dict:
    capsule_id = task["capsule_id"]
    destination = capsule_root / capsule_id
    if destination.is_dir():
        return {"capsule_id": capsule_id, "status": "already_present"}
    archive = capsule_root / f"{capsule_id}.tar.gz"
    partial = archive.with_suffix(archive.suffix + ".partial")
    try:
        urllib.request.urlretrieve(URL.format(capsule_id=capsule_id), partial)
        os.replace(partial, archive)
        with tempfile.TemporaryDirectory(dir=capsule_root) as temp_dir:
            safe_extract(archive, Path(temp_dir))
            candidates = [p for p in Path(temp_dir).iterdir() if p.is_dir()]
            if len(candidates) != 1:
                raise RuntimeError(f"archive has {len(candidates)} top-level directories")
            shutil.move(str(candidates[0]), destination)
        return {
            "capsule_id": capsule_id,
            "status": "downloaded",
            "archive_sha256": sha256(archive),
            "archive_bytes": archive.stat().st_size,
        }
    except Exception as exc:
        partial.unlink(missing_ok=True)
        return {"capsule_id": capsule_id, "status": "failed", "error": repr(exc)}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--encrypted-dataset", type=Path, required=True)
    parser.add_argument("--capsule-root", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=6)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    tasks = load_test_dataset(args.encrypted_dataset)
    args.capsule_root.mkdir(parents=True, exist_ok=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        rows = list(pool.map(lambda task: fetch(task, args.capsule_root), tasks))
    report = {
        "schema": "trustscientist.corebench_test_download.v1",
        "source_url_template": URL,
        "dataset_sha256": EXPECTED_DATASET_SHA256,
        "n_expected": len(tasks),
        "n_available": sum(r["status"] in {"downloaded", "already_present"} for r in rows),
        "n_failed": sum(r["status"] == "failed" for r in rows),
        "capsules": rows,
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))
    return 1 if report["n_failed"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
