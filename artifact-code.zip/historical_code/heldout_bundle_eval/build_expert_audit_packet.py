#!/usr/bin/env python3
"""Build a blinded expert-audit packet from held-out bundle decisions."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import random
from collections import defaultdict
from pathlib import Path

SEED = 20260721
LABELS = ("authenticity", "relevance", "sufficiency", "discriminativeness", "overall_closure")


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def item_id(row: dict[str, str]) -> str:
    key = "|".join((row["capsule_id"], row["question"], row["condition"]))
    return "audit-" + hashlib.sha256(key.encode()).hexdigest()[:12]


def stratified_sample(rows: list[dict[str, str]], limit: int) -> list[dict[str, str]]:
    strata: dict[tuple[str, ...], list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        strata[(row["field"], row["language"], row["condition"], row["full_reaudit_closed"])].append(row)
    rng = random.Random(SEED)
    for group in strata.values():
        rng.shuffle(group)
    selected = []
    keys = sorted(strata)
    while len(selected) < min(limit, len(rows)) and keys:
        next_keys = []
        for key in keys:
            if strata[key] and len(selected) < limit:
                selected.append(strata[key].pop())
            if strata[key]:
                next_keys.append(key)
        keys = next_keys
    return sorted(selected, key=item_id)


def write_sheet(path: Path, items: list[dict[str, str]]) -> None:
    fields = ["item_id"] + list(LABELS) + ["confidence_1_to_5", "reason", "evidence_notes"]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        for row in items:
            writer.writerow({"item_id": item_id(row)})


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--decisions", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--limit", type=int, default=96)
    args = parser.parse_args()
    rows = read_rows(args.decisions)
    items = stratified_sample(rows, args.limit)
    args.output.mkdir(parents=True, exist_ok=True)

    public_fields = ["item_id", "field", "language", "question", "reference_values",
                     "condition", "observed", "value_type", "context", "artifact_basename"]
    with (args.output / "audit_items.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=public_fields, lineterminator="\n")
        writer.writeheader()
        for row in items:
            writer.writerow({
                "item_id": item_id(row), "field": row["field"], "language": row["language"],
                "question": row["question"], "reference_values": row["reference_values"],
                "condition": row["condition"], "observed": row["observed"],
                "value_type": row["value_type"], "context": row["context"],
                "artifact_basename": Path(row["path"]).name,
            })
    write_sheet(args.output / "annotator_a.csv", items)
    write_sheet(args.output / "annotator_b.csv", items)
    write_sheet(args.output / "adjudication.csv", items)

    key_fields = ["item_id", "capsule_id", "full_reaudit_closed", "full_reaudit_action",
                  "action_correct", "strict_reaudit_success"]
    with (args.output / "SYSTEM_KEY_DO_NOT_SHARE_WITH_ANNOTATORS.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=key_fields, lineterminator="\n")
        writer.writeheader()
        for row in items:
            writer.writerow({"item_id": item_id(row), **{k: row[k] for k in key_fields[1:]}})

    codebook = """# Expert audit codebook

Annotators must not open `SYSTEM_KEY_DO_NOT_SHARE_WITH_ANNOTATORS.csv`.
Label every gate `yes` or `no`; do not infer missing evidence.

- **authenticity**: the displayed evidence is attributable to the named artifact
  condition and has no indicated provenance/digest failure.
- **relevance**: the excerpt concerns the question's quantity or relation.
- **sufficiency**: the excerpt and reference range are enough to decide the
  requirement without unsupported assumptions.
- **discriminativeness**: the evidence distinguishes the requested relation from
  a plausible different metric, run, dataset, or claim.
- **overall_closure**: `yes` only if all four preceding gates are `yes`.

Use confidence 1 (guess) to 5 (very certain). Explain every `no`. Work
independently. After both sheets are frozen, an adjudicator reviews only
disagreements and records final labels in `adjudication.csv`.
"""
    (args.output / "CODEBOOK.md").write_text(codebook, encoding="utf-8")
    status = {
        "schema": "trustscientist.expert_audit_packet.v1",
        "status": "pending_two_independent_experts",
        "sampling_seed": SEED,
        "items": len(items),
        "blinded_system_key": "SYSTEM_KEY_DO_NOT_SHARE_WITH_ANNOTATORS.csv",
        "required_annotators": 2,
        "adjudication_required": True,
    }
    (args.output / "STATUS.json").write_text(json.dumps(status, indent=2))
    print(json.dumps(status, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
