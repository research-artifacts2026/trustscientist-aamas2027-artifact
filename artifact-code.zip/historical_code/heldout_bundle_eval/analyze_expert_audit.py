#!/usr/bin/env python3
"""Validate completed blinded sheets and score the adjudicated expert audit."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

LABELS = ("authenticity", "relevance", "sufficiency", "discriminativeness", "overall_closure")


def load(path: Path) -> dict[str, dict[str, str]]:
    with path.open(encoding="utf-8") as handle:
        return {row["item_id"]: row for row in csv.DictReader(handle)}


def binary(value: str) -> int:
    value = value.strip().lower()
    if value not in {"yes", "no"}:
        raise ValueError(f"expected yes/no, got {value!r}")
    return int(value == "yes")


def kappa(a: list[int], b: list[int]) -> float | None:
    if not a:
        return None
    observed = sum(x == y for x, y in zip(a, b)) / len(a)
    pa, pb = sum(a) / len(a), sum(b) / len(b)
    expected = pa * pb + (1 - pa) * (1 - pb)
    return None if expected == 1 else (observed - expected) / (1 - expected)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--packet", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    a = load(args.packet / "annotator_a.csv")
    b = load(args.packet / "annotator_b.csv")
    adjudicated = load(args.packet / "adjudication.csv")
    key = load(args.packet / "SYSTEM_KEY_DO_NOT_SHARE_WITH_ANNOTATORS.csv")
    if not (set(a) == set(b) == set(adjudicated) == set(key)):
        raise RuntimeError("item IDs differ across packet files")
    agreement = {}
    for label in LABELS:
        av = [binary(a[i][label]) for i in sorted(a)]
        bv = [binary(b[i][label]) for i in sorted(b)]
        agreement[label] = {
            "n": len(av), "raw_agreement": sum(x == y for x, y in zip(av, bv)) / len(av),
            "cohen_kappa": kappa(av, bv),
        }
    truth = [binary(adjudicated[i]["overall_closure"]) for i in sorted(key)]
    pred = [int(key[i]["full_reaudit_closed"]) for i in sorted(key)]
    tp = sum(p and y for p, y in zip(pred, truth)); fp = sum(p and not y for p, y in zip(pred, truth))
    fn = sum(not p and y for p, y in zip(pred, truth)); tn = sum(not p and not y for p, y in zip(pred, truth))
    result = {
        "schema": "trustscientist.expert_audit_results.v1", "status": "complete",
        "n": len(truth), "agreement": agreement,
        "full_vs_adjudicated": {
            "tp": tp, "fp": fp, "fn": fn, "tn": tn,
            "precision": tp / (tp + fp) if tp + fp else None,
            "recall": tp / (tp + fn) if tp + fn else None,
            "false_closure_rate": fp / (fp + tn) if fp + tn else None,
            "accuracy": (tp + tn) / len(truth),
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
