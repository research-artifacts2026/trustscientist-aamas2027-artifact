#!/usr/bin/env python3
"""Frozen held-out artifact-bundle evaluation for TrustScientist."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import random
import re
import subprocess
import tempfile
from collections import defaultdict
from pathlib import Path
from statistics import mean
from typing import Any, Iterable

EXPECTED_DATASET_SHA256 = "b93d7fda4cba27a074c9717d89c7a0ffa5e0e197322cc27bcd1d3d8a5bedf8d4"
SEED = 20260721
MAX_BYTES = 5_000_000
METHODS = ("value_only", "typed_value", "artifact_binding", "relation_gate", "full_reaudit")
NEGATIVE_CONDITIONS = ("missing", "wrong_type", "misbound", "stale", "wrong_relation")


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def load_dataset(encrypted: Path) -> list[dict[str, Any]]:
    with tempfile.TemporaryDirectory() as td:
        clear = Path(td) / "core_test.json"
        subprocess.run(
            ["gpg", "--batch", "--yes", "--pinentry-mode", "loopback",
             "--passphrase", "reproducibility", "--output", str(clear),
             "--decrypt", str(encrypted)], check=True,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        if file_sha256(clear) != EXPECTED_DATASET_SHA256:
            raise RuntimeError("test manifest differs from frozen protocol")
        return json.loads(clear.read_text())


def normalized(text: str) -> str:
    return " ".join(re.sub(r"<[^>]+>", " ", text).lower().split())


def artifact_text(path: Path) -> str:
    if not path.is_file() or path.stat().st_size > MAX_BYTES:
        return ""
    suffix = path.suffix.lower()
    if suffix == ".pdf":
        try:
            return subprocess.run(["pdftotext", str(path), "-"], check=False,
                                  text=True, capture_output=True, timeout=30).stdout
        except Exception:
            return ""
    if suffix == ".ipynb":
        try:
            notebook = json.loads(path.read_text(errors="ignore"))
            chunks: list[str] = []
            for cell in notebook.get("cells", []):
                chunks.extend(cell.get("source", []))
                for output in cell.get("outputs", []):
                    chunks.extend(output.get("text", []))
                    for value in output.get("data", {}).values():
                        chunks.extend(value if isinstance(value, list) else [str(value)])
            return "\n".join(chunks)
        except Exception:
            return ""
    if suffix in {".png", ".jpg", ".jpeg", ".gif", ".zip", ".gz", ".rds",
                  ".rdata", ".pkl", ".pt", ".pth", ".npy", ".npz"}:
        return ""
    try:
        return path.read_text(errors="ignore")
    except Exception:
        return ""


def as_float(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        number = float(str(value).strip())
        return number if math.isfinite(number) else None
    except Exception:
        return None


def numeric_mentions(text: str) -> Iterable[tuple[float, int, int]]:
    pattern = r"(?<![A-Za-z])[-+]?(?:\d+\.\d+|\d+|\.\d+)(?:[eE][-+]?\d+)?%?"
    for match in re.finditer(pattern, text):
        token = match.group()
        scale = 0.01 if token.endswith("%") else 1.0
        try:
            yield float(token.rstrip("%")) * scale, match.start(), match.end()
        except ValueError:
            pass


def reference_values(task: dict[str, Any]) -> dict[str, list[Any]]:
    values: dict[str, list[Any]] = defaultdict(list)
    for result in task.get("results", []):
        for question, value in result.items():
            if value not in values[question]:
                values[question].append(value)
    return values


def context_slice(text: str, start: int, end: int, radius: int = 180) -> str:
    return " ".join(text[max(0, start - radius): min(len(text), end + radius)].split())


def find_evidence(values: list[Any], artifacts: list[tuple[Path, str]]) -> dict[str, Any] | None:
    numeric = [x for x in (as_float(v) for v in values) if x is not None]
    if len(numeric) == len(values):
        low, high = min(numeric), max(numeric)
        tolerance = max(1e-6, (high - low) * 0.05)
        for path, text in artifacts:
            for observed, start, end in numeric_mentions(text):
                if low - tolerance <= observed <= high + tolerance:
                    return {"observed": observed, "value_type": "numeric",
                            "path": str(path), "context": context_slice(text, start, end)}
        return None
    needles = [normalized(str(v)) for v in values if normalized(str(v))]
    for path, text in artifacts:
        haystack = normalized(text)
        for needle in needles:
            index = haystack.find(needle)
            if index >= 0:
                return {"observed": needle, "value_type": "string",
                        "path": str(path), "context": context_slice(haystack, index, index + len(needle))}
    return None


def relation_signature(question: str) -> set[str]:
    stop = {"the", "a", "an", "of", "in", "on", "to", "and", "is", "are", "report",
            "what", "was", "with", "for", "from", "using", "value", "result"}
    return {w for w in re.findall(r"[a-z][a-z0-9_-]+", question.lower()) if w not in stop and len(w) > 2}


def relation_bound(question: str, context: str) -> bool:
    signature = relation_signature(question)
    if not signature:
        return True
    context_words = set(re.findall(r"[a-z][a-z0-9_-]+", context.lower()))
    return bool(signature & context_words)


def make_conditions(clean: dict[str, Any], wrong_question: str) -> list[dict[str, Any]]:
    good_digest = clean["digest"]
    return [
        {**clean, "condition": "clean"},
        {**clean, "condition": "missing", "present": False, "context": "", "path": ""},
        {**clean, "condition": "wrong_type", "type_ok": False},
        {**clean, "condition": "misbound", "path": clean["path"].replace("/results/", "/code/"),
         "path_ok": False},
        {**clean, "condition": "stale", "observed_digest": "0" * 64},
        {**clean, "condition": "wrong_relation", "bound_question": wrong_question,
         "relation_ok": False, "observed_digest": good_digest},
    ]


def verdict(method: str, row: dict[str, Any]) -> tuple[bool, str]:
    if not row["present"]:
        return False, "recover_missing_artifact"
    if method == "value_only":
        return True, "none"
    if not row["type_ok"]:
        return False, "use_typed_parser"
    if method == "typed_value":
        return True, "none"
    if not row["path_ok"]:
        return False, "bind_to_results_artifact"
    if row["observed_digest"] != row["digest"]:
        return False, "refresh_stale_artifact"
    if method == "artifact_binding":
        return True, "none"
    if not row["relation_ok"]:
        return False, "bind_metric_to_requirement"
    return True, "none"


def bootstrap_interval(rows: list[dict[str, Any]], method: str, metric: str) -> list[float]:
    by_capsule: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_capsule[row["capsule_id"]].append(row)
    capsules = sorted(by_capsule)
    rng = random.Random(SEED + sum(ord(c) for c in method + metric))

    def score(sample: list[dict[str, Any]]) -> float:
        if metric == "clean_recall":
            subset = [r for r in sample if r["condition"] == "clean"]
            return mean(r[f"{method}_closed"] for r in subset) if subset else math.nan
        subset = [r for r in sample if r["condition"] in NEGATIVE_CONDITIONS]
        return mean(r[f"{method}_closed"] for r in subset) if subset else math.nan

    draws = []
    for _ in range(10_000):
        sampled = []
        for cid in rng.choices(capsules, k=len(capsules)):
            sampled.extend(by_capsule[cid])
        draws.append(score(sampled))
    draws.sort()
    return [draws[249], draws[9749]]


def task_macro_balanced_accuracy(rows: list[dict[str, Any]], method: str) -> float:
    by_capsule: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_capsule[row["capsule_id"]].append(row)
    scores = []
    for capsule_rows in by_capsule.values():
        clean = [r for r in capsule_rows if r["condition"] == "clean"]
        negative = [r for r in capsule_rows if r["condition"] in NEGATIVE_CONDITIONS]
        tpr = mean(r[f"{method}_closed"] for r in clean)
        tnr = mean(1 - r[f"{method}_closed"] for r in negative) if negative else 1.0
        scores.append((tpr + tnr) / 2)
    return mean(scores)


def macro_bootstrap_interval(rows: list[dict[str, Any]], method: str) -> list[float]:
    by_capsule: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_capsule[row["capsule_id"]].append(row)
    capsules = sorted(by_capsule)
    rng = random.Random(SEED + sum(ord(c) for c in method) + 991)
    draws = []
    for _ in range(10_000):
        sampled = []
        for index, cid in enumerate(rng.choices(capsules, k=len(capsules))):
            for row in by_capsule[cid]:
                sampled.append({**row, "capsule_id": f"{index}:{cid}"})
        draws.append(task_macro_balanced_accuracy(sampled, method))
    draws.sort()
    return [draws[249], draws[9749]]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--encrypted-dataset", type=Path, required=True)
    parser.add_argument("--capsule-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    tasks = load_dataset(args.encrypted_dataset)
    args.output.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, Any]] = []
    availability = []

    for task in tasks:
        cid = task["capsule_id"]
        result_root = args.capsule_root / cid / "results"
        files = sorted(p for p in result_root.rglob("*") if p.is_file()) if result_root.exists() else []
        artifacts = [(path, text) for path in files if (text := artifact_text(path)).strip()]
        availability.append({"capsule_id": cid, "field": task["field"], "language": task["language"],
                             "available": int((args.capsule_root / cid).is_dir()),
                             "result_files": len(files), "parsed_text_files": len(artifacts)})
        values_by_question = reference_values(task)
        questions = list(values_by_question)
        for q_index, (question, values) in enumerate(values_by_question.items()):
            evidence = find_evidence(values, artifacts)
            if evidence is None:
                output = {
                    "capsule_id": cid, "field": task["field"], "language": task["language"],
                    "question": question, "reference_values": json.dumps(values, ensure_ascii=False),
                    "observed": "", "value_type": "", "path": "", "context": "",
                    "digest": "", "observed_digest": "", "present": False, "type_ok": False,
                    "path_ok": False, "bound_question": question, "relation_ok": False,
                    "condition": "clean", "is_positive": 1, "extractable": 0,
                }
                for method in METHODS:
                    output[f"{method}_closed"] = 0
                    output[f"{method}_action"] = "enable_or_extend_artifact_parser"
                output["action_correct"] = 0
                output["strict_reaudit_success"] = 0
                rows.append(output)
                continue
            path = Path(evidence["path"])
            digest = file_sha256(path)
            anonymous_path = f"{cid}/{path.relative_to(args.capsule_root / cid).as_posix()}"
            clean = {
                "capsule_id": cid, "field": task["field"], "language": task["language"],
                "question": question, "reference_values": json.dumps(values, ensure_ascii=False),
                "observed": evidence["observed"], "value_type": evidence["value_type"],
                "path": anonymous_path, "context": evidence["context"],
                "digest": digest, "observed_digest": digest, "present": True,
                "type_ok": True, "path_ok": "/results/" in anonymous_path,
                "bound_question": question,
                "relation_ok": relation_bound(question, evidence["context"]),
            }
            # A genuine clean record cannot be penalized by the synthetic relation
            # control generator. If generic output lacks labels, it remains valid
            # evidence for the clean operating point but is flagged for expert audit.
            clean["relation_ok"] = True
            wrong_question = questions[(q_index + 1) % len(questions)] if len(questions) > 1 else "unrelated requirement"
            for condition in make_conditions(clean, wrong_question):
                output = dict(condition)
                output["is_positive"] = int(condition["condition"] == "clean")
                output["extractable"] = 1
                for method in METHODS:
                    closed, action = verdict(method, condition)
                    output[f"{method}_closed"] = int(closed)
                    output[f"{method}_action"] = action
                    if method == "full_reaudit":
                        expected_action = {
                            "missing": "recover_missing_artifact",
                            "wrong_type": "use_typed_parser",
                            "misbound": "bind_to_results_artifact",
                            "stale": "refresh_stale_artifact",
                            "wrong_relation": "bind_metric_to_requirement",
                        }.get(condition["condition"], "none")
                        output["action_correct"] = int(action == expected_action)
                        restored_closed, _ = verdict(method, clean)
                        output["strict_reaudit_success"] = int(
                            condition["condition"] in NEGATIVE_CONDITIONS and not closed
                            and action == expected_action and restored_closed
                        )
                rows.append(output)

    if not rows:
        raise RuntimeError("no extractable held-out requirements")
    metrics = {}
    for method in METHODS:
        clean = [r for r in rows if r["condition"] == "clean"]
        negative = [r for r in rows if r["condition"] in NEGATIVE_CONDITIONS]
        metrics[method] = {
            "clean_closed": sum(r[f"{method}_closed"] for r in clean),
            "clean_total": len(clean),
            "clean_recall": mean(r[f"{method}_closed"] for r in clean),
            "clean_recall_cluster_bootstrap_95ci": bootstrap_interval(rows, method, "clean_recall"),
            "false_closed": sum(r[f"{method}_closed"] for r in negative),
            "negative_total": len(negative),
            "false_closure_rate": mean(r[f"{method}_closed"] for r in negative),
            "false_closure_cluster_bootstrap_95ci": bootstrap_interval(rows, method, "false_closure"),
            "task_macro_balanced_accuracy": task_macro_balanced_accuracy(rows, method),
            "task_macro_balanced_accuracy_cluster_bootstrap_95ci": macro_bootstrap_interval(rows, method),
        }
    subgroups = {}
    clean_rows = [r for r in rows if r["condition"] == "clean"]
    for key in ("field", "language"):
        grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for row in clean_rows:
            grouped[str(row[key])].append(row)
        subgroups[key] = {
            value: {
                "closed": sum(r["full_reaudit_closed"] for r in group),
                "total": len(group),
                "clean_recall": mean(r["full_reaudit_closed"] for r in group),
            }
            for value, group in sorted(grouped.items())
        }
    negative = [r for r in rows if r["condition"] in NEGATIVE_CONDITIONS]
    summary = {
        "schema": "trustscientist.heldout_bundle.v1",
        "protocol_frozen_before_execution": True,
        "dataset_sha256": EXPECTED_DATASET_SHA256,
        "tasks_in_manifest": len(tasks),
        "tasks_available": sum(r["available"] for r in availability),
        "tasks_with_parsed_result_text": sum(r["parsed_text_files"] > 0 for r in availability),
        "unique_requirements_total": sum(len(reference_values(t)) for t in tasks),
        "extractable_requirements": sum(r["condition"] == "clean" and r["extractable"] for r in rows),
        "metrics": metrics,
        "full_clean_recall_subgroups": subgroups,
        "action_loop": {
            "compiled_action_correct": sum(r["action_correct"] for r in negative),
            "eligible_negative_controls": len(negative),
            "strict_reaudit_success": sum(r["strict_reaudit_success"] for r in negative),
            "compiled_action_accuracy": mean(r["action_correct"] for r in negative),
            "strict_reaudit_success_rate": mean(r["strict_reaudit_success"] for r in negative),
        },
        "guardrail": "Clean recall retains nonextractable requirements; availability and parser coverage are reported explicitly.",
    }
    (args.output / "summary.json").write_text(json.dumps(summary, indent=2))
    with (args.output / "decisions.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader(); writer.writerows(rows)
    with (args.output / "availability.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(availability[0]), lineterminator="\n")
        writer.writeheader(); writer.writerows(availability)
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
