from pathlib import Path
import sys,tempfile,json,unittest,ast,re,copy
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'implementation'))
from researchclaw.pipeline.counterfactual_revalidation import *
# Exercise actual existing decision parser, extracted without optional model dependencies.
source=(BASE/'legacy_decision_parser.py').read_text()
tree=ast.parse(source)
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_parse_decision')
ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'_analysis.py','exec'),ns)
def route_policy(root,bindings,context):
    return ns['_parse_decision']((root/bindings[0]).read_text())
class Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.store=Store(self.root,{'route':route_policy})
    def tearDown(self):self.tmp.cleanup()
    def add(self,name,action):
        (self.root/name).write_text('## Decision\n'+action.upper())
        output='outputs/'+name;atomic(self.root/output,{'action':action})
        return self.store.record('route',[name],{},action,[output],{'last_completed_stage':14,'index':len(self.store.state()['active'])})
    def test_earliest_multi_flip_and_persistence(self):
        self.add('a','proceed');self.add('b','refine');self.add('c','pivot')
        (self.root/'b').write_text('PIVOT');(self.root/'c').write_text('PROCEED')
        r=self.store.revalidate()
        self.assertEqual(r['rollback_index'],1)
        self.assertEqual(len(r['replayed']),1)
        self.assertTrue((self.root/'outputs/a').exists());self.assertFalse((self.root/'outputs/b').exists())
        s=Store(self.root,{'route':route_policy}).state();self.assertEqual(len(s['active']),1)
        self.assertEqual(json.loads((self.root/'checkpoint.json').read_text())['index'],1)
    def test_unchanged_action_refresh_then_no_replay(self):
        self.add('a','proceed');(self.root/'a').write_text('## Decision\nPROCEED\n\nUpdated explanation')
        r=self.store.revalidate();self.assertIsNone(r['rollback_index']);self.assertEqual(len(r['replayed']),1)
        self.assertEqual(self.store.revalidate()['replayed'],[])
    def test_unrelated(self):
        self.add('a','proceed');(self.root/'unrelated').write_text('x')
        self.assertEqual(self.store.revalidate()['replayed'],[])
    def test_missing_and_budget_fail_closed(self):
        self.add('a','proceed');(self.root/'a').unlink()
        self.assertTrue(self.store.revalidate()['blocked'])
        self.assertTrue(self.store.state()['blocked'])
    def test_zero_budget(self):
        self.add('a','proceed');(self.root/'a').write_text('REFINE')
        self.assertTrue(self.store.revalidate(budget=0)['blocked'])
        self.assertTrue((self.root/'outputs/a').exists())
    def test_policy_change_blocked(self):
        self.add('a','proceed')
        other=Store(self.root,{})
        self.assertTrue(other.revalidate()['blocked'])
    def test_bad_receipt_and_escape(self):
        rid=self.add('a','proceed');p=self.store.home/'receipts'/(rid+'.json')
        p.write_text('{}')
        with self.assertRaises(ValueError):self.store.revalidate()
        with self.assertRaises(ValueError):safe(self.root,'../escape')
    def test_requirements_rule_matches_original_boundary(self):
        self.assertEqual(requirements_action('reject',0,1),'refine')
        self.assertEqual(requirements_action('reject',1,1),'proceed')
        self.assertEqual(requirements_action('accept',0,1),'proceed')
    def test_real_stage15_snapshot(self):
        atomic(self.root/'stage-16/paper.json',{'old':True})
        rid=snapshot_requirements_decision(self.root,{'verdict':'proceed'},0,1,'proceed')
        st=Store(self.root,{'stage15_requirements':verdict_policy});r=st.receipt(rid)
        atomic(self.root/r['bindings'][0],{'verdict':'reject'})
        result=st.revalidate();self.assertEqual(result['rollback_index'],0)
        self.assertFalse((self.root/'stage-16').exists())
        self.assertEqual(json.loads((self.root/'checkpoint.json').read_text())['last_completed_stage'],14)
    def test_recovery_prepared_rollback(self):
        self.add('a','proceed');s=self.store.state();s['blocked']=True
        s['pending_rollback']={'id':'test','outputs':['outputs/a'],'checkpoint':{'last_completed_stage':14},'earliest_receipt':s['active'][0],'invalidated':s['active']}
        s['active']=[];atomic(self.store.state_path,s)
        st=Store(self.root,{'route':route_policy});st.revalidate()
        self.assertFalse((self.root/'outputs/a').exists());self.assertFalse(st.state()['blocked'])
if __name__=='__main__':unittest.main(verbosity=2)
