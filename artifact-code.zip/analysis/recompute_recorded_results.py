"""Offline count checks. No inference, model endpoint or external dataset needed."""
from pathlib import Path
import csv,json,math
R=Path(__file__).resolve().parents[1]
D=json.loads((R/'visualizations/verified_results.json').read_text())
def js(n):return json.loads((R/n).read_text(encoding='utf-8'))
def jl(n):return [json.loads(s) for s in (R/n).read_text(encoding='utf-8').splitlines() if s.strip()]
def cr(n):return list(csv.DictReader((R/n).open(encoding='utf-8-sig')))
raw=js('recorded_results/records.json');assert len(raw)==405
flips=[r for r in raw if r['oracle_rollback'] is not None]
for row in D['cbr']:
 m=row['method'];assert len(flips)==row['flip_events']
 assert sum(r['methods'][m]['report']['rollback_index']==r['oracle_rollback'] for r in flips)==row['exact_rollback_on_flip']
 assert sum(r['methods'][m]['wrong_actions_retained'] for r in raw)==row['wrong_actions_retained']
 assert sum(len(r['methods'][m]['report'].get('replayed',[])) for r in raw)==row['decision_replays']
rows=js('evidence/certificate/scored.json');assert len(rows)==2025
for row in D['dynamic']['methods']:
 selected=[r for r in rows if r['method']==row['method']]
 for key in ['stale_closed','stale_opportunities','valid_closed','valid','checks']:assert sum(r[key] for r in selected)==row[key]
rows=js('evidence/scope/scored.json');assert len(rows)==79
for row in D['scope_gates']['summary']:
 picked=[r for r in rows if r['gates'][row['method']]]
 assert len(picked)==row['closed'] and sum(r['answer_match'] for r in picked)==row['correct']
rows=jl('evidence/acquisition/outcomes.jsonl')
for row in D['acquisition_budget4']:
 picked=[r for r in rows if r['method']==row['method'] and r['cohort']==row['cohort'] and r['budget']==4]
 assert len(picked)==row['attempts']
 assert sum(r['successful_closure'] for r in picked)==row['correct']
 assert sum(r['false_termination'] for r in picked)==row['wrong']
guard=[r for r in rows if r['method']=='ECC' and r['budget']==4]
assert len(guard)==D['guarded_acquisition_budget4']['attempts'] and sum(r['declared_done'] for r in guard)==D['guarded_acquisition_budget4']['closed']
for cohort in ['natural','controlled_multi']:
 def states(method):return {r['task_id']:(r['declared_done'],r['gold_valid']) for r in rows if r['cohort']==cohort and r['method']==method and r['budget']==4}
 assert states('without_risk_bound')==states('structured_LLM')
for row in D['manifest'][:2]:
 name='gpt' if row['method']=='GPT-5.6-Sol' else 'deepseek';rows=jl('evidence/manifest/'+name+'.jsonl')
 assert len(rows)==372 and len({r['record_id'] for r in rows})==372
 assert sum(r['condition']=='clean' and r['prediction']['state']=='CLOSED' for r in rows)==row['clean_closed']
 assert sum(r['condition']!='clean' and r['prediction']['state']=='CLOSED' for r in rows)==row['corrupt_closed']
rows=cr('evidence/manifest/decisions.csv');assert sum(r['condition']=='clean' for r in rows)==79
assert sum(r['condition']=='clean' and r['full_reaudit_closed']=='1' for r in rows)==62
assert sum(r['condition']!='clean' and r['full_reaudit_closed']=='1' for r in rows)==0
for row in D['fresh_execution']:
 rows=cr(f"evidence/fresh/run-{row['run']:02d}.csv")
 assert len(rows)==row['n_tasks']
 assert sum(int(r['strict_e2e_success']) for r in rows)==row['strict_success']
 assert sum(int(r['initial_closed']) for r in rows)==row['fresh_question_matches']
rows=cr('evidence/scifact/repeated_predictions.csv');assert len(rows)==1695
def check(rows,column,metric):
 assert len(rows)==metric['n']
 assert sum(r['gold']=='NEI' for r in rows)==metric['gold_nei']
 assert sum(r[column]!='NEI' for r in rows)==metric['closures']
 assert sum(r['gold']=='NEI' and r[column]!='NEI' for r in rows)==metric['false_nei_closures']
 assert sum(r['gold']!='NEI' and r[column]==r['gold'] for r in rows)==metric['correct_relation_closures']
 assert sum(r['gold']!='NEI' and r[column]!='NEI' and r[column]!=r['gold'] for r in rows)==metric['wrong_relation_closures']
for run in range(1,6):
 subset=[r for r in rows if r['run_id']==str(run)]
 for name,metric in D['scifact_operating_points'].items():
  if name not in ['mondrian_90','risk_control_20']:check(subset,name,metric)
check(cr('evidence/scifact/mondrian_predictions.csv'),'prediction',D['scifact_operating_points']['mondrian_90'])
check(cr('evidence/scifact/risk_control_predictions.csv'),'prediction',D['scifact_operating_points']['risk_control_20'])
pilot=js('evidence/disambiguation/summary.json')
for method in D['disjoint_acquisition']:
 row=next(r for r in pilot['summary'] if r['method']==method['method'])
 for k in ['attempts','correct_closed','wrong_closed','initial_wrong_answers','recovered_wrong_answers']:assert row[k]==method[k]
print('PASS: branch, certificate, scope, acquisition, manifest, fresh execution and SciFact recorded counts. No inference run.')
