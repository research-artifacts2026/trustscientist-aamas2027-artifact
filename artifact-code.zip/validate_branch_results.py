from pathlib import Path
import json,hashlib,sys,collections
b=Path(__file__).resolve().parent
rows=json.loads((b/'records.json').read_text());cases=json.loads((b/'cases.json').read_text())
protocol=json.loads((b/'protocol.json').read_text())
def sha(x):return hashlib.sha256(x).hexdigest()
assert sha((b/'run_branch_experiment.py').read_bytes())==protocol['runner_hash']
assert sha((b/'implementation/researchclaw/pipeline/counterfactual_revalidation.py').read_bytes())==protocol['engine_hash']
assert sha((b/'legacy_dependency_tracker.py').read_bytes())==protocol['tracker_hash']
assert len(rows)==sum(len(c['events']) for c in cases)
case_map={c['id']:c for c in cases};source=b/'data'
count=collections.Counter()
for c in cases:
    blobs={f:(source/'originals'/c['id']/f).read_bytes() for f in c['files']}
    def oracle():
        return ['proceed' if q['base_pass'] and all(sha(blobs[f])==c['files'][f]['expected_sha256'] for f in q['required_files']) else 'refine' for q in c['claims']]
    for ei,event in enumerate(c['events']):
        row=next(r for r in rows if r['capsule']==c['id'] and r['event_index']==ei)
        before=oracle()
        for f in event['changed_files']:
            if f in blobs:blobs[f]=(source/'originals'/c['id']/f).read_bytes()+(b'\nCONTROLLED_VERSION_CHANGE\n' if event['mutated'] else b'')
        after=oracle();flips=[i for i,(x,y) in enumerate(zip(before,after)) if x!=y]
        earliest=min(flips) if flips else None
        assert row['old_actions']==before and row['counterfactual_actions']==after
        assert row['flip_indices']==flips and row['oracle_rollback']==earliest
        for method,x in row['methods'].items():
            root=b/'workspaces'/c['id']/str(ei)/method
            state=json.loads((root/'.cbr/state.json').read_text())
            for rid in state['receipts']:
                receipt=json.loads((root/'.cbr/receipts'/(rid+'.json')).read_text())
                canonical=json.dumps(receipt,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
                assert sha(canonical)==rid
            assert x['wrong_actions_retained']==sum(before[i]!=after[i] for i in range(len(state['active'])))
            if method in ('full_replay','TrustScientist_CBR'):
                assert x['report']['rollback_index']==earliest
                assert len(state['active'])==(earliest if earliest is not None else len(before))
                for i in range(len(before)):
                    assert (root/('branch/output_'+str(i)+'.json')).exists()==(earliest is None or i<earliest)
            count[method]+=1
summary=json.loads((b/'summary.json').read_text())
for item in summary:
    m=item['method'];assert count[m]==item['events']
    assert item['decision_replays']==sum(len(r['methods'][m]['report']['replayed']) for r in rows)
    assert item['wrong_actions_retained']==sum(r['methods'][m]['wrong_actions_retained'] for r in rows)
result={'status':'PASS','events':len(rows),'capsules':len(cases),'history_decisions':sum(len(r['old_actions']) for r in rows),'flip_events':sum(r['oracle_rollback'] is not None for r in rows),'action_flips':sum(len(r['flip_indices']) for r in rows),'checked_policy_event_records':sum(count.values()),'scope':'independent byte-level oracle, persisted receipt hashes, actual checkpoint/branch output effects, and summary arithmetic; no semantic or natural-error validation'}
(b/'validation.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
