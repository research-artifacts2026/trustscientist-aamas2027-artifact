from pathlib import Path
import argparse,csv,hashlib,io,json,shutil,textwrap
from pypdf import PdfReader,PdfWriter,Transformation
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
R=Path(__file__).resolve().parents[2]
parser=argparse.ArgumentParser();parser.add_argument('--data-dir',type=Path,default=R/'outputs/TrustScientist_real_results_20261006')
O=parser.parse_args().data_dir.resolve()
D=json.loads((O/'verified_results.json').read_text());captions=json.loads((O/'captions.json').read_text())
records=[]
def record(study,method,metric,value,denominator='',unit='count',scope=''):
 records.append({'study':study,'method':method,'metric':metric,'value':value,'denominator':denominator,'unit':unit,'scope':scope})
for r in D['cbr']:
 record('CBR',r['method'],'earliest rollback exact',r['exact_rollback_on_flip'],r['flip_events'],scope='Controlled authored histories')
 record('CBR',r['method'],'wrong actions retained',r['wrong_actions_retained'],scope='Historical routing, not scientific truth')
 record('CBR',r['method'],'decision evaluations',r['decision_replays'],scope='Bookkeeping count, not total cost')
for r in D['dynamic']['methods']:
 record('Certificate updates',r['method'],'stale certificates accepted',r['stale_closed'],r['stale_opportunities'],scope='Supplied version contracts')
 record('Certificate updates',r['method'],'valid certificates retained',r['valid_closed'],r['valid'],scope='Supplied version contracts')
 record('Certificate updates',r['method'],'predicate evaluations',r['checks'],scope='Initialization excluded; not pooled with replay calls')
for r in D['manifest']:
 record('Manifest',r['method'],'nominal clean closed',r['clean_closed'],r['clean_n'],scope='Not semantic binding accuracy')
 record('Manifest',r['method'],'corrupted states closed',r['corrupt_closed'],r['corrupt_n'],scope='All controlled corruptions; supplied validity flags')
record('CORE retrieval','TrustScientist','reference-assisted candidates',D['core_retrieval']['candidates'],D['core_retrieval']['requirements'],scope='Candidate binding, not independently validated semantic completeness')
for r in D['fresh_execution']:
 record('Fresh workspace run '+str(r['run']),'TrustScientist','strict task success',r['strict_success'],r['n_tasks'],scope='Same tasks repeated; prepared compatibility fixes')
 record('Fresh workspace run '+str(r['run']),'TrustScientist','fresh answer matches',r['fresh_question_matches'],r['n_questions'],scope='Before official-artifact recovery; not autonomous repair')
record('Guarded acquisition','ECC','closed',D['guarded_acquisition_budget4']['closed'],D['guarded_acquisition_budget4']['attempts'],scope='Failed historical calibration; budget4')
for r in D['acquisition_budget4']:
 for k in ['correct','wrong','unresolved']:record('Acquisition: '+r['cohort'],r['method'],k,r[k],r['attempts'],scope='Budget4, existing artifacts; unguarded ECC')
for r in D['scope_gates']['summary']:
 for k in ['correct','wrong']:record('Paired semantic gates',r['method'],k,r[k],r['attempts'],scope='Benchmark agreement, not expert semantic validation')
for name,r in D['scifact_operating_points'].items():
 record('SciFact',name,'correct evidence-bearing closures',r['correct_relation_closures'],r['gold_evidence'],scope='Fixed retrieval; different coverage')
 record('SciFact',name,'NEI false closures',r['false_nei_closures'],r['gold_nei'],scope='Does not include reversed positive relations')
 for k in ['coverage','selective_risk','macro_f1']:record('SciFact',name,k,r[k],unit='fraction',scope='Unresolved maps to NEI in Macro-F1')
with (O/'results.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)

writer=PdfWriter();PAGE=(595.28,841.89);INK=HexColor('#163248');BLUE=HexColor('#0072B2')
def base(title,subtitle):
 mem=io.BytesIO();c=canvas.Canvas(mem,pagesize=PAGE);c.setFillColor(INK);c.setFont('Helvetica-Bold',17);c.drawString(42,795,title)
 c.setFont('Helvetica',8.5);c.setFillColor(HexColor('#555555'));c.drawString(42,777,subtitle)
 c.setStrokeColor(HexColor('#DCE3E8'));c.line(42,765,553,765)
 c.setFont('Helvetica',7.5);c.drawString(42,27,'Recorded results only | manuscript '+D['manuscript_commit'][:7]+' | no new inference')
 return mem,c
mem,c=base('TrustScientist: verified manuscript results','AAMAS 2027 draft | current project anonymous-manuscript | source-linked figures and complete counts')
cb={r['method']:r for r in D['cbr']};dy={r['method']:r for r in D['dynamic']['methods']};ma={r['method']:r for r in D['manifest']}
ca={(r['cohort'],r['method']):r for r in D['acquisition_budget4']};sf=D['scifact_operating_points']['full_trustscientist']
pair=D['scope_gates']['paired'][0];gate={r['method']:r for r in D['scope_gates']['summary']};pilot=D['disjoint_acquisition'][0];fresh=D['fresh_execution'][0]
cr=100*(1-cb['TrustScientist_CBR']['decision_replays']/cb['full_replay']['decision_replays'])
contrast=next(r for r in D['dynamic']['paired_contrasts'] if r['baseline']=='full_revalidation');ci=contrast['check_reduction_ci95']
declared_pairs=sum(r['attempts'] for r in D['acquisition_budget4'] if r['method']=='without_risk_bound')
items=[
 ('Historical branch replay',f"CBR and full replay: {cb['TrustScientist_CBR']['exact_rollback_on_flip']}/{cb['TrustScientist_CBR']['flip_events']} exact rollback points.",f"CBR: {cb['TrustScientist_CBR']['decision_replays']} evaluations; full replay: {cb['full_replay']['decision_replays']}. Saving: {cr:.1f}% in replay count."),
 ('Certificate maintenance',f"Graph, flat and full: {dy['dependency_graph']['stale_closed']}/{dy['dependency_graph']['stale_opportunities']} stale certificates accepted.",f"Graph/flat: {dy['dependency_graph']['checks']:,} checks; full: {dy['full_revalidation']['checks']:,}. Saving: {contrast['check_reduction']*100:.1f}% [{ci[0]*100:.1f}, {ci[1]*100:.1f}]% CI."),
 ('Matched manifests',f"TrustScientist: {ma['TrustScientist']['clean_closed']}/{ma['TrustScientist']['clean_n']} nominal clean, {ma['TrustScientist']['corrupt_closed']}/{ma['TrustScientist']['corrupt_n']} corrupted closed. Retrieval: {D['core_retrieval']['candidates']}/{D['core_retrieval']['requirements']}.",f"GPT: {ma['GPT-5.6-Sol']['clean_closed']}/{ma['GPT-5.6-Sol']['clean_n']}, {ma['GPT-5.6-Sol']['corrupt_closed']}/{ma['GPT-5.6-Sol']['corrupt_n']}; DeepSeek: {ma['DeepSeek-V4-Flash']['clean_closed']}/{ma['DeepSeek-V4-Flash']['clean_n']}, {ma['DeepSeek-V4-Flash']['corrupt_closed']}/{ma['DeepSeek-V4-Flash']['corrupt_n']}. Clean is not semantic accuracy."),
 ('Fresh execution',f"Each of {len(D['fresh_execution'])} runs: {fresh['strict_success']}/{fresh['n_tasks']} strict task successes; {fresh['fresh_question_matches']}/{fresh['n_questions']} fresh answer matches.",'Same tasks and prepared compatibility fixes; this is not independent sampling or autonomous repair.'),
 ('Budget-four acquisition',f"Unguarded ECC: {ca[('natural','without_risk_bound')]['correct']}/{ca[('natural','without_risk_bound')]['attempts']} correct natural; {ca[('controlled_multi','without_risk_bound')]['correct']}/{ca[('controlled_multi','without_risk_bound')]['attempts']} correct controlled.",f"Structured LLM matches every paired outcome ({declared_pairs}/{declared_pairs}); guarded closures: {D['guarded_acquisition_budget4']['closed']}/{D['guarded_acquisition_budget4']['attempts']}."),
 ('Fixed-retrieval SciFact',f"TrustScientist: {sf['correct_relation_closures']}/{sf['gold_evidence']} correct evidential resolutions; {sf['false_nei_closures']}/{sf['gold_nei']} NEI false closures.",f"There are {sf['wrong_relation_closures']} additional reversed relations. Selective error is {sf['false_nei_closures']+sf['wrong_relation_closures']}/{sf['closures']}."),
 ('Semantic scope gate',f"Adding scope witnesses removes {gate['answer_agreement']['wrong']-gate['scope_witness']['wrong']} error but loses {gate['answer_agreement']['correct']-gate['scope_witness']['correct']} correct closures.",f"Success difference: {pair['delta_success']*100:.1f} points [{pair['delta_success_ci'][0]*100:.1f}, {pair['delta_success_ci'][1]*100:.1f}]%; a negative result."),
 ('Remaining acquisition pilot',f"{pilot['attempts']} questions from {D['pilot_capsules']} disjoint capsules: {pilot['correct_closed']} correct, {pilot['wrong_closed']} wrong for both selectors.",f"None of {pilot['initial_wrong_answers']} initially wrong answers is recovered; no acquisition superiority.")]
y=730
for heading,line1,line2 in items:
 c.setFillColor(BLUE);c.setFont('Helvetica-Bold',11);c.drawString(42,y,heading);y-=19
 c.setFillColor(INK);c.setFont('Helvetica',9)
 for line in [line1,line2]:
  for wrapped in textwrap.wrap(line,width=99):c.drawString(42,y,wrapped);y-=13
 y-=16
c.setFillColor(INK);c.setFont('Helvetica-Bold',10);c.drawString(42,y-2,'Supported interpretation')
c.setFont('Helvetica',9)
notes='The strongest evidence concerns registered version and branch consistency. Graph and flat tracking tie. Work-count reductions do not establish lower end-to-end cost. Open-ended semantic completeness, natural autonomous recovery, adaptive risk certification and SOTA remain unsupported. Raw model outputs are not human validation.'
y-=20
for line in textwrap.wrap(notes,width=98):c.drawString(42,y,line);y-=13
assert y>40,'Summary text overlaps footer'
c.showPage();c.save();mem.seek(0);writer.add_page(PdfReader(mem).pages[0])
titles={'fig_current_maintenance':'Figure 1. Version and branch maintenance',
 'fig_current_semantic_control':'Figure 2. Semantic and acquisition outcomes',
 'fig_current_manifest':'Figure 3. Supplied-manifest compliance',
 'fig_current_scifact':'Figure 4. Fixed-retrieval semantic tradeoffs'}
for name,caption in captions.items():
 mem,c=base(titles[name],'Original cohort denominators and baseline ties are retained')
 wrapped=textwrap.wrap(caption,width=102);c.setFillColor(INK);c.setFont('Helvetica',8.5)
 cap_y=180
 for line in wrapped:c.drawString(42,cap_y,line);cap_y-=12
 assert cap_y>40,'Caption text overlaps footer'
 c.showPage();c.save();mem.seek(0);page=PdfReader(mem).pages[0]
 figure=PdfReader(O/'figures'/ (name+'.pdf')).pages[0]
 width=float(figure.mediabox.width);height=float(figure.mediabox.height)
 scale=min(511/width,545/height);x=42+(511-width*scale)/2;y=210+(545-height*scale)/2
 page.merge_transformed_page(figure,Transformation().scale(scale).translate(x,y))
 writer.add_page(page)
writer.add_metadata({'/Title':'TrustScientist Verified Results','/Author':'Anonymous Authors'})
with (O/'TrustScientist_verified_results.pdf').open('wb') as f:writer.write(f)
scripts=O/'scripts';scripts.mkdir(exist_ok=True)
for n in ['prepare_results.py','plot_current_results.py','create_report.py']:
 src=Path(__file__).resolve().parent/n;dst=scripts/n
 if src.resolve()!=dst.resolve():shutil.copy2(src,dst)
readme='''# Verified current manuscript results

Current manuscript commit 40161f4, project anonymous-manuscript. This is a result reanalysis
and visualization, not new experiment execution. The withdrawn WGR and
executed-update revisions are not pooled with this manuscript.

- TrustScientist_verified_results.pdf: five-page summary and four vector figures.
- figures/: vector PDF, editable SVG, 350-dpi PNG.
- verified_results.json: exact plot inputs, raw-record verification and source hashes.
- results.csv: complete metric table, denominators and scope.
- captions.json / latex_includes.tex: full scope captions and include snippets.

To redraw the frozen plots, run
`python scripts/plot_current_results.py --data-dir .`
with matplotlib and NumPy. scripts/prepare_results.py additionally requires
the original local paper checkout and frozen CBR evidence archive to recheck
all raw records; it performs no model requests. The per-plot data are never
hardcoded. Whole-task execution, model budgets and baseline capabilities are
described in the underlying manuscript protocols.

To regenerate the report and CSV from frozen inputs, run
`python scripts/create_report.py --data-dir .`
with pypdf and reportlab. Fresh-workspace runs repeat the same tasks; their
counts are reported per run, never pooled as independent observations.

No official SOTA, overall cost advantage, independent human validation or
natural autonomous scientific repair is established. Quality-gate closure
is zero under failed historical calibration; plotted ECC acquisition outcomes
are explicitly unguarded. Same-family figure/code review is provisional.
Original manuscript sources and figure files remain unchanged.
'''
(O/'README.md').write_text(readme,encoding='utf-8')
print('Verified result table and 5-page vector report saved.')
