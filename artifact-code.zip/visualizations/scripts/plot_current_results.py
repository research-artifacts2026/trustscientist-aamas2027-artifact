"""Publication figures: only read verified measurements, preserve all controls."""
from pathlib import Path
import argparse,csv,json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
R=Path(__file__).resolve().parents[2]
parser=argparse.ArgumentParser();parser.add_argument('--data-dir',type=Path,default=R/'outputs/TrustScientist_real_results_20261006')
O=parser.parse_args().data_dir.resolve()
D=json.loads((O/'verified_results.json').read_text());F=O/'figures';F.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'serif','font.serif':['Times New Roman','DejaVu Serif'],
 'font.size':9,'axes.labelsize':9,'xtick.labelsize':8,'ytick.labelsize':8,
 'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,
 'savefig.dpi':350,'axes.linewidth':.65,'legend.fontsize':8})
BLUE='#0072B2';GRAY='#7E8790';GREEN='#007A55';ORANGE='#C27018';PALE='#E7EAED';RED='#AD4A45'
def save(fig,name):
 for ext in ['pdf','svg','png']:fig.savefig(F/(name+'.'+ext),bbox_inches='tight',pad_inches=.07)
 plt.close(fig)
def panel(ax,letter):ax.text(-.06,1.06,'('+letter+')',transform=ax.transAxes,fontsize=10,fontweight='bold',va='bottom')
def bars(ax,labels,values,colors,den=None):
 y=np.arange(len(labels));ax.barh(y,values,color=colors,height=.57,zorder=3)
 ax.set_yticks(y,labels);ax.invert_yaxis();limit=max(max(values)*1.30,1);ax.set_xlim(0,limit)
 ax.grid(axis='x',color='#DADFE3',linewidth=.5,zorder=0)
 for i,v in enumerate(values):ax.text(v+limit*.018,i,f'{v:,}'+(f'/{den}' if den else ''),va='center',fontsize=8)
 ax.tick_params(axis='y',length=0);ax.spines['left'].set_visible(False)
def vertical(ax,labels,values,colors):
 bars_=ax.bar(np.arange(len(labels)),values,color=colors,width=.56,zorder=3)
 ax.set_xticks(np.arange(len(labels)),labels);ax.set_ylim(0,max(values)*1.22);ax.grid(axis='y',color='#DADFE3',linewidth=.5,zorder=0)
 for b,v in zip(bars_,values):ax.text(b.get_x()+b.get_width()/2,v+max(values)*.025,f'{v:,}',ha='center',va='bottom',fontsize=9)
 ax.tick_params(axis='x',length=0)

cbr={x['method']:x for x in D['cbr']};dyn={x['method']:x for x in D['dynamic']['methods']}
fig,axs=plt.subplots(2,2,figsize=(7.4,5.5));fig.subplots_adjust(left=.19,right=.98,bottom=.10,top=.94,wspace=.64,hspace=.62)
keys=['no_reaudit','existing_dependency_tracker','full_replay','TrustScientist_CBR']
bars(axs[0,0],['No re-audit','Certificate-only tracker','Full replay','CBR'],[cbr[k]['exact_rollback_on_flip'] for k in keys],[GRAY,GRAY,GRAY,BLUE],cbr[keys[0]]['flip_events'])
axs[0,0].set_xlabel('Exact rollback points (flip events)');panel(axs[0,0],'a')
keys=['without_reaudit','stateful_llm','full_revalidation','flat_dependency_scan','dependency_graph'];labels=['No re-audit','Stateful Qwen','Full re-audit','Flat tracking','Graph tracking']
y=np.arange(len(keys));ax=axs[0,1]
for i,k in enumerate(keys):
 row=dyn[k];value=row['stale_acceptance_rate']*100;lo,hi=np.array(row['stale_acceptance_ci95'])*100
 ax.errorbar(value,i,xerr=[[max(0,value-lo)],[max(0,hi-value)]],fmt='o',color=BLUE if k=='dependency_graph' else GRAY,capsize=2,markersize=5,zorder=3)
 # Raw counts remain separated from the uncertainty whiskers.
 ax.text(114,i,f"{row['stale_closed']}/{row['stale_opportunities']}",ha='left',va='center',fontsize=8)
ax.set_yticks(y,labels);ax.invert_yaxis();ax.set_xlim(-5,146);ax.set_xticks([0,50,100]);ax.set_xlabel('Stale certificates accepted (%)');ax.grid(axis='x',color='#DADFE3',linewidth=.5);ax.tick_params(axis='y',length=0);ax.spines['left'].set_visible(False);panel(ax,'b')
vertical(axs[1,0],['Full replay','CBR'],[cbr[k]['decision_replays'] for k in ['full_replay','TrustScientist_CBR']],[GRAY,BLUE]);axs[1,0].set_ylabel('Decision evaluations');panel(axs[1,0],'c')
vertical(axs[1,1],['Full','Flat','Graph'],[dyn[k]['checks'] for k in ['full_revalidation','flat_dependency_scan','dependency_graph']],[GRAY,GRAY,BLUE]);axs[1,1].set_ylabel('Predicate evaluations');panel(axs[1,1],'d')
save(fig,'fig_current_maintenance')

def stacked(ax,labels,rows):
 y=np.arange(len(rows));left=np.zeros(len(rows))
 for field,color,hatch in [('correct',GREEN,None),('wrong',ORANGE,'///'),('unresolved',PALE,None)]:
  vals=np.array([100*r[field]/r['attempts'] for r in rows]);bs=ax.barh(y,vals,left=left,color=color,height=.58,hatch=hatch,edgecolor='white',linewidth=.65,label=field.capitalize())
  for i,(b,v) in enumerate(zip(bs,vals)):
   if rows[i][field]:ax.text(left[i]+v/2,i,str(rows[i][field]),ha='center',va='center',fontsize=8,color='white' if field=='correct' else '#222222',bbox=dict(facecolor='white',edgecolor='none',pad=.3,alpha=.9) if field=='wrong' else None)
  left+=vals
 ax.set_yticks(y,labels);ax.invert_yaxis();ax.set_xlim(0,100);ax.set_xticks([0,50,100]);ax.tick_params(axis='y',length=0);ax.spines['left'].set_visible(False)

fig,axs=plt.subplots(1,2,figsize=(7.4,3.0));fig.subplots_adjust(left=.19,right=.99,bottom=.26,top=.88,wspace=.80)
scope=[]
for r in D['scope_gates']['summary']:scope.append(dict(r,unresolved=r['attempts']-r['closed']))
stacked(axs[0],['Literal contract','Structured rubric','Answer agreement','Agreement + scope'],scope);axs[0].set_xlabel('Paired gate outcomes (%)');panel(axs[0],'a')
stacked(axs[1],['Natural: unguarded ECC','Natural: structured LLM','Controlled: unguarded ECC','Controlled: structured LLM'],D['acquisition_budget4']);axs[1].set_xlabel('Budget-4 outcomes (%)');panel(axs[1],'b')
handles,labels=axs[0].get_legend_handles_labels();fig.legend(handles,labels,loc='lower center',ncol=3,frameon=False,bbox_to_anchor=(.52,.01))
save(fig,'fig_current_semantic_control')

fig,axs=plt.subplots(1,2,figsize=(7.4,2.55));fig.subplots_adjust(left=.18,right=.98,bottom=.25,top=.91,wspace=.65)
rows=D['manifest'];labels=[x['method'] for x in rows];colors=[GRAY,GRAY,BLUE]
bars(axs[0],labels,[x['clean_closed'] for x in rows],colors,rows[0]['clean_n']);axs[0].set_xlabel('Nominal clean states closed');panel(axs[0],'a')
bars(axs[1],labels,[x['corrupt_closed'] for x in rows],colors,rows[0]['corrupt_n']);axs[1].set_xlabel('Corrupted states closed');panel(axs[1],'b')
save(fig,'fig_current_manifest')

points=D['scifact_operating_points']
display={'direct_nli':'Direct NLI','llm_as_judge':'LLM judge','rule_auditor':'Rule','global_nli_llm_consensus':'Consensus',
 'typed_nli_only_ablation':'Typed NLI','full_trustscientist':'TrustScientist','mondrian_90':'Mondrian','risk_control_20':'Risk-controlled NLI'}
offset={'direct_nli':(-7,-17),'llm_as_judge':(-7,9),'rule_auditor':(-10,9),'global_nli_llm_consensus':(-50,-17),
 'typed_nli_only_ablation':(7,7),'full_trustscientist':(7,-19),'mondrian_90':(7,6),'risk_control_20':(-72,9)}
offset['global_nli_llm_consensus']=(0,-28)
fig,ax=plt.subplots(figsize=(5.0,3.25));fig.subplots_adjust(left=.15,right=.96,bottom=.19,top=.92)
for k,row in points.items():
 x=row['valid_claim_recall']*100;y=row['nei_fcr']*100
 ax.scatter(x,y,s=36,color=BLUE if k=='full_trustscientist' else GRAY,marker='D' if k=='full_trustscientist' else 'o',zorder=3)
 ax.annotate(display[k],(x,y),xytext=offset[k],textcoords='offset points',fontsize=8,color=BLUE if k=='full_trustscientist' else '#333333')
ax.set_xlim(8,78);ax.set_ylim(0,55);ax.set_xlabel('Correct evidential resolutions / 209 (%)');ax.set_ylabel('NEI false closure / 130 (%)');ax.grid(color='#DADFE3',linewidth=.5,zorder=0)
save(fig,'fig_current_scifact')

caption={
 'fig_current_maintenance':'''Controlled maintenance studies: 45 capsules and 405 update scenarios. CBR means Counterfactual Branch Revalidation. (a) Exact earliest rollback among 254 flip scenarios; the certificate-only tracker is the archived implementation without replay/rollback. (b) Stale certificate acceptance among 163 opportunities; whiskers are existing 45-capsule bootstrap 95% intervals. Degenerate empirical zero intervals are not population guarantees. Full, flat and graph retain 332/332 valid certificates; Qwen3-8B retains 327/332. (c) Decision evaluations for the two correct branch-replay policies. (d) Certificate predicate evaluations for equivalent deterministic policies. These separate work units exclude initialization and are not end-to-end costs. Histories are authored, changes scripted and dependencies supplied.''',
 'fig_current_semantic_control':'''(a) Outcomes for 79 paired semantic-gate questions; correct/wrong mean benchmark-answer agreement, not expert scientific validation. Correct/Wrong count closed cases; Unresolved means not closed. (b) Budget-four existing-artifact acquisition on 46 natural reporting questions and 36 controlled states. ECC (Evidence-Closure Control) is unguarded here. Budget units are declared tool costs, not time or currency: rebinding/extraction costs one, search/fetch two, and broad refresh three. The structured large-language-model selector matches all 82 paired outcomes. The guarded controller closes no cases after failed calibration. Counts sum to each cohort denominator. Panels are not pooled; unrestricted autonomous recovery is untested.''',
 'fig_current_manifest':'''Matched supplied manifests: 62 nominal clean and 310 controlled corrupted states per policy. Clean closure is not semantic binding accuracy: three GPT nonclosures expose mismatches that TrustScientist accepts. Corrupted closure uses all 310 states, not a clean-closed conditional denominator. Models receive supplied validity flags, not raw artifacts. These are functional stress tests, not a natural-error or SOTA estimate.''',
 'fig_current_scifact':'''Fixed-retrieval SciFact: 339 pairs, with 209 evidence-bearing pairs and 130 NEI (Not Enough Information) controls. CLOSED resolves SUPPORTS/REFUTES, not publication acceptance. Mondrian uses class-conditional conformal prediction at alpha=0.10 (90% nominal coverage); risk-controlled NLI uses a calibration risk target of 0.20. The six repeated policies use a representative saved run; their five-run aggregate operating-point metrics are identical. The two additional policies use single saved deterministic outputs. Methods have different closure coverage: points are not a matched-coverage frontier or connected curve. Lower NEI false closure can reduce useful resolutions.'''}
(O/'captions.json').write_text(json.dumps(caption,indent=2),encoding='utf-8')
includes=[]
for name,c in caption.items():
 c=c.replace('%','\\%')
 includes.append('\\begin{figure*}[t]\n\\centering\n\\includegraphics[width=0.98\\textwidth]{figures/'+name+'.pdf}\n\\caption{'+c+'}\n\\label{fig:'+name+'}\n\\end{figure*}\n')
(O/'latex_includes.tex').write_text('\n'.join(includes),encoding='utf-8')
print('Four data figures exported as editable SVG, vector PDF and 350-dpi PNG.')
