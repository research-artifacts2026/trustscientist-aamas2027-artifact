"""Operate CBR on an explicitly registered, opt-in run directory."""
import argparse,json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent/'implementation'))
from researchclaw.pipeline.counterfactual_revalidation import Store,verdict_policy,version_contract_policy,atomic,safe
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('command',choices=['inspect','revalidate','update-verdict'])
    ap.add_argument('run_directory',type=Path)
    ap.add_argument('--receipt');ap.add_argument('--verdict',type=Path)
    ap.add_argument('--budget',type=int)
    args=ap.parse_args()
    if not (args.run_directory/'.cbr/state.json').is_file():ap.error('No registered decision history. Legacy unbound decisions cannot be silently certified.')
    store=Store(args.run_directory,{'stage15_requirements':verdict_policy,'version_contract':version_contract_policy})
    if args.command=='inspect':
        s=store.state()
        print(json.dumps({'generation':s['generation'],'blocked':s['blocked'],'active':[{'receipt':rid,'policy':store.receipt(rid)['policy'],'old_action':store.receipt(rid)['old_action'],'bindings':store.receipt(rid)['bindings']} for rid in s['active']]},indent=2))
        return
    if args.command=='update-verdict':
        if not args.receipt or not args.verdict:ap.error('--receipt and --verdict required')
        if args.receipt not in store.state()['active']:ap.error('Receipt is not in active history')
        r=store.receipt(args.receipt)
        if r['policy']!='stage15_requirements':ap.error('Only the registered Stage-15 verdict adapter is supported')
        value=json.loads(args.verdict.read_text())
        if value.get('verdict') not in {'proceed','partial','reject'}:ap.error('Expected a normalized judge verdict')
        atomic(safe(store.root,r['bindings'][0]),value)
    result=store.revalidate(budget=args.budget)
    print(json.dumps(result,indent=2))
    if result['blocked']:raise SystemExit(2)
if __name__=='__main__':main()
