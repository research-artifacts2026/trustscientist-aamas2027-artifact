"""Policy arithmetic checks and post-run action/prompt diagnostic; no policy tuning."""
from pathlib import Path
import importlib.util,json,hashlib,collections
R=Path('/disk2/ANON/TrustScientist_AAMAS2027');O=R/'releases/discriminating_evidence_20260930'
spec=importlib.util.spec_from_file_location('runner',R/'scripts/discriminating_evidence_20260930.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
s={'hypotheses':[{'id':'H1','weight':.4},{'id':'H2','weight':.6}],'recommended_probe':'expensive'}
cheap={'id':'cheap','cost':1,'outcomes':['one','two'],'predicted_outcomes':{'H1':0,'H2':1}}
expensive=dict(cheap,id='expensive',cost=2)
assert abs(m.utility(cheap,s)-.24)<1e-12
assert m.select('discrimination_per_cost',[cheap,expensive],s,None)['id']=='cheap'
assert m.select('discrimination_only',[cheap,expensive],s,None)['id']=='expensive'
assert m.utility(dict(cheap,predicted_outcomes={'H1':0,'H2':0}),s)==0
assert m.utility(dict(cheap,predicted_outcomes={'H1':None,'H2':1}),s)==0
assert not m.gate({'report':{'answer':1,'declared_done':True,'bindings':[{'evidence_id':'e','quote':'return 1'}]}},[{'evidence_id':'e','kind':'code','text':'return 1'}])['closed']
checks={'score_formula':True,'cost_ablation_changes_only_division':True,'same_or_unknown_outcome_has_zero_score':True,'code_alone_cannot_certify_observed_result':True}
if not (O/'full_complete.json').exists():
 (O/'mechanism_smoke.json').write_text(json.dumps(checks,indent=2));print('Mechanism arithmetic and code-only negative controls PASS.');raise SystemExit()
rows=[json.loads(p.read_text()) for p in (O/'records/full').glob('*.json')];groups=collections.defaultdict(list);requests=0;parse_errors=0
for p in (O/'api/full').rglob('*.json'):
 d=json.loads(p.read_text());requests+=1
 if 'response' not in d:continue
 key=hashlib.sha256(m.canonical(d['request']).encode()).hexdigest();content=d['response']['choices'][0]['message']['content'];groups[key].append(content)
 try:assert isinstance(json.loads(content),dict)
 except Exception:parse_errors+=1
agreements={}
for other in ['stateful_validator','discrimination_only','cheapest_probe','random_probe']:
 exact=first=nonempty=0
 for r in rows:
  a=[m.probe_key(e['probe']) for e in r['methods']['discrimination_per_cost']['history']];b=[m.probe_key(e['probe']) for e in r['methods'][other]['history']]
  exact+=a==b
  if a and b:nonempty+=1;first+=a[0]==b[0]
 agreements[other]={'exact_action_sequence_matches':exact,'cases':len(rows),'same_first_probe':first,'both_nonempty':nonempty}
summary={'mechanism_checks':checks,'formal_requests':requests,'all_response_parse_errors':parse_errors,
 'repeated_request_groups':sum(len(v)>1 for v in groups.values()),'repeated_request_groups_with_different_content':sum(len(v)>1 and len(set(v))>1 for v in groups.values()),
 'action_agreement':agreements,'interpretation':'Any repeated-request variation limits deterministic attribution even at temperature0. Action agreement locates whether the selector actually changes behavior.'}
(O/'mechanism_audit.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
