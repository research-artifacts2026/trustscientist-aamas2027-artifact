# Discriminating evidence acquisition: completed 30 September 2026

## Conclusion
The tested heuristic does not improve answer correction over the shared-state model selector. Do not promote it to a successful core contribution.

## Execution and cohort
- 24 newly acquired official public-train capsules, 41 questions, disjoint from the known 45 test and 20 cached train capsules used earlier.
-25 candidate capsules were selected before outcomes; one exceeded the512-MiB archive cap. All41 acquired questions remain in evaluation.
- Frozen main experiment:623 actual model requests,2,867,307 tokens,0 transport failures and0 malformed JSON responses.
- Separate post hoc interface repair:217 actual requests,857,480 tokens;199 byte-identical calls reused across the two policies are not new executions.
- Smoke on two old cases:35 actual requests,149,716 tokens. Across all phases:875 unique actual responses.
- Independent implementation checks verified3,005 source-file hashes, observed text spans, literal gates, budget bounds, input allowlists, code hashes and response IDs.

## Frozen main results
Each policy receives up to4 declared tool-cost units. Searches cost1 and context expansion costs2. Actual tokens are reported separately.

| Policy | Correct closed /41 | Wrong closed /41 | Recovery of11 initially wrong answers | Allocated tokens |
|---|---:|---:|---:|---:|
| Initial report |13|9|0|116,254|
| Stateful validator |14|11|0|597,739|
| Disagreement / cost |14|11|0|624,028|
| Disagreement only |14|11|0|615,683|
| Cheapest probe |12|10|0|655,843|
| Random probe |14|10|0|615,884|
| All initial probes (different budget) |14|10|0|339,400|

The proposed selector and validator match every question's outcome. Its4.4% extra token use is observed in this execution; it is not an isolated causal estimate because repeated temperature0 requests can vary.
The mean paired token difference is641.2 per question, capsule-bootstrap95% interval[12.5,1448.9].
No method changes an initially correct answer into a wrong closure. Cheapest selection loses one initially correct closure through abstention.

## Mechanism diagnosis
-27/41 initial states have only one hypothesis.
-79/109 proposed-selector steps have zero predicted discrimination.
-All41 first actions match the validator;33 complete action sequences match.
-59/106 validator recommendations repeat an executed query and invoke the specified fallback.
-45/118 groups of identical model requests yield differing response text despite the fixed seed and temperature0.

## Post hoc interface repair
Both policies receive an additional selector call over only valid, affordable, unexecuted probes. The proposal formula and evidence-update prompt are unchanged. Identical requests are reused within each case to remove repeated-request variability for identical states. This is a diagnostic on already inspected cases, not a new held-out test.

| Policy | Correct closed /41 | Wrong closed /41 | Wrong-answer recovery | Allocated tokens |
|---|---:|---:|---:|---:|
| Strict stateful validator |13|11|0/11|919,775|
| Strict disagreement / cost |13|10|0/11|919,655|

The one outcome difference is abstention on the same wrong model name, not correction. False-termination difference is-2.4 percentage points,95% capsule-bootstrap interval[-7.9,0.0]. The token difference interval spans zero. Three policy trajectories encounter invalid probe choices and remain unresolved. Neither arm repairs an initial wrong answer, and both lose one initial correct closure.

## What was and was not tested
The tools execute read-only retrieval and context expansion over real outputs, code and metadata. No scientific training/reproduction computation was rerun. This tests selection within a model-proposed probe bank, not unrestricted agents or frontier-model superiority. Hypotheses and predicted probe outcomes are heuristic forecasts, not a calibrated generative model. Benchmark-reference scoring is independently implemented; scientific semantic fidelity has no independent human labels. The newly acquired cohort is public training data, not an official hidden test set.

## Manuscript changes
Added main Section6.1, full supplementary protocol, all comparative results and diagnostic limitations, plus a measured outcome/token-cost figure. Kept every existing figure. Compressed prose to retain8 body pages and1 reference page; supplement13 pages. Added and verified the active-learning prior art rather than claiming a new information-gain theorem. Preserved the author's title. The new selector is recorded as an unsuccessful extension.

## Reproduction
Server release: `/disk2/ANON/TrustScientist_AAMAS2027/releases/discriminating_evidence_20260930`.
Frozen scripts and prompts, raw requests/responses, normalized documents, source/archive hashes, per-question records, both scoring sets and validation are in the evidence ZIP. Original binary downloads remain on212. The raw archive includes server paths and reference answers, and is a private audit package rather than an anonymous submission supplement.

## Remaining research risks
The new cohort reduces repeated-test-data concerns for the frozen pilot but shows no comparative correction gain. Hypothesis and probe quality remain bottlenecks; the pairwise score alone is insufficient in this implementation. No useful adaptive risk certificate or independent semantic validation is established. This is a compiled research draft, not evidence of Strong Accept readiness.
