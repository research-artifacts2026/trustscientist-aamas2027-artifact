"""Benchmark-reference evaluator independent of controller and evidence-gate code."""
from pathlib import Path
import csv,hashlib,json,math,re
import numpy as np
O=Path('/disk2/ANON/TrustScientist_AAMAS2027/releases/discriminating_evidence_20260930')
NUM=r'(?<![\w.])[-+]?(?:\d+\.\d+|\d+|\.\d+)(?:[eE][-+]?\d+)?'
def scalar(x):
 if isinstance(x,bool) or x is None:raise ValueError()
 s=str(x).strip().rstrip('%')
 try:y=float(s)
 except ValueError:
  if re.search(r'\b(not|incorrect|wrong|unknown|less|greater)\b',s,re.I):raise ValueError()
  ns=re.findall(NUM,s)
  if len(ns)!=1:raise ValueError()
  y=float(ns[0])
 if not math.isfinite(y):raise ValueError()
 return y
def match(a,refs):
 vals=[v for x in refs for v in (x if isinstance(x,list) else [x])]
 if a is None:return False
 try:
  x=scalar(a);vs=[float(v) for v in vals];lo,hi=min(vs),max(vs);margin=max(1e-5,.05*(hi-lo),.001*abs(lo))
  return lo-margin<=x<=hi+margin
 except (ValueError,TypeError):return any(' '.join(str(a).lower().split())==' '.join(str(v).lower().split()) for v in vals)
assert not match('98.3',[100]) and match('100%',[100]) and not match(None,[0]) and not match('unknown 100',[100])
def main():
 gold=json.loads((O/'private_gold.json').read_text());rows=[json.loads(p.read_text()) for p in sorted((O/'records/full').glob('*.json'))];assert set(gold)=={r['id'] for r in rows}
 methods=['initial_report']+list(rows[0]['methods']);scored=[];actual_paths=set()
 for r in rows:
  g=gold[r['id']];initial=r['initial']['gate'];initialcorrect=match(initial['answer'],g['reference_values']);wrong_initial_answer=initial['answer'] is not None and not initialcorrect
  for method in methods:
   x=r['methods'].get(method,{});final=x.get('final',initial);correct=match(final['answer'],g['reference_values']);closed=final['closed']
   paths=r['initial']['api_calls']+x.get('api_calls',[]);actual_paths.update(paths)
   raws=[json.loads((O/p).read_text()) for p in paths];tokens=sum(a.get('response',{}).get('usage',{}).get('total_tokens',0) for a in raws)
   checkpoints=[{'spent':0,'gate':initial}]+x.get('checkpoints',[]);first=next((cp['spent'] for cp in checkpoints if cp['gate']['closed'] and match(cp['gate']['answer'],g['reference_values'])),None)
   scored.append({'id':r['id'],'cluster_id':r['cluster_id'],'method':method,'closed':closed,'correct_answer':correct,'correct_closed':bool(closed and correct),'wrong_closed':bool(closed and not correct),
    'initial_correct_answer':initialcorrect,'initial_wrong_answer':wrong_initial_answer,'initial_correct_closed':bool(initial['closed'] and initialcorrect),
    'recovered_wrong_answer':bool(wrong_initial_answer and closed and correct),'damaged_correct_answer':bool(initialcorrect and closed and not correct),
    'lost_correct_closure':bool(initial['closed'] and initialcorrect and not(closed and correct)),
    'tool_cost':x.get('tool_cost',0),'actions':x.get('actions',0),'tokens':tokens,'model_calls_allocated':len(paths),
    'returned_characters':sum(e['returned_characters'] for e in x.get('history',[])),'first_correct_closure_cost':first,
    'hypothesis_pair_discrimination_steps':sum(any(v['utility']>0 for v in e.get('selection_scores',{}).values()) for e in x.get('history',[])),
    'selector_fallbacks':x.get('selector_fallbacks',0),'semantic_fidelity':'unknown'})
 clusters=sorted({r['cluster_id'] for r in rows});rng=np.random.default_rng(20260930);draw=rng.integers(0,len(clusters),(10000,len(clusters)))
 summary=[]
 for method in methods:
  rr=[r for r in scored if r['method']==method];by=np.array([[sum(r[k] for r in rr if r['cluster_id']==c) for k in ['correct_closed','wrong_closed','tool_cost','tokens']]+[sum(r['cluster_id']==c for r in rr)] for c in clusters],dtype=float)
  boots=by[draw].sum(axis=1);ci=np.quantile(boots[:,:4]/boots[:,4,None],[.025,.975],axis=0);n=len(rr);right=sum(r['correct_closed'] for r in rr);wrong=sum(r['wrong_closed'] for r in rr)
  initialwrong=sum(r['initial_wrong_answer'] for r in rr);initialcorrect=sum(r['initial_correct_answer'] for r in rr);initialclosed=sum(r['initial_correct_closed'] for r in rr)
  summary.append({'method':method,'attempts':n,'correct_closed':right,'wrong_closed':wrong,'closed':right+wrong,'successful_closure':right/n,'false_termination':wrong/n,'selective_risk':wrong/(right+wrong) if right+wrong else None,
   'success_ci95':ci[:,0].tolist(),'false_termination_ci95':ci[:,1].tolist(),
   'initial_wrong_answers':initialwrong,'recovered_wrong_answers':sum(r['recovered_wrong_answer'] for r in rr),'recovery_rate':sum(r['recovered_wrong_answer'] for r in rr)/initialwrong if initialwrong else None,
   'initial_correct_answers':initialcorrect,'damaged_correct_answers':sum(r['damaged_correct_answer'] for r in rr),
   'initial_correct_closures':initialclosed,'lost_correct_closures':sum(r['lost_correct_closure'] for r in rr),
   'tool_cost':sum(r['tool_cost'] for r in rr),'actions':sum(r['actions'] for r in rr),'tokens_allocated':sum(r['tokens'] for r in rr),
   'mean_tool_cost':sum(r['tool_cost'] for r in rr)/n,'mean_tokens':sum(r['tokens'] for r in rr)/n,
   'returned_characters':sum(r['returned_characters'] for r in rr),'selector_fallbacks':sum(r['selector_fallbacks'] for r in rr),
   'discriminating_steps':sum(r['hypothesis_pair_discrimination_steps'] for r in rr)})
 def contrast(a,b):
  aa={r['id']:r for r in scored if r['method']==a};bb={r['id']:r for r in scored if r['method']==b};metrics=['correct_closed','wrong_closed','tool_cost','tokens']
  by=np.array([[sum(float(aa[k][m])-float(bb[k][m]) for k in aa if aa[k]['cluster_id']==c) for m in metrics]+[sum(aa[k]['cluster_id']==c for k in aa)] for c in clusters]);boots=by[draw].sum(axis=1);ci=np.quantile(boots[:,:4]/boots[:,4,None],[.025,.975],axis=0)
  return {'a':a,'b':b,'differences':{m:{'mean':float(by[:,i].sum()/len(aa)),'ci95':ci[:,i].tolist()} for i,m in enumerate(metrics)},'outcome_disagreements':sum((aa[k]['correct_closed'],aa[k]['wrong_closed'])!=(bb[k]['correct_closed'],bb[k]['wrong_closed']) for k in aa)}
 raws=[json.loads((O/p).read_text()) for p in sorted(actual_paths)];ids=[r['response']['id'] for r in raws if 'response' in r]
 out={'cases':len(rows),'capsules':len(clusters),'actual_model_requests':len(actual_paths),'actual_unique_responses':len(set(ids)),
  'actual_total_tokens':sum(r.get('response',{}).get('usage',{}).get('total_tokens',0) for r in raws),'transport_errors':sum('error' in r for r in raws),
  'summary':summary,'paired':[contrast('discrimination_per_cost',m) for m in ['stateful_validator','discrimination_only','cheapest_probe','random_probe']],
  'cost_accounting':'Shared initial request counted once in actual total; allocated to every method for per-policy cost. No requests shared after initial state. Prefixes are not separately optimized policies.',
  'scope':'Benchmark reference agreement, not independent scientific correctness; public-train subset; read-only evidence acquisition; all acquired question cases retained',
  'evaluator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
 (O/'scored.json').write_text(json.dumps(scored,indent=2));(O/'summary.json').write_text(json.dumps(out,indent=2))
 with (O/'summary.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
 print(json.dumps(out,indent=2))
if __name__=='__main__':main()
