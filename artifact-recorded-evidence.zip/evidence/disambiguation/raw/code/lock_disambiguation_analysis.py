"""Record analysis choices without reading model outcomes."""
from pathlib import Path
import hashlib,json,time
R=Path('/disk2/ANON/TrustScientist_AAMAS2027');O=R/'releases/discriminating_evidence_20260930'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
plan={'locked_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'timing':'formal execution in progress; no formal outcome records inspected by this script or analysis yet',
 'runner_sha256':sha(R/'scripts/discriminating_evidence_20260930.py'),'scorer_sha256':sha(R/'scripts/score_discriminating_evidence_20260930.py'),
 'validator_sha256':sha(R/'scripts/validate_discriminating_evidence_20260930.py'),'private_reference_sha256':sha(O/'private_gold.json'),
 'primary':'paired correct-closure and wrong-closure differences, discrimination_per_cost minus stateful_validator at endpoint of a4-tool-unit audit',
 'secondary':['recovery from initial non-null wrong answer','damage to initially reference-correct answer','loss of initially correct closure including abstention','actions','tool units','model tokens','returned characters'],
 'recovery_denominator':'all initial non-null reference-wrong answers, irrespective of initial declared_done; separately count initial unanswered cases',
 'damage_denominator':'all initial reference-correct answers; report wrong closures and lost correct closures separately',
 'gate':'model declares done with a real quoted output passage; independent reference agreement scores correctness; quoted passage validity is not independently semantically labelled',
 'tolerance':'same preexisting numeric reference-range tolerance: max(1e-5,0.05 range,0.001 abs(lower)); exact whitespace/case normalized string otherwise; no per-case tolerance tuning',
 'uncertainty':'paired capsule bootstrap10000 draws, seed20260930; secondary comparisons exploratory; do not interpret a degenerate zero-error bootstrap as a risk certificate',
 'comparison_rule':'report both success and false termination and their intervals; no general superiority from an improvement in only one endpoint or fewer closures',
 'prefixes':'descriptive observations along budget4 run; not separate optimized budget1/2 experiments',
 'missing':'all formal cases retained, parse/transport failures unresolved, no outcome-based exclusions'}
p=O/'analysis_plan.json';assert not p.exists();p.write_text(json.dumps(plan,indent=2));print('Analysis plan locked without reading outcomes.')
