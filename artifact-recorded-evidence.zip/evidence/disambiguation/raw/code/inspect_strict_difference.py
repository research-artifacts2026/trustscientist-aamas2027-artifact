from pathlib import Path
import json
O=Path('/disk2/ANON/TrustScientist_AAMAS2027/releases/discriminating_evidence_20260930');sc=json.loads((O/'strict_scored.json').read_text());out=[]
for p in (O/'records/strict').glob('*.json'):
 r=json.loads(p.read_text());a=r['methods']['discrimination_per_cost'];b=r['methods']['stateful_validator'];sa=next(x for x in sc if x['id']==r['id'] and x['method']=='discrimination_per_cost');sb=next(x for x in sc if x['id']==r['id'] and x['method']=='stateful_validator')
 if (sa['correct_closed'],sa['wrong_closed'])!=(sb['correct_closed'],sb['wrong_closed']) or a['strict_choice_failed'] or b['strict_choice_failed']:
  out.append({'id':r['id'],'question':r['question'],'proposed':a['final'],'baseline':b['final'],'proposed_choice_failed':a['strict_choice_failed'],'baseline_choice_failed':b['strict_choice_failed']})
(O/'strict_differences.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
