"""Validate isolation, raw model receipts, budgets, evidence spans and frozen protocol."""
from pathlib import Path
import argparse,hashlib,json,math
R=Path('/disk2/ANON/TrustScientist_AAMAS2027');O=R/'releases/discriminating_evidence_20260930'
def sha(x):return hashlib.sha256(x if isinstance(x,bytes) else x.encode()).hexdigest()
def canonical(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def norm(x):return ' '.join(str(x).split())
def independent_gate(state,evidence):
 report=state.get('report',{});report=report if isinstance(report,dict) else {};ev={e['evidence_id']:e for e in evidence};ok=False
 for b in report.get('bindings',[]) if isinstance(report.get('bindings'),list) else []:
  if not isinstance(b,dict):continue
  q=b.get('quote');e=ev.get(b.get('evidence_id'))
  if e and e['kind']=='outputs' and isinstance(q,str) and len(q.strip())>=3 and norm(q) in norm(e['text']):ok=True
 return {'closed':report.get('declared_done') is True and report.get('answer') is not None and ok,'literal_output_quote':ok,'answer':report.get('answer')}
def validate(phase):
 protocol=json.loads((O/'protocol.json').read_text());assert protocol['runner_sha256']==sha((R/'scripts/discriminating_evidence_20260930.py').read_bytes())
 cases=json.loads((O/('smoke_cases.json' if phase=='smoke' else 'cases.json')).read_text());plan=json.loads((O/'acquisition_plan.json').read_text())
 if phase=='full':
  assert {c['cluster_id'] for c in cases}.isdisjoint(plan['excluded_capsules'])
  assert protocol['cases_sha256']==sha(canonical(cases))
 rows=[json.loads((O/'records'/phase/(c['id']+'.json')).read_text()) for c in cases];calls=[];source_hashes={};invalid_outputs=0
 for c,row in zip(cases,rows):
  assert row['id']==c['id'] and row['cluster_id']==c['cluster_id']
  docs=json.loads(Path(c['documents_file']).read_text());docmap={d['id']:d for d in docs}
  if phase=='full':assert sha(Path(c['documents_file']).read_bytes())==protocol['documents_sha256'][c['cluster_id']]
  for d in docs:
   if d['source_path'] not in source_hashes:source_hashes[d['source_path']]=sha(Path(d['source_path']).read_bytes())
   assert source_hashes[d['source_path']]==d['source_sha256']
  def evidence_check(e):
   d=docmap[e['document_id']];start=e['start'];assert e['text']==d['text'][start:start+len(e['text'])]
   assert e['source_sha256']==d['source_sha256'] and e['kind']==d['kind']
  initial=row['initial'];ev=initial['evidence'];calls+=initial['api_calls'];assert independent_gate(initial['state'],ev)==initial['gate']
  for e in ev:evidence_check(e)
  for method,x in row['methods'].items():
   current={e['evidence_id']:e for e in ev};spent=0;assert x['actions']==len(x['history'])
   for event in x['history']:
    probe=event['probe'];cost=2 if probe['operation']=='inspect_context' else 1
    assert event['cost']==cost==probe['cost'];spent+=cost
    limit=6000 if cost==2 else 3000;assert event['returned_characters']==sum(len(e['text']) for e in event['observations'])<=limit
    if probe['operation']=='inspect_context':assert probe['evidence_id'] in current
    for e in event['observations']:evidence_check(e);current[e['evidence_id']]=e
   assert spent==x['tool_cost'] and (method=='all_initial_probes' or spent<=4)
   assert list(current.values())==x['observed'];assert independent_gate(x['state'],x['observed'])==x['final']
   calls+=x['api_calls'];invalid_outputs+=int(bool(x['state'].get('parse_or_transport_error')))
 ids=[];tokens=0;errors=0
 assert len(calls)==len(set(calls))
 for path in calls:
  raw=json.loads((O/path).read_text());req=raw['request'];assert req['model']==protocol['model'] and req['temperature']==0 and req['seed']==protocol['seed'] and req['max_tokens']==2048
  assert req['messages'][0]['content']==protocol['prompt']
  public=json.loads(req['messages'][1]['content']);assert set(public)=={'question','task_instructions','remaining_tool_units','files','evidence','previous_report','previous_hypotheses','executed_probes'}
  assert 0<=public['remaining_tool_units']<=4
  if 'response' in raw:ids.append(raw['response']['id']);tokens+=raw['response'].get('usage',{}).get('total_tokens',0)
  else:errors+=1
 assert len(ids)==len(set(ids))
 # Negative control: invented quotation cannot obtain a literal certificate.
 assert independent_gate({'report':{'answer':1,'declared_done':True,'bindings':[{'evidence_id':'e','quote':'invented value'}]}},[{'evidence_id':'e','kind':'outputs','text':'actual value'}])['closed'] is False
 result={'status':'PASS','phase':phase,'cases':len(cases),'capsules':len({c['cluster_id'] for c in cases}),'actual_requests':len(calls),'unique_response_ids':len(ids),'transport_errors':errors,'tokens':tokens,'sources_hash_verified':len(source_hashes),'final_parse_or_transport_errors':invalid_outputs,
 'checks':['frozen runner and input document hashes','known earlier cohorts excluded from formal cases','raw unique response IDs and common model settings','model-facing allowlist excludes reference answers','independent byte spans and unchanged source digests','identical literal-output gate and cost bounds','invented-quote negative control'],
 'scope':'Protocol/source integrity verification; no independent scientific semantic gold'}
 (O/f'{phase}_validation.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('phase',choices=['smoke','full']);validate(p.parse_args().phase)
