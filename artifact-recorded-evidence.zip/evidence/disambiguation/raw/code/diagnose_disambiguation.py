from pathlib import Path
import json,collections,hashlib
O=Path('/disk2/ANON/TrustScientist_AAMAS2027/releases/discriminating_evidence_20260930')
rows=[json.loads(p.read_text()) for p in (O/'records/full').glob('*.json')];d=collections.Counter();examples=[]
def key(p):return hashlib.sha256(json.dumps({k:p.get(k,'') for k in ['operation','query','evidence_id']},sort_keys=True).encode()).hexdigest()
for r in rows:
 st=r['initial']['state'];d['initial_hypotheses_'+str(len(st.get('hypotheses',[])))]+=1
 h=r['methods']['stateful_validator']['history'];states=[st]+[c['state'] for c in r['methods']['stateful_validator']['checkpoints']];seen=set()
 for state,e in zip(states,h):
  rec=state.get('recommended_probe');ps=state.get('probes',[]);recp=next((p for p in ps if p.get('id')==rec),None)
  if rec!=e['probe']['id']:
   reason='missing_id' if recp is None else 'repeated_query' if key(recp) in seen else 'other_filter_or_field_normalization'
   d['fallback_'+reason]+=1
   if len(examples)<4:examples.append({'question':r['question'],'recommendation':rec,'selected':e['probe'],'original_probes':ps,'reason':reason})
  seen.add(key(e['probe']))
  d['validator_operation_'+e['probe']['operation']]+=1
 for e in r['methods']['discrimination_per_cost']['history']:
  d['discrimination_steps_total']+=1;d['discrimination_steps_all_scores_zero']+=not any(v['utility']>0 for v in e['selection_scores'].values())
result={'counts':dict(d),'examples':examples,'scope':'Post hoc mechanism diagnosis, not new test evidence'}
(O/'diagnosis.json').write_text(json.dumps(result,indent=2));print(json.dumps({'counts':dict(d),'examples':examples[:1]},indent=2))
