from pathlib import Path
import importlib.util,json,hashlib,collections
import numpy as np
R=Path('/disk2/ANON/TrustScientist_AAMAS2027');O=R/'releases/discriminating_evidence_20260930'
def load(name):
 s=importlib.util.spec_from_file_location(name,R/'scripts'/f'{name}.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
score=load('score_discriminating_evidence_20260930');validator=load('validate_discriminating_evidence_20260930')
gold=json.loads((O/'private_gold.json').read_text());rows=[json.loads(p.read_text()) for p in sorted((O/'records/strict').glob('*.json'))];assert {r['id'] for r in rows}==set(gold)
sp=json.loads((O/'strict_protocol.json').read_text());assert hashlib.sha256((R/'scripts/strict_disambiguation_diagnostic.py').read_bytes()).hexdigest()==sp['runner_sha256']
scored=[];paths=set();logical=0;failures=0
for r in rows:
 original=json.loads((O/'records/full'/f"{r['id']}.json").read_text());assert r['initial']==original['initial'];ref=gold[r['id']]['reference_values'];init=r['initial']['gate'];ic=score.match(init['answer'],ref)
 for method,x in r['methods'].items():
  assert validator.independent_gate(x['state'],x['observed'])==x['final'];assert x['tool_cost']<=4 and sum(h['cost'] for h in x['history'])==x['tool_cost'];failures+=x['strict_choice_failed']
  ev={e['evidence_id']:e for e in r['initial']['evidence']};docs=json.loads((O/'documents'/f"{r['cluster_id']}.json").read_text());dm={d['id']:d for d in docs}
  for h in x['history']:
   ids={p['id'] for p in h['valid_probes']};assert h['strict_recommended_probe'] in ids and h['probe']['id'] in ids
   if method=='stateful_validator':assert h['probe']['id']==h['strict_recommended_probe']
   for e in h['observations']:
    d=dm[e['document_id']];assert e['text']==d['text'][e['start']:e['start']+len(e['text'])];assert e['source_sha256']==d['source_sha256'];ev[e['evidence_id']]=e
  assert list(ev.values())==x['observed']
  rawpaths=x['api_calls'];paths.update(rawpaths);logical+=len(rawpaths);raws=[json.loads((O/p).read_text()) for p in r['initial']['api_calls']+rawpaths]
  tokens=sum(a.get('response',{}).get('usage',{}).get('total_tokens',0) for a in raws);c=x['final']['closed'];correct=score.match(x['final']['answer'],ref)
  scored.append({'id':r['id'],'cluster_id':r['cluster_id'],'method':method,'correct_closed':bool(c and correct),'wrong_closed':bool(c and not correct),
   'recovered_wrong_answer':bool(init['answer'] is not None and not ic and c and correct),'damaged_correct_answer':bool(ic and c and not correct),
   'lost_correct_closure':bool(ic and init['closed'] and not(c and correct)),'actions':x['actions'],'tool_cost':x['tool_cost'],'tokens':tokens})
raw=[json.loads((O/p).read_text()) for p in paths];ids=[a['response']['id'] for a in raw if 'response' in a];assert len(ids)==len(set(ids));transport=sum('error' in a for a in raw)
summary=[]
for method in ['stateful_validator','discrimination_per_cost']:
 rr=[r for r in scored if r['method']==method];s={k:sum(r[k] for r in rr) for k in ['correct_closed','wrong_closed','recovered_wrong_answer','damaged_correct_answer','lost_correct_closure','actions','tool_cost','tokens']};s.update(method=method,cases=len(rr),mean_tokens=s['tokens']/len(rr));summary.append(s)
a={r['id']:r for r in scored if r['method']=='discrimination_per_cost'};b={r['id']:r for r in scored if r['method']=='stateful_validator'};clusters=sorted({r['cluster_id'] for r in rows});rng=np.random.default_rng(20260930);draw=rng.integers(0,len(clusters),(10000,len(clusters)))
metrics=['correct_closed','wrong_closed','tool_cost','tokens'];by=np.array([[sum(float(a[k][m])-float(b[k][m]) for k in a if a[k]['cluster_id']==c) for m in metrics]+[sum(a[k]['cluster_id']==c for k in a)] for c in clusters]);boots=by[draw].sum(axis=1);ci=np.quantile(boots[:,:4]/boots[:,4,None],[.025,.975],axis=0)
out={'status':'PASS','scope':'post hoc filtered-choice repair; same41 cases now previously inspected; shared byte-identical requests reused across arms',
 'new_actual_requests':len(paths),'unique_response_ids':len(ids),'transport_errors':transport,'actual_new_tokens':sum(x.get('response',{}).get('usage',{}).get('total_tokens',0) for x in raw),'logical_postinitial_calls':logical,'reused_postinitial_calls':logical-len(paths),'strict_choice_failures':failures,
 'summary':summary,'paired_differences':{m:{'mean':float(by[:,i].sum()/len(rows)),'ci95':ci[:,i].tolist()} for i,m in enumerate(metrics)},
 'outcome_disagreements':sum((a[k]['correct_closed'],a[k]['wrong_closed'])!=(b[k]['correct_closed'],b[k]['wrong_closed']) for k in a)}
(O/'strict_summary.json').write_text(json.dumps(out,indent=2));(O/'strict_scored.json').write_text(json.dumps(scored,indent=2));print(json.dumps(out,indent=2))
