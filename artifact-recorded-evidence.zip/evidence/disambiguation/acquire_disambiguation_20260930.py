"""Outcome-blind acquisition of previously uncached official train capsules."""
from pathlib import Path,PurePosixPath
import concurrent.futures as cf,hashlib,json,tarfile,time,requests
R=Path('/disk2/ANON/TrustScientist_AAMAS2027');B=Path('/disk2/ANON/benchmarks/core-bench/benchmark/dataset')
O=R/'releases/discriminating_evidence_20260930';O.mkdir(exist_ok=True)
def h(x):return hashlib.sha256(x if isinstance(x,bytes) else x.encode()).hexdigest()
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2))
train=json.loads((B/'core_train.json').read_text());old=json.loads((R/'data/corebench/core_test_evaluator_only.json').read_text())
exclude={x['capsule_id'] for x in old}|{p.name.split('.')[0] for p in (B/'capsules').iterdir() if p.is_dir()}
eligible=sorted([x['capsule_id'] for x in train if x['capsule_id'] not in exclude],key=lambda s:h('20260930'+s))
f=O/'acquisition_plan.json'
plan={'date':'2026-09-30','source':'official CORE-Bench train manifest','manifest_sha256':h((B/'core_train.json').read_bytes()),'excluded_capsules':sorted(exclude),'candidate_order':eligible,
 'rule':'All uncached train capsules considered, hash order, archive cap512MiB; no outcome selection; extract code/results/metadata/environment and reproduction text only; never execute capsule code',
 'max_compressed_bytes_per_archive':512*1024**2,'max_member_bytes':20*1024**2,'split_claim':'new to this evaluation and disjoint from known earlier cohorts; public benchmark train, not official hidden test'}
if f.exists():assert json.loads(f.read_text())==plan
else:dump(f,plan)
def acquire(cid):
 dest=O/'acquisition'/f'{cid}.json'
 if dest.exists():return json.loads(dest.read_text())
 url=f'https://corebench.cs.princeton.edu/capsules/{cid}.tar.gz';start=time.time();r={'capsule_id':cid,'url':url,'status':'pending'}
 try:
  with requests.get(url,stream=True,timeout=(20,50)) as response:
   response.raise_for_status();length=int(response.headers.get('Content-Length','0'));r['declared_bytes']=length
   if length>plan['max_compressed_bytes_per_archive']:r['status']='excluded_archive_size';dump(dest,r);return r
   archive=O/'downloads'/f'{cid}.tar.gz';archive.parent.mkdir(exist_ok=True);count=0
   with archive.open('wb') as out:
    for block in response.iter_content(1024**2):
     count+=len(block)
     if count>plan['max_compressed_bytes_per_archive']:raise ValueError('compressed archive exceeds frozen cap')
     out.write(block)
  r['downloaded_bytes']=count;r['archive_sha256']=h(archive.read_bytes());members=[];skipped=[]
  with tarfile.open(archive,'r:gz') as tar:
   for member in tar:
    pp=PurePosixPath(member.name);parts=pp.parts
    if not member.isfile() or pp.is_absolute() or '..' in parts:continue
    if parts and parts[0]==cid:parts=parts[1:]
    if not parts:continue
    if parts[0] not in ['results','code','metadata','environment','REPRODUCING.md']:continue
    if member.size>plan['max_member_bytes']:skipped.append({'path':'/'.join(parts),'size':member.size});continue
    target=O/'capsules'/cid/Path(*parts);target.parent.mkdir(parents=True,exist_ok=True)
    content=tar.extractfile(member).read();target.write_bytes(content);members.append({'path':'/'.join(parts),'bytes':len(content),'sha256':h(content)})
  r.update(status='acquired',members=members,skipped_members=skipped,elapsed=time.time()-start)
 except Exception as e:r.update(status='failed',error=type(e).__name__+': '+str(e),elapsed=time.time()-start)
 dump(dest,r);return r
if __name__=='__main__':
 with cf.ThreadPoolExecutor(max_workers=4) as pool:
  rows=[]
  for x in pool.map(acquire,eligible):rows.append(x);print(x['capsule_id'],x['status'],x.get('downloaded_bytes',0),flush=True)
 dump(O/'acquisition_summary.json',rows)
