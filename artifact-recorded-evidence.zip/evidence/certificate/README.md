# Dynamic evidence revalidation: completed on 212, 30 September 2026

## Question and scope
Can dependency-driven revalidation preserve fixed-version certificates with less work than full re-audit, and does a carefully prompted stateful validator perform the same invalidation correctly?

124 copied source files, 79 reporting states, 45 previously inspected capsules, 361 check nodes.
Nine fixed update/restore events per capsule yield 405 formal model requests and 711 certificate decisions per method.
The 9-request smoke run is separate. Formal requests use 232,958 tokens, with zero transport failures and no fallback plans.

| Policy | Stale accepted /163 | Valid retained /332 | Predicate checks |
|---|---:|---:|---:|
| Full re-audit |0|332|2,888|
| Stateful Qwen3-8B |38|327|1,624|
| Dependency graph |0|332|1,530|
| Flat dependency table |0|332|1,530|
| No re-audit |163|332|0|

Graph and flat tracking match every full-revalidation decision with 47.0% fewer checks; paired 10,000-resample capsule-bootstrap 95% interval [42.2%,51.8%].
LLM stale acceptance is 23.3%, with interval [12.8%,35.2%]. The 216 initially non-passing instances are excluded from this stale denominator.
Graph-vs-LLM check reduction has interval [-7.4%,13.8%]; no check-cost advantage over that selector is established.

## Interpretation
This supports executable dependency invalidation and selective re-audit for declared deterministic version contracts.
It does not show that a graph data structure is necessary: the flat table is exactly tied.
It does not establish semantic correctness, natural-update prevalence, adaptive risk certification, frontier-model superiority or general wall-clock speedup.
The shared-file example shows one real response updating only one of three affected reporting chains, leaving two stale closures.
These are scripted version changes in isolated copies; the existing acquisition controller is unchanged.

## Verification and evidence
An independent evaluator reconstructs bytes after each event and scores certificate file contracts directly.
A separate validator reconstructs certificate file lists from upstream bundles, tests a missing-dependency negative control, and checks protocol hashes, 405 unique response IDs and unchanged original source files.
All checks pass. No independent human annotation is claimed.
Remote release: /disk2/ANON/TrustScientist_AAMAS2027/releases/dynamic_revalidation_20260930
Raw evidence includes requests/responses, case inputs, copied originals, events, per-case scores and frozen scripts.
The raw archive includes server paths and is a private audit/reproduction package, not an anonymous submission supplement.

## Manuscript and figures
Preserved the author's title, "TrustScientist: Stateful Evidence Control for Autonomous Research Agents".
Revised abstract, introduction, contributions, method, discussion and conclusion; added main dynamic study and supplementary protocol.
Moved detailed paired semantic-gate results to the supplement while retaining the negative finding in the main paper.
Added verified Build Systems a la Carte prior art to distinguish standard dependency invalidation from the application-level contribution.
Added two deterministic vector figures from recorded results: outcome/cost comparison in the main paper and an executed shared-source failure trace in the supplement.
Both preexisting figures remain byte-identical. Exact-number table and all prior results are retained.

## Remaining submission risks
The controller still ties the structured selector on 82/82 budget-4 outcomes. The new dynamic study answers a narrower maintenance question.
No independent semantic gold or open-ended requirement completeness validation is available.
Historical calibration fails the risk threshold; no useful certified adaptive closure is demonstrated.
One small local model and previously inspected capsules limit external validity; a deterministic baseline matches the graph.
The paper is a compiled scientific draft, not a demonstrated Strong Accept result.
