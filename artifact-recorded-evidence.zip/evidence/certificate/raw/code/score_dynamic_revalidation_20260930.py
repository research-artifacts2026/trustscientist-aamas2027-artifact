"""Independent truth: direct file-to-certificate contracts; no graph/executor imports."""
import argparse, json, hashlib
from pathlib import Path
import numpy as np
O=Path('/disk2/ANON/TrustScientist_AAMAS2027/releases/dynamic_revalidation_20260930')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def expected(claim,case,observed):
    return bool(claim['base_pass'] and all(observed[f]==case['files'][f]['expected_sha256'] for f in claim['required_files']))
def main(phase):
    cases={c['id']:c for c in json.loads((O/'cases.json').read_text())};records=[json.loads(p.read_text()) for p in sorted((O/'records'/phase).glob('*.json'))]
    assert len(records)==(1 if phase=='smoke' else 45)
    scored=[];total_calls=0;total_tokens=0;fallbacks=0;raw=[]
    for r in records:
        case=cases[r['id']]
        assert len(r['events'])==9
        # Original source files must remain identical to their immutable copies.
        for f,meta in case['files'].items():
            assert digest(O/'originals'/case['id']/f)==meta['expected_sha256']
            if 'original_source' in meta:assert digest(Path(meta['original_source']))==meta['expected_sha256']
        reconstructed={fid:(O/'originals'/case['id']/fid).read_bytes() for fid in case['files']}
        for event in r['events']:
            specification=case['events'][event['event_index']]
            for fid in specification['changed_files']:
                if fid not in reconstructed:continue
                original=(O/'originals'/case['id']/fid).read_bytes()
                reconstructed[fid]=original+(b'\nCONTROLLED_VERSION_CHANGE\n' if specification['mutated'] else b'')
            assert event['observed_sha256']=={fid:hashlib.sha256(blob).hexdigest() for fid,blob in reconstructed.items()}
            truths={c['node']:expected(c,case,event['observed_sha256']) for c in case['claims']}
            for method,m in event['methods'].items():
                valid=sum(truths.values());invalid=len(truths)-valid
                stale_opportunities=sum(c['base_pass'] and not truths[c['node']] for c in case['claims'])
                tp=sum(m['cache'][n] is True and y for n,y in truths.items());fp=sum(m['cache'][n] is True and not y for n,y in truths.items())
                scored.append({'capsule':case['id'],'event':event['event_index'],'event_type':event['event_type'],'method':method,
                    'valid':valid,'invalid':invalid,'stale_opportunities':stale_opportunities,'valid_closed':tp,'stale_closed':fp,'checks':m['cost']['checks'],'file_reads':m['cost']['file_reads'],
                    'bytes_read':m['cost']['bytes_read'],'check_seconds':m['cost']['check_seconds'],'selection_seconds':m['selection_seconds'],
                    'nodes':len(case['nodes'])})
                if m['api']:
                    total_calls+=1;total_tokens+=m['api']['tokens'];fallbacks+=m['api']['fallback_full'];raw.append(json.loads((O/m['api']['path']).read_text()))
            # Independent full-oracle equivalence must hold for both programmatic dependency methods.
            for method in ['full_revalidation','dependency_graph','flat_dependency_scan']:
                assert all((event['methods'][method]['cache'][node] is True)==truth for node,truth in truths.items())
    if phase=='smoke':
        result={'status':'PASS','capsules':1,'events':9,'model_requests':total_calls,'checks':['original artifact preservation','direct contract oracle','full/graph/flat certificate equivalence','complete event trajectory']}
        (O/'smoke_pass.json').write_text(json.dumps(result,indent=2));print(json.dumps(result));return
    methods=list(records[0]['events'][0]['methods']);summary=[]
    for method in methods:
        xs=[x for x in scored if x['method']==method];summ={k:sum(x[k] for x in xs) for k in ['valid','invalid','stale_opportunities','valid_closed','stale_closed','checks','file_reads','bytes_read','check_seconds','selection_seconds']}
        summ.update(method=method,events=len(xs),certificate_decisions=summ['valid']+summ['invalid'])
        summ['stale_acceptance_rate']=summ['stale_closed']/summ['stale_opportunities'] if summ['stale_opportunities'] else None
        summ['valid_retention_rate']=summ['valid_closed']/summ['valid'] if summ['valid'] else None
        summary.append(summ)
    clusters=sorted(cases);rng=np.random.default_rng(20260930);draws=rng.integers(0,len(clusters),(10000,len(clusters)))
    for summ in summary:
        arr=np.array([[sum(x[k] for x in scored if x['capsule']==c and x['method']==summ['method']) for k in ['stale_closed','stale_opportunities','valid_closed','valid']] for c in clusters])
        bs=arr[draws].sum(axis=1)
        summ['stale_acceptance_ci95']=np.quantile(bs[:,0]/np.maximum(bs[:,1],1),[.025,.975]).tolist()
        summ['valid_retention_ci95']=np.quantile(bs[:,2]/np.maximum(bs[:,3],1),[.025,.975]).tolist()
    contrasts=[]
    for baseline in ['full_revalidation','stateful_llm','flat_dependency_scan']:
        array=[]
        for c in clusters:
            a=[x for x in scored if x['capsule']==c and x['method']=='dependency_graph'];b=[x for x in scored if x['capsule']==c and x['method']==baseline]
            array.append([sum(x['checks'] for x in a),sum(x['checks'] for x in b),sum(x['stale_closed'] for x in a)-sum(x['stale_closed'] for x in b),sum(x['valid_closed'] for x in a)-sum(x['valid_closed'] for x in b)])
        arr=np.array(array);bs=arr[draws].sum(axis=1);savings=1-bs[:,0]/np.maximum(bs[:,1],1)
        contrasts.append({'baseline':baseline,'check_reduction':float(1-arr[:,0].sum()/arr[:,1].sum()),'check_reduction_ci95':np.quantile(savings,[.025,.975]).tolist(),
          'delta_stale_closed':int(arr[:,2].sum()),'delta_valid_closed':int(arr[:,3].sum())})
    out={'capsules':45,'questions':79,'events':405,'certificate_decisions_per_method':711,'formal_model_requests':total_calls,
      'formal_tokens':total_tokens,'fallback_full':fallbacks,'transport_errors':sum('error_type' in r for r in raw),
      'methods':summary,'paired_contrasts':contrasts,'scope':'controlled version-contract stress test; no scientific semantic accuracy or graph-necessity claim',
      'score_sha256':digest(Path(__file__)),
      'validation':['complete trajectories','original source hashes preserved','independent byte-level event replay','full/graph/flat certificate equivalence'],
      'graph_index_build_seconds':sum(r['graph_index_build_seconds'] for r in records)}
    (O/'scored.json').write_text(json.dumps(scored,indent=2));(O/'summary.json').write_text(json.dumps(out,indent=2))
    print(json.dumps(out,indent=2))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('phase',choices=['smoke','full']);main(ap.parse_args().phase)
