"""Regenerate both exact-evidence figures from saved experiment outputs."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Patch
P=Path(__file__).resolve().parents[1];F=P/'figures';D=P/'revision_control/dynamic'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':8,
 'axes.labelsize':7.5,'xtick.labelsize':7,'ytick.labelsize':7.8,'pdf.fonttype':42,
 'ps.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,
 'savefig.pad_inches':.04})
def save(fig,name):
    for ext in ['pdf','svg','png']:fig.savefig(F/(name+'.'+ext),dpi=400,bbox_inches='tight')
    plt.close(fig)
s=json.loads((D/'analysis.json').read_text());by={x['method']:x for x in s['methods']}
order=['full_revalidation','stateful_llm','dependency_graph','flat_dependency_scan','without_reaudit']
labels=['Full audit','Stateful LLM','Graph','Flat table','No re-audit']
colors=['#707B84','#D55E00','#0072B2','#56B4E9','#A9AFB5']
fig,(a,b)=plt.subplots(1,2,figsize=(3.5,2.5),sharey=True,gridspec_kw={'width_ratios':[1,1.25]})
fig.subplots_adjust(left=.25,right=.99,top=.80,bottom=.15,wspace=.36)
y=np.arange(5)
for i,(method,color) in enumerate(zip(order,colors)):
    row=by[method];rate=100*row['stale_acceptance_rate'];lo,hi=np.array(row['stale_acceptance_ci95'])*100
    a.errorbar(rate,i,xerr=[[rate-lo],[hi-rate]],fmt='s' if method=='flat_dependency_scan' else 'o',
               color=color,ms=4,capsize=2,elinewidth=1,clip_on=False)
    x=rate+7 if rate<90 else rate-7
    if method=='stateful_llm':x=hi+5
    a.text(x,i,str(row['stale_closed']),va='center',ha='left' if rate<90 else 'right',fontsize=7.5,color=color)
    b.barh(i,row['checks'],height=.51,color=color,alpha=.92,
           hatch='///' if method=='flat_dependency_scan' else None,edgecolor=color,linewidth=.5)
    b.text(row['checks']+100,i,f"{row['checks']:,}",va='center',fontsize=7.5)
for ax in [a,b]:
    ax.set_ylim(4.6,-.65);ax.spines['left'].set_visible(False);ax.spines['bottom'].set_color('#9BA4AD')
    ax.tick_params(axis='y',length=0);ax.grid(axis='x',color='#E8EBEE',linewidth=.5);ax.set_axisbelow(True)
a.set_yticks(y,labels);b.tick_params(labelleft=False)
a.set_xlim(-5,115);a.set_xticks([0,50,100]);a.set_xlabel('% of 163 stale cases')
b.set_xlim(0,4250);b.set_xticks([0,1500,3000]);b.set_xlabel('Predicate checks')
a.set_title('(a) Stale accepted ↓',loc='left',pad=12)
b.set_title('(b) Revalidation cost ↓',loc='left',pad=12)
save(fig,'fig_dynamic_outcomes')

t=json.loads((D/'figure_trace.json').read_text());nodes=t['nodes'];node_by={n['id']:n for n in nodes}
pos={'n000':(.45,2.05),'n001':(.45,.85)}
for row,chain in enumerate([['n002','n003','n004'],['n005','n006','n007'],['n008','n009','n010']]):
    for col,n in enumerate(chain):pos[n]=(1.65+col*1.1,2.55-row*1.05)
fig,axs=plt.subplots(1,2,figsize=(7.0,3.20));fig.subplots_adjust(left=.012,right=.99,top=.87,bottom=.19,wspace=.07)
palette={'fresh_fail':('#E4F0F8','#0072B2'),'stale_pass':('#FBE8DC','#C14C08'),'unchanged_pass':('#F0F2F4','#747D85')}
for ax,method,title in zip(axs,['stateful_llm','dependency_graph'],['(a) Prompted stateful validator','(b) Executable dependency tracking']):
    states=t['methods'][method]['cache'];selected=set(t['methods'][method]['selected']);affected=set(t['methods']['dependency_graph']['selected'])
    for node in nodes:
        x2,y2=pos[node['id']]
        for parent in node['parents']:
            x1,y1=pos[parent];missed=parent in affected and node['id'] not in selected
            arrow=FancyArrowPatch((x1+.39,y1),(x2-.40,y2),arrowstyle='-|>',mutation_scale=7,
                linewidth=.85,color='#C14C08' if missed else '#8A959D',linestyle='--' if missed else '-')
            ax.add_patch(arrow)
    for node in nodes:
        n=node['id'];x,y0=pos[n]
        category='fresh_fail' if n in selected else ('stale_pass' if n in affected else 'unchanged_pass')
        fc,ec=palette[category]
        ax.add_patch(FancyBboxPatch((x-.39,y0-.245),.78,.49,boxstyle='round,pad=0.025,rounding_size=.04',
                                   facecolor=fc,edgecolor=ec,linewidth=1.05))
        if node['kind']=='closure':label='OPEN' if not states[n] else 'CLOSED*'
        else:label='FAIL' if not states[n] else ('stale PASS' if category=='stale_pass' else 'PASS')
        ax.text(x,y0+.075,n,ha='center',va='center',fontsize=7.7,color='#17232D')
        ax.text(x,y0-.095,label,ha='center',va='center',fontsize=7.1,color=ec)
    for x,label in zip([.45,1.65,2.75,3.85],['Source','Receipt','Binding','Closure']):ax.text(x,3.07,label,ha='center',fontsize=7.7,weight='bold')
    ax.text(.45,2.48,'f000 changed',ha='center',fontsize=7.1,color='#0072B2')
    ax.text(.45,.39,'f001 unchanged',ha='center',fontsize=7.1,color='#747D85')
    ax.set_title(title,loc='left',fontsize=9,pad=19);ax.set_xlim(-.04,4.33);ax.set_ylim(.04,3.15);ax.axis('off')
legend=[Patch(facecolor=palette[k][0],edgecolor=palette[k][1],label=label) for k,label in
        [('fresh_fail','Rechecked: FAIL / OPEN'),('stale_pass','Cached: stale PASS / CLOSED*'),('unchanged_pass','Unchanged: PASS')]]
fig.legend(handles=legend,loc='lower center',bbox_to_anchor=(.5,.015),ncol=3,fontsize=7.5,frameon=False,
           handlelength=1.2,columnspacing=1.3)
save(fig,'fig_dynamic_shared_source_trace')
print('Saved two figures as PDF, SVG and 400-dpi PNG from recorded data.')
