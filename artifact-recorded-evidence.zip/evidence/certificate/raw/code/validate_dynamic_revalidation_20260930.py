"""Independent provenance and dependency-omission negative control."""
from pathlib import Path
import copy,hashlib,importlib.util,json
R=Path('/disk2/ANON/TrustScientist_AAMAS2027');O=R/'releases/dynamic_revalidation_20260930'
cases=json.loads((O/'cases.json').read_text());p=json.loads((O/'protocol.json').read_text())
assert hashlib.sha256((R/'scripts/dynamic_revalidation_20260930.py').read_bytes()).hexdigest()==p['runner_sha256']
raw_inputs={x['task_id']:x for x in [json.loads(f.read_text()) for f in (R/'releases/paired_scope_probe_20260930/records').glob('*.json')]}
for case in cases:
    sources={m['original_source']:f for f,m in case['files'].items() if 'original_source' in m}
    for claim in case['claims']:
        original=raw_inputs[claim['question_id']]
        independently_expected={sources[e['source_path']] for e in original['public']['evidence']}
        independently_expected|={f for f,m in case['files'].items() if m.get('derived_from')==claim['question_id']}
        assert independently_expected==set(claim['required_files'])
        assert claim['base_pass']==original['gates']['literal_contract']
spec=importlib.util.spec_from_file_location('runner',R/'scripts/dynamic_revalidation_20260930.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
case=next(c for c in cases if c['id']=='08ec5a4786de2e71');changed=case['events'][1]['changed_files']
complete=mod.graph_select(mod.build_index(case['nodes']),changed)
faulty=copy.deepcopy(case['nodes'])
source_node=next(n['id'] for n in faulty if n['input_files']==changed)
target=next(n for n in faulty if n['kind']=='extraction' and source_node in n['parents'])
target['parents'].remove(source_node)
incomplete=mod.graph_select(mod.build_index(faulty),changed)
assert complete-incomplete and any(c['node'] in complete-incomplete for c in case['claims'])
api=[json.loads(f.read_text()) for f in (O/'api/full').rglob('*.json')]
assert len(api)==405 and len({r['response']['id'] for r in api})==405
for a in api:
    assert a['request']['temperature']==0 and a['request']['max_tokens']==768
    public=json.dumps(a['request']['messages']);assert 'reference_values' not in public and 'mutated' not in public
result={'status':'PASS','formal_unique_response_ids':405,'smoke_requests':len(list((O/'api/smoke').rglob('*.json'))),
 'nodes':sum(len(c['nodes']) for c in cases),'initial_closed':sum(c['base_pass'] for case in cases for c in case['claims']),
 'negative_control_missing_dependency_changes_closure_set':True,
 'checks':['frozen runner hash','independent reconstruction of certificate file dependencies from upstream bundles',
 'dependency omission negative control','unique actual model responses','common model settings and no private mutation labels',
 'independent byte replay and original source preservation in scorer']}
(O/'validation.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
