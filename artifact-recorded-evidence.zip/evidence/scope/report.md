# September 30 paired gate experiment: completed on 212

79 natural questions, 45 previously inspected capsules, 237 actual model requests.
No HTTP failures; six JSON parse failures retained as unresolved. Total tokens: 1,044,094.

| Shared-output gate | Correct closed | Wrong closed | Wrong / closed |
|---|---:|---:|---:|
| Literal contract |44|11|20.0%|
| Structured rubric |35|4|10.3%|
| Blind answer agreement |34|6|15.0%|
| Agreement + scope witnesses |25|5|16.7%|

The isolated scope gate rejects one reference error and nine reference-correct answers.
Paired capsule-bootstrap successful-closure difference: -11.4 points, 95% CI [-19.8,-2.9].
False-termination difference: -1.3 points, CI [-4.2,0.0]. The extension is not adopted as an improvement.
The structured rubric remains the stronger observed semantic gate. No external generalization or risk certificate follows.

Primary scoring is independently implemented benchmark-reference agreement, with the preexisting numeric tolerance.
Source-file integrity and literal answer support are separate diagnostics: 79 and 55 pass, respectively.
No independent semantic labels exist; scientific validity and requirement completeness remain unverified.
All questions were previously inspected. This is a paired exploratory gate experiment, not a new autonomous-loop benchmark.

## Reproduction
Remote release: /disk2/ANON/TrustScientist_AAMAS2027/releases/paired_scope_probe_20260930
Scripts: scope_probe_20260930.py, score_scope_probe_20260930.py, validate_scope_probe_20260930.py under the server scripts directory.
Protocol frozen before model requests; validation checks its hash, input isolation, full case coverage, nested gates and evaluator regression cases.
Raw model requests/responses and per-case public inputs are preserved in the private evidence archive.
The source ZIP is a compile package; the raw archive contains server paths and is not an anonymous submission supplement.

## Scientific status
Functional enforcement and some recovery are supported. The structured selector still ties all 82 budget-4 outcomes.
Risk calibration still fails. New evidence improves attribution and exposes the cost of an unsuccessful extension;
it does not establish comparative controller superiority or Strong Accept readiness.
Next high-value work requires unused evaluation capsules and genuinely diverse shared acquisition actions,
followed by isolated graph/budget/re-audit contrasts. Repeated tuning on these same 45 capsules is not new test evidence.
