import copy, hashlib, importlib.util, json, tempfile
from pathlib import Path
R=Path('/disk2/ANON/TrustScientist_AAMAS2027')
O=R/'releases/paired_scope_probe_20260930'
s=importlib.util.spec_from_file_location('score',R/'scripts/score_scope_probe_20260930.py')
e=importlib.util.module_from_spec(s);s.loader.exec_module(e)
with tempfile.TemporaryDirectory(prefix='trust_scope_eval_') as d:
    p=Path(d)/'results.txt';p.write_text('Accuracy 95.2')
    h=hashlib.sha256(p.read_bytes()).hexdigest()
    ev={'evidence_id':'e','source_path':str(p),'source_sha256':h,'text':'Accuracy 95.2',
        'capsule_id':'c','question':'Accuracy?','receipt':{'status':'complete'}}
    row={'public':{'cluster_id':'c','question':'Accuracy?','evidence':[ev],
        'trusted_manifest':{'e':{'content_sha256':h}}},
        'prediction':{'answer':95.2,'evidence_bindings':[{'evidence_id':'e','quote':'Accuracy 95.2'}]}}
    assert e.source_scores(row)==(True,True)
    altered=copy.deepcopy(row);altered['prediction']['answer']=70
    assert e.source_scores(altered)==(True,False)
    altered=copy.deepcopy(row);altered['public']['evidence'][0]['text']='Accuracy 70.0'
    assert e.source_scores(altered)==(False,False)
    p.write_text('Accuracy 70.0')
    assert e.source_scores(row)==(False,True)
protocol=json.loads((O/'protocol.json').read_text())
assert hashlib.sha256((R/'scripts/scope_probe_20260930.py').read_bytes()).hexdigest()==protocol['source_sha256']
rows=[json.loads(p.read_text()) for p in (O/'records').glob('*.json')]
assert len(rows)==79 and len({r['task_id'] for r in rows})==79
for row in rows:
    assert len(row['api_calls'])==3
    assert not row['gates']['scope_witness'] or row['gates']['answer_agreement']
    calls=[json.loads((O/path).read_text()) for path in row['api_calls']]
    for c in calls:
        assert c['request']['temperature']==0 and c['request']['max_tokens']==1536
        for msg in c['request']['messages']:
            assert row['task_id'] not in msg['content']
            assert 'reference_values' not in msg['content']
    assert json.loads(calls[0]['request']['messages'][1]['content'])==row['public']
    assert json.loads(calls[2]['request']['messages'][1]['content'])==row['public']
out={'status':'PASS','records':79,'unique_requests':237,'checks':['fixed protocol hash','complete cases',
     'three requests per case','same report and witness inputs','no private task IDs or reference fields in requests',
     'scope gate subset of agreement gate','separate evaluator positive, wrong-answer, changed-text, changed-file tests']}
(O/'validation.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
