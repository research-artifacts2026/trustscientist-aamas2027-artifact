"""Exploratory paired gate study. Freeze before querying; do not tune on results."""
import concurrent.futures as cf
import copy, hashlib, importlib.util, json, time
from pathlib import Path
R=Path('/disk2/ANON/TrustScientist_AAMAS2027')
OUT=R/'releases/paired_scope_probe_20260930'
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
v=load('v4',R/'scripts/39_blind_certificate.py');m=v.m
m.OUT=OUT;v.OUT=OUT
safety=load('safety',R/'scripts/28_runtime_safety.py');safety.apply(m)
SEED=20270928
cases=m.readrows(R/'data/natural_failures/tasks.jsonl')
for c in cases:c['task_id']='natural/'+c['task_id'];c['cohort']='natural'
protocol={'name':'paired_scope_probe_20260930','scope':'Exploratory natural artifact reporting; all 79 previously inspected tasks, no held-out claim',
 'cases':len(cases),'capsules':len({c['cluster_id'] for c in cases}),
 'design':'One shared query-only retrieval, one reporter, one rubric judge, one blind scope witness per case; paired deterministic gates over identical outputs',
 'methods':['literal_contract','structured_rubric','answer_agreement','scope_witness'],
 'primary_contrast':'scope_witness versus answer_agreement; count rejected reference errors AND lost correct closures',
 'primary_score':'Final answer agreement with preexisting benchmark reference; evaluator independently implemented; source consistency reported separately; semantic fidelity unlabelled',
 'seed':SEED,'temperature':0,'max_output_tokens':m.MAX_OUTPUT,'model':m.MODEL,
 'source_sha256':m.digest(Path(__file__).read_bytes()),'input_sha256':m.digest(m.canonical(cases)),
 'base_sha256':m.digest((R/'scripts/21_v2b_experiments.py').read_bytes()),
 'certificate_sha256':m.digest((R/'scripts/39_blind_certificate.py').read_bytes()),
 'notes':'No controller superiority, adaptive-risk certification, independent human annotation, or fresh scientific execution claim. Same-model agreement is not independent gold.'}
p=OUT/'protocol.json'
if p.exists():assert json.loads(p.read_text())==protocol
else:m.dump(p,protocol)
def run(c):
    dest=OUT/'records'/(m.digest(c['task_id'])[:24]+'.json')
    if dest.exists():return json.loads(dest.read_text())
    start=time.time();c=copy.deepcopy(c);rid=dest.stem
    receipt=v.execute(c,{'action':'search','query':c['question'],'offset':0},'paired',rid)
    public=m.public(c)
    sentinel=copy.deepcopy(c);sentinel['reference_values']=['DO_NOT_EXPOSE_GOLD'];assert m.public(sentinel)==public
    client=m.Client('paired',rid,SEED)
    pred=client.query([{'role':'system','content':m.PROMPT+'\nReturn a final report now; no further tools are available.'},
        {'role':'user','content':m.canonical(public)}],'shared_report')
    review=m.semantic(client,c,pred)
    proof=client.query([{'role':'system','content':v.CERT},{'role':'user','content':m.canonical(public)}],'blind_scope_witness')
    req=pred.get('requirements',[])
    base=bool(m.audit(c)[0] and m.binding_valid(pred,c) and isinstance(req,list) and all(q in req for q in c['requirements']) and pred.get('declared_done') is True)
    agree,state=v.certificate(c,pred,proof,False)
    scope,scope_state=v.certificate(c,pred,proof,True)
    gates={'literal_contract':base,'structured_rubric':bool(base and m.semantic_pass(review)),
           'answer_agreement':bool(base and agree),'scope_witness':bool(base and scope)}
    assert not gates['scope_witness'] or gates['answer_agreement']
    row={'task_id':c['task_id'],'cluster_id':c['cluster_id'],'public':public,'prediction':pred,'review':review,'proof':proof,
         'gates':gates,'certificate_state':scope_state,'receipt':receipt,'api_calls':client.calls,
         'usage':dict(client.usage),'elapsed_seconds':time.time()-start}
    m.dump(dest,row);return row
if __name__=='__main__':
    with cf.ThreadPoolExecutor(max_workers=8) as pool:
        for i,row in enumerate(pool.map(run,cases),1):print(f'{i}/{len(cases)} completed',flush=True)
    m.dump(OUT/'completion.json',{'records':len(cases),'status':'completed','protocol_sha256':m.digest(p.read_bytes())})
